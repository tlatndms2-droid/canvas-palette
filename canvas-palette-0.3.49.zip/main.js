var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => CanvasPalettePlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian18 = require("obsidian");

// src/canvas/canvas-adapter.ts
var import_obsidian = require("obsidian");

// src/core/ids.ts
function createId(prefix) {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
}

// src/core/canvas-node-replacement.ts
function findMarkdownNodeReplacement(previousNodes, currentNodes, linkedNodeIds, maximumDistance = 48) {
  const removedNode = linkedNodeIds.map((nodeId) => previousNodes.get(nodeId)).find((node) => Boolean((node == null ? void 0 : node.type) === "text" && !currentNodes.has(node.id)));
  if (!removedNode) return null;
  const replacementNode = [...currentNodes.values()].filter((node) => {
    var _a;
    return node.type === "file" && ((_a = node.file) == null ? void 0 : _a.toLocaleLowerCase().endsWith(".md")) && !previousNodes.has(node.id);
  }).sort((left, right) => nodeDistance(left, removedNode) - nodeDistance(right, removedNode))[0];
  return replacementNode && nodeDistance(replacementNode, removedNode) <= maximumDistance ? { removedNode, replacementNode } : null;
}
function nodeDistance(left, right) {
  const leftCenterX = left.x + left.width / 2;
  const leftCenterY = left.y + left.height / 2;
  const rightCenterX = right.x + right.width / 2;
  const rightCenterY = right.y + right.height / 2;
  return Math.hypot(leftCenterX - rightCenterX, leftCenterY - rightCenterY);
}

// src/core/serial-task-queue.ts
var SerialTaskQueue = class {
  constructor() {
    __publicField(this, "tails", /* @__PURE__ */ new Map());
  }
  enqueue(key, task) {
    var _a;
    const previous = (_a = this.tails.get(key)) != null ? _a : Promise.resolve();
    const result = previous.catch(() => void 0).then(task);
    const tail = result.then(() => void 0, () => void 0);
    this.tails.set(key, tail);
    void tail.then(() => {
      if (this.tails.get(key) === tail) this.tails.delete(key);
    });
    return result;
  }
};

// src/canvas/group-serializer.ts
function serializeGroup(nodes, edges) {
  if (nodes.length === 0) return { bounds: { width: 0, height: 0 }, nodes: [], edges: [] };
  const minX = Math.min(...nodes.map((node) => node.x));
  const minY = Math.min(...nodes.map((node) => node.y));
  const maxX = Math.max(...nodes.map((node) => node.x + node.width));
  const maxY = Math.max(...nodes.map((node) => node.y + node.height));
  const ids = new Set(nodes.map((node) => node.id));
  return {
    bounds: { width: maxX - minX, height: maxY - minY },
    nodes: nodes.map((node) => ({ ...node, x: node.x - minX, y: node.y - minY })),
    edges: edges.filter((edge) => ids.has(edge.fromNode) && ids.has(edge.toNode)).map((edge) => ({ ...edge }))
  };
}
function restoreGroup(snapshot, x, y, nodeIdFactory, edgeIdFactory) {
  const idMap = /* @__PURE__ */ new Map();
  const nodes = snapshot.nodes.filter((node, index, all) => typeof node.id === "string" && node.id.length > 0 && all.findIndex((candidate) => candidate.id === node.id) === index);
  let discardedReferences = snapshot.nodes.length - nodes.length;
  for (const node of nodes) idMap.set(node.id, nodeIdFactory());
  const restoredNodes = nodes.map((node) => {
    const parentId = node.parentId && idMap.has(node.parentId) ? idMap.get(node.parentId) : void 0;
    if (node.parentId && !parentId) discardedReferences++;
    return { ...node, id: idMap.get(node.id), x: node.x + x, y: node.y + y, parentId };
  });
  const restoredEdges = snapshot.edges.flatMap((edge) => {
    const fromNode = idMap.get(edge.fromNode);
    const toNode = idMap.get(edge.toNode);
    if (!fromNode || !toNode) {
      discardedReferences++;
      return [];
    }
    return [{ ...edge, id: edgeIdFactory(), fromNode, toNode }];
  });
  return {
    bounds: { ...snapshot.bounds },
    nodes: restoredNodes,
    edges: restoredEdges,
    nodeBacks: snapshot.nodeBacks,
    nodeMetadata: snapshot.nodeMetadata,
    originalToRestored: idMap,
    discardedReferences
  };
}

// src/canvas/canvas-adapter.ts
var IMAGE_EXTENSIONS = /* @__PURE__ */ new Set(["png", "jpg", "jpeg", "gif", "webp", "svg", "bmp", "avif"]);
var CanvasAdapter = class {
  constructor(app, onRestored, getMetadata, restoreNodeMetadata, linkedNodes = () => [], onReplaced = () => {
  }) {
    this.app = app;
    this.onRestored = onRestored;
    this.getMetadata = getMetadata;
    this.restoreNodeMetadata = restoreNodeMetadata;
    this.linkedNodes = linkedNodes;
    this.onReplaced = onReplaced;
    __publicField(this, "restoreQueue", new SerialTaskQueue());
    __publicField(this, "previousNodesByCanvas", /* @__PURE__ */ new Map());
  }
  activeContext() {
    var _a;
    const leaf = this.app.workspace.activeLeaf;
    const view = leaf == null ? void 0 : leaf.view;
    if (!view || ((_a = view.getViewType) == null ? void 0 : _a.call(view)) !== "canvas" || !view.file || !view.canvas) return null;
    return { file: view.file, view, runtime: view.canvas };
  }
  activeContainer() {
    var _a, _b;
    return (_b = (_a = this.activeContext()) == null ? void 0 : _a.view.containerEl) != null ? _b : null;
  }
  contextForTarget(target) {
    var _a;
    if (!(target instanceof Node)) return null;
    for (const leaf of this.app.workspace.getLeavesOfType("canvas")) {
      const view = leaf.view;
      if (view.file && view.canvas && ((_a = view.containerEl) == null ? void 0 : _a.contains(target))) return { file: view.file, view, runtime: view.canvas };
    }
    return null;
  }
  openContexts() {
    return this.app.workspace.getLeavesOfType("canvas").map((leaf) => {
      const view = leaf.view;
      return view.file && view.canvas ? { file: view.file, view, runtime: view.canvas } : null;
    }).filter((value) => Boolean(value));
  }
  nodeContext(value) {
    var _a;
    const nodeId = this.runtimeNodeId(value);
    if (!nodeId) return null;
    const context = (_a = this.openContexts().find((candidate) => {
      var _a2;
      return ((_a2 = candidate.runtime.nodes) == null ? void 0 : _a2.get(nodeId)) === value;
    })) != null ? _a : this.activeContext();
    return context ? { canvasPath: context.file.path, nodeId } : null;
  }
  openNodeIds(canvasPath) {
    const ids = /* @__PURE__ */ new Set();
    for (const context of this.openContexts()) {
      if (context.file.path !== canvasPath || !(context.runtime.nodes instanceof Map)) continue;
      for (const nodeId of context.runtime.nodes.keys()) ids.add(nodeId);
    }
    return ids;
  }
  supportsFrontBack(node) {
    var _a;
    const data = (_a = node.getData) == null ? void 0 : _a.call(node);
    if ((data == null ? void 0 : data.type) === "text") return true;
    return (data == null ? void 0 : data.type) === "file" && Boolean(data.file);
  }
  beginBackDrag(node, event) {
    var _a;
    if (event.button !== 0 || !event.isPrimary || !node.nodeEl) return false;
    const context = this.openContexts().find((candidate) => {
      var _a2, _b;
      return ((_b = candidate.runtime.nodes) == null ? void 0 : _b.get((_a2 = node.id) != null ? _a2 : "")) === node;
    });
    const posFromEvt = context == null ? void 0 : context.runtime.posFromEvt;
    if (!context || !posFromEvt || !node.moveTo) return false;
    const runtime = context.runtime;
    const pointFromEvent = (pointerEvent) => posFromEvt.call(runtime, pointerEvent);
    const selected = runtime.selection instanceof Set && runtime.selection.has(node) ? [...runtime.selection].filter((candidate) => candidate.moveTo) : [node];
    if (!(runtime.selection instanceof Set) || !runtime.selection.has(node)) (_a = runtime.selectOnly) == null ? void 0 : _a.call(runtime, node);
    const startPoint = pointFromEvent(event);
    const starts = selected.map((candidate) => {
      var _a2, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l;
      return {
        node: candidate,
        x: (_c = (_b = candidate.x) != null ? _b : (_a2 = candidate.getData) == null ? void 0 : _a2.call(candidate).x) != null ? _c : 0,
        y: (_f = (_e = candidate.y) != null ? _e : (_d = candidate.getData) == null ? void 0 : _d.call(candidate).y) != null ? _f : 0,
        width: (_i = (_h = candidate.width) != null ? _h : (_g = candidate.getData) == null ? void 0 : _g.call(candidate).width) != null ? _i : 0,
        height: (_l = (_k = candidate.height) != null ? _k : (_j = candidate.getData) == null ? void 0 : _j.call(candidate).height) != null ? _l : 0
      };
    });
    const win = node.nodeEl.ownerDocument.defaultView;
    if (!win) return false;
    let moved = false;
    const move = (moveEvent) => {
      var _a2, _b, _c;
      if (moveEvent.pointerId !== event.pointerId) return;
      const point = pointFromEvent(moveEvent);
      const delta = { x: point.x - startPoint.x, y: point.y - startPoint.y };
      if (!moved && Math.hypot(delta.x, delta.y) < 3) return;
      moved = true;
      moveEvent.preventDefault();
      for (const start of starts) {
        (_a2 = start.node.nodeEl) == null ? void 0 : _a2.addClass("is-dragging");
        (_c = (_b = start.node).moveTo) == null ? void 0 : _c.call(_b, { x: start.x + delta.x, y: start.y + delta.y, width: start.width, height: start.height });
      }
    };
    const finish = (finishEvent) => {
      var _a2, _b;
      if (finishEvent.pointerId !== event.pointerId) return;
      win.removeEventListener("pointermove", move, true);
      win.removeEventListener("pointerup", finish, true);
      win.removeEventListener("pointercancel", finish, true);
      for (const start of starts) (_a2 = start.node.nodeEl) == null ? void 0 : _a2.removeClass("is-dragging");
      if (moved) (_b = runtime.requestSave) == null ? void 0 : _b.call(runtime);
    };
    win.addEventListener("pointermove", move, true);
    win.addEventListener("pointerup", finish, true);
    win.addEventListener("pointercancel", finish, true);
    return true;
  }
  async collectSelection() {
    const context = this.activeContext();
    if (!context) {
      new import_obsidian.Notice("Open a Canvas before collecting Canvas items.");
      return [];
    }
    const document2 = await this.read(context.file);
    const selectedIds = this.runtimeSelectionIds(context.view);
    return this.collectIds(document2, context.file.path, selectedIds);
  }
  async collectNode(node) {
    const context = this.activeContext();
    if (!context) {
      new import_obsidian.Notice("Open a Canvas before collecting Canvas items.");
      return [];
    }
    const document2 = await this.read(context.file);
    const id = this.runtimeNodeId(node);
    if (!id) {
      new import_obsidian.Notice("Unable to identify the selected Canvas item.");
      return [];
    }
    return this.collectIds(document2, context.file.path, [id]);
  }
  async collectIds(document2, canvasPath, selectedIds) {
    var _a;
    if (selectedIds.length === 0) {
      new import_obsidian.Notice("Select one or more Canvas items first.");
      return [];
    }
    const selectedNodes = document2.nodes.filter((node) => selectedIds.includes(node.id));
    const selectedGroups = selectedNodes.filter((node) => node.type === "group");
    const groupNodes = /* @__PURE__ */ new Map();
    for (const group of selectedGroups) groupNodes.set(group.id, this.expandGroupNodes(document2.nodes, [group.id]));
    const rootGroups = selectedGroups.filter((group) => !selectedGroups.some((other) => {
      var _a2;
      return other.id !== group.id && ((_a2 = groupNodes.get(other.id)) == null ? void 0 : _a2.some((node) => node.id === group.id));
    }));
    const capturedByGroup = new Set(rootGroups.flatMap((group) => {
      var _a2, _b;
      return (_b = (_a2 = groupNodes.get(group.id)) == null ? void 0 : _a2.map((node) => node.id)) != null ? _b : [];
    }));
    const items = [];
    for (const group of rootGroups) {
      const item = this.groupItem((_a = groupNodes.get(group.id)) != null ? _a : [group], document2.edges, canvasPath, group.id);
      if (item) items.push(item);
    }
    for (const node of selectedNodes) {
      if (node.type === "group" || capturedByGroup.has(node.id)) continue;
      items.push(await this.itemFromNode(node, canvasPath));
    }
    return items;
  }
  async syncItemToCanvases(item, locations) {
    var _a;
    if (item.type !== "card") return;
    const byCanvas = /* @__PURE__ */ new Map();
    for (const location of locations) byCanvas.set(location.canvasPath, [...(_a = byCanvas.get(location.canvasPath)) != null ? _a : [], location.nodeId]);
    for (const [canvasPath, nodeIds] of byCanvas) await this.syncCardToCanvas(item, canvasPath, nodeIds);
  }
  async renameLinkedFileNodes(locations, filePath) {
    await this.mutateLinkedNodes(locations, (node) => {
      if (node.type !== "file" || node.file === filePath) return false;
      node.file = filePath;
      return true;
    });
  }
  async renameLinkedGroupNodes(locations, title) {
    await this.mutateLinkedNodes(locations, (node) => {
      if (node.type !== "group" || node.label === title) return false;
      node.label = title;
      return true;
    });
  }
  async convertLinkedCardsToMarkdown(locations, filePath) {
    await this.mutateLinkedNodes(locations, (node) => {
      if (node.type !== "text") return false;
      node.type = "file";
      node.file = filePath;
      delete node.text;
      return true;
    }, true);
  }
  async mutateLinkedNodes(locations, mutate, replaceOpenRuntimeNodes = false) {
    var _a, _b, _c;
    const byCanvas = /* @__PURE__ */ new Map();
    for (const location of locations) {
      const nodeIds = (_a = byCanvas.get(location.canvasPath)) != null ? _a : /* @__PURE__ */ new Set();
      nodeIds.add(location.nodeId);
      byCanvas.set(location.canvasPath, nodeIds);
    }
    for (const [canvasPath, nodeIds] of byCanvas) {
      const open = this.openContexts().find((context) => context.file.path === canvasPath);
      if ((open == null ? void 0 : open.runtime.getData) && open.runtime.setData) {
        const current = open.runtime.getData();
        if (!current || typeof current !== "object") continue;
        const document3 = this.parse(JSON.stringify(current));
        let changed2 = false;
        const changedNodeIds = /* @__PURE__ */ new Set();
        for (const node of document3.nodes) {
          if (!nodeIds.has(node.id) || !mutate(node)) continue;
          changed2 = true;
          changedNodeIds.add(node.id);
        }
        if (!changed2) continue;
        if (replaceOpenRuntimeNodes) {
          const withoutConvertedNodes = {
            ...document3,
            nodes: document3.nodes.filter((node) => !changedNodeIds.has(node.id)),
            edges: document3.edges.filter((edge) => !changedNodeIds.has(edge.fromNode) && !changedNodeIds.has(edge.toNode))
          };
          await open.runtime.setData(withoutConvertedNodes);
        }
        await open.runtime.setData(document3);
        (_c = (_b = open.runtime).requestSave) == null ? void 0 : _c.call(_b);
        continue;
      }
      const file = this.app.vault.getAbstractFileByPath(canvasPath);
      if (!(file instanceof import_obsidian.TFile)) continue;
      const document2 = await this.read(file);
      let changed = false;
      for (const node of document2.nodes) if (nodeIds.has(node.id)) changed = mutate(node) || changed;
      if (changed) await this.app.vault.modify(file, JSON.stringify(document2, null, 2));
    }
  }
  async syncCardToCanvas(item, canvasPath, nodeIds) {
    var _a, _b, _c, _d;
    const open = this.openContexts().find((context) => context.file.path === canvasPath);
    if ((open == null ? void 0 : open.runtime.getData) && open.runtime.setData) {
      const current = open.runtime.getData();
      if (!current || typeof current !== "object") return;
      const document3 = this.parse(JSON.stringify(current));
      const nodes2 = document3.nodes.filter((candidate) => nodeIds.includes(candidate.id) && candidate.type === "text");
      const changed2 = nodes2.some((node) => {
        var _a2;
        return node.text !== this.syncedCardText(item, (_a2 = node.text) != null ? _a2 : "");
      });
      if (!changed2) return;
      for (const node of nodes2) node.text = this.syncedCardText(item, (_a = node.text) != null ? _a : "");
      await open.runtime.setData(document3);
      (_c = (_b = open.runtime).requestSave) == null ? void 0 : _c.call(_b);
      return;
    }
    const file = this.app.vault.getAbstractFileByPath(canvasPath);
    if (!(file instanceof import_obsidian.TFile)) return;
    const document2 = await this.read(file);
    const nodes = document2.nodes.filter((candidate) => nodeIds.includes(candidate.id) && candidate.type === "text");
    const changed = nodes.some((node) => {
      var _a2;
      return node.text !== this.syncedCardText(item, (_a2 = node.text) != null ? _a2 : "");
    });
    if (!changed) return;
    for (const node of nodes) node.text = this.syncedCardText(item, (_d = node.text) != null ? _d : "");
    await this.app.vault.modify(file, JSON.stringify(document2, null, 2));
  }
  async syncItemsFromCanvas(file, items) {
    var _a, _b, _c, _d;
    const document2 = await this.read(file);
    const previousNodes = (_a = this.previousNodesByCanvas.get(file.path)) != null ? _a : /* @__PURE__ */ new Map();
    const currentNodes = new Map(document2.nodes.map((node) => [node.id, node]));
    const existingNodeIds = new Set(currentNodes.keys());
    let changed = 0;
    for (const item of items) {
      const linkedNodeIds = [
        ...item.origin.canvasPath === file.path && item.origin.canvasNodeId ? [item.origin.canvasNodeId] : [],
        ...item.canvasPlacements.filter((placement) => placement.canvasPath === file.path).flatMap((placement) => placement.nodeIds)
      ];
      if (linkedNodeIds.length === 0) continue;
      if (item.type === "card") {
        const replacement = findMarkdownNodeReplacement(previousNodes, currentNodes, linkedNodeIds);
        const removedLinkedNode = replacement == null ? void 0 : replacement.removedNode;
        const replacementNode = replacement == null ? void 0 : replacement.replacementNode;
        const convertedNode = (_b = document2.nodes.find((candidate) => {
          var _a2;
          return linkedNodeIds.includes(candidate.id) && candidate.type === "file" && ((_a2 = candidate.file) == null ? void 0 : _a2.toLocaleLowerCase().endsWith(".md"));
        })) != null ? _b : replacementNode;
        if (convertedNode == null ? void 0 : convertedNode.file) {
          if (removedLinkedNode && convertedNode.id !== removedLinkedNode.id) this.onReplaced(item.id, file.path, [removedLinkedNode.id], [convertedNode.id], existingNodeIds);
          const source = this.app.vault.getAbstractFileByPath(convertedNode.file);
          item.type = "markdown";
          item.origin.filePath = convertedNode.file;
          delete item.origin.textRange;
          if (source instanceof import_obsidian.TFile) {
            item.displayTitle = source.basename;
            item.content = await this.app.vault.cachedRead(source);
          }
          item.modifiedAt = Date.now();
          changed++;
          continue;
        }
      }
      const linkedNodes = document2.nodes.filter((candidate) => linkedNodeIds.includes(candidate.id) && candidate.type === (item.type === "card" ? "text" : "group"));
      const node = item.type === "card" ? (_c = linkedNodes.find((candidate) => {
        var _a2, _b2;
        return ((_a2 = candidate.text) != null ? _a2 : "") !== ((_b2 = item.content) != null ? _b2 : "");
      })) != null ? _c : linkedNodes[0] : linkedNodes[0];
      if (!node) continue;
      if (item.type === "card" && node.type === "text") {
        const rawContent = (_d = node.text) != null ? _d : "";
        const heading = this.readHeading(rawContent);
        const normalizeHeading = Boolean(heading && this.plainTitle(item.displayTitle) === this.plainTitle(heading.title));
        const content = normalizeHeading && heading ? heading.body : rawContent;
        const displayTitle = normalizeHeading && heading ? this.plainTitle(heading.title) : rawContent.split(/\r?\n/, 1)[0].slice(0, 80) || "Canvas card";
        if (item.content !== content || item.displayTitle !== displayTitle) {
          item.content = content;
          item.displayTitle = displayTitle;
          item.modifiedAt = Date.now();
          changed++;
        }
      } else if (item.type === "group" && node.type === "group") {
        const nodes = this.expandGroupNodes(document2.nodes, [node.id]);
        const group = serializeGroup(nodes, document2.edges);
        if (JSON.stringify(item.group) !== JSON.stringify(group)) {
          item.group = group;
          item.modifiedAt = Date.now();
          changed++;
        }
      }
    }
    this.previousNodesByCanvas.set(file.path, currentNodes);
    return { changedItems: changed, nodeIds: existingNodeIds };
  }
  async revealNode(canvasPath, nodeId) {
    var _a, _b, _c;
    const file = this.app.vault.getAbstractFileByPath(canvasPath);
    if (!(file instanceof import_obsidian.TFile)) return false;
    let context = this.openContexts().find((candidate) => candidate.file.path === canvasPath);
    let leaf = context ? this.app.workspace.getLeavesOfType("canvas").find((candidate) => {
      var _a2;
      return ((_a2 = candidate.view.file) == null ? void 0 : _a2.path) === canvasPath;
    }) : void 0;
    if (!context || !leaf) {
      leaf = this.app.workspace.getLeaf("tab");
      await leaf.openFile(file);
      const view = leaf.view;
      if (!view.canvas) return false;
      context = { file, view, runtime: view.canvas };
    }
    this.app.workspace.setActiveLeaf(leaf, { focus: true });
    const node = (_a = context.runtime.nodes) == null ? void 0 : _a.get(nodeId);
    if (!node || !context.runtime.selectOnly) return false;
    context.runtime.selectOnly(node);
    (_c = (_b = context.runtime).zoomToSelection) == null ? void 0 : _c.call(_b);
    return true;
  }
  async restoreItem(item, screenX, screenY) {
    var _a, _b;
    const context = this.activeContext();
    if (!context) {
      new import_obsidian.Notice("Open a Canvas before dropping an item.");
      return false;
    }
    const point = (_b = (_a = context.runtime).posFromClient) == null ? void 0 : _b.call(_a, { x: screenX, y: screenY });
    if (!point) {
      new import_obsidian.Notice("Unable to calculate the Canvas drop position.");
      return false;
    }
    return this.restoreQueue.enqueue(context.file.path, () => this.commitBundle(context, this.createItemBundle([item], context), point, "copy"));
  }
  async restoreItems(items, screenX, screenY) {
    var _a, _b;
    const context = this.activeContext();
    if (!context || items.length === 0) {
      if (!context) new import_obsidian.Notice("Open a Canvas before placing items.");
      return false;
    }
    const point = (_b = (_a = context.runtime).posFromClient) == null ? void 0 : _b.call(_a, { x: screenX, y: screenY });
    if (!point) {
      new import_obsidian.Notice("Unable to calculate the Canvas position.");
      return false;
    }
    return this.restoreQueue.enqueue(context.file.path, () => this.commitBundle(context, this.createItemBundle(items, context), point, "copy"));
  }
  async restoreItemFromDrop(item, event) {
    var _a, _b;
    const context = this.contextForTarget(event.target);
    if (!context) return false;
    const point = (_b = (_a = context.runtime).posFromEvt) == null ? void 0 : _b.call(_a, event);
    if (!point) {
      new import_obsidian.Notice("Unable to calculate the Canvas drop position.");
      return false;
    }
    return this.restoreQueue.enqueue(context.file.path, () => this.commitBundle(context, this.createItemBundle([item], context), point, "copy"));
  }
  async restoreItemsFromDrop(items, event) {
    var _a, _b;
    const context = this.contextForTarget(event.target);
    if (!context || items.length === 0) return false;
    const point = (_b = (_a = context.runtime).posFromEvt) == null ? void 0 : _b.call(_a, event);
    if (!point) {
      new import_obsidian.Notice("Unable to calculate the Canvas drop position.");
      return false;
    }
    return this.restoreQueue.enqueue(context.file.path, () => this.commitBundle(context, this.createItemBundle(items, context), point, "copy"));
  }
  batchRestorePositions(items, point) {
    const sizeFor = (item) => {
      var _a, _b, _c, _d;
      return item.type === "group" ? { width: Math.max(280, (_b = (_a = item.group) == null ? void 0 : _a.bounds.width) != null ? _b : 280), height: Math.max(180, (_d = (_c = item.group) == null ? void 0 : _c.bounds.height) != null ? _d : 180) } : item.type === "image" ? { width: 360, height: 240 } : { width: 280, height: 180 };
    };
    const sizes = items.map(sizeFor);
    const columns = items.some((item) => item.type === "group") ? 1 : Math.max(1, Math.ceil(Math.sqrt(items.length)));
    const columnWidth = Math.max(...sizes.map((size) => size.width)) + 56;
    const rowHeight = Math.max(...sizes.map((size) => size.height)) + 56;
    return items.map((_item, index) => ({ x: point.x + index % columns * columnWidth, y: point.y + Math.floor(index / columns) * rowHeight }));
  }
  createItemBundle(items, context) {
    var _a;
    const document2 = this.currentDocument(context);
    const positions = this.batchRestorePositions(items, { x: 0, y: 0 });
    const usedNodeIds = new Set(document2.nodes.map((node) => node.id));
    const usedEdgeIds = new Set(document2.edges.map((edge) => edge.id));
    const nodes = [];
    const edges = [];
    const placements = [];
    const metadata = [];
    const warnings = [];
    for (const [index, item] of items.entries()) {
      const point = (_a = positions[index]) != null ? _a : { x: 0, y: 0 };
      const material = this.materializeItem(item, point.x, point.y, usedNodeIds, usedEdgeIds);
      if (!material) {
        warnings.push(`${item.displayTitle}: stored Group data is unavailable.`);
        continue;
      }
      nodes.push(...material.nodes);
      edges.push(...material.edges);
      metadata.push(...material.metadata);
      warnings.push(...material.warnings);
      if (material.placementNodeIds.length > 0) placements.push({ itemId: item.id, nodeIds: material.placementNodeIds });
    }
    return this.normalizeBundle({ nodes, edges, placements, metadata, warnings, items: [...items] });
  }
  canvasFiles() {
    return this.app.vault.getFiles().filter((file) => file.extension.toLowerCase() === "canvas").sort((left, right) => left.path.localeCompare(right.path, void 0, { numeric: true }));
  }
  async openContext(file) {
    var _a;
    const existing = this.openContexts().find((context) => context.file.path === file.path);
    if (existing) return existing;
    const leaf = this.app.workspace.getLeaf("tab");
    await leaf.openFile(file);
    this.app.workspace.setActiveLeaf(leaf, { focus: true });
    const view = leaf.view;
    return ((_a = view.file) == null ? void 0 : _a.path) === file.path && view.canvas ? { file, view, runtime: view.canvas } : null;
  }
  createTreeBundle(entries, context) {
    var _a, _b, _c, _d;
    if (entries.length === 0) return this.emptyBundle();
    const positions = this.treeLayout(entries);
    const depths = this.treeDepths(entries);
    const document2 = this.currentDocument(context);
    const usedNodeIds = new Set(document2.nodes.map((node) => node.id));
    const usedEdgeIds = new Set(document2.edges.map((edge) => edge.id));
    const canvasNodes = [];
    const edges = [];
    const anchors = /* @__PURE__ */ new Map();
    const restoredByItem = /* @__PURE__ */ new Map();
    const metadata = [];
    const warnings = [];
    for (const entry of entries) {
      const position = (_a = positions.get(entry.id)) != null ? _a : { x: 0, y: 0 };
      const headingLevel = Math.min(6, ((_b = depths.get(entry.id)) != null ? _b : 0) + 1);
      if (!entry.item) {
        const node = this.headingNode(entry.name, headingLevel, position.x, position.y, () => this.uniqueId("node", usedNodeIds));
        canvasNodes.push(node);
        anchors.set(entry.id, node.id);
        continue;
      }
      const material = this.materializeItem(entry.item, position.x, position.y, usedNodeIds, usedEdgeIds, headingLevel);
      if (!material) {
        warnings.push(`${entry.item.displayTitle}: stored Group data is unavailable.`);
        continue;
      }
      canvasNodes.push(...material.nodes);
      edges.push(...material.edges);
      metadata.push(...material.metadata);
      warnings.push(...material.warnings);
      if (material.anchorNodeId) anchors.set(entry.id, material.anchorNodeId);
      if (material.placementNodeIds.length > 0) restoredByItem.set(entry.item.id, material.placementNodeIds);
    }
    for (const entry of entries) {
      if (!entry.parentId) continue;
      let parentId = entry.parentId;
      while (parentId && !anchors.has(parentId)) parentId = (_d = (_c = entries.find((candidate) => candidate.id === parentId)) == null ? void 0 : _c.parentId) != null ? _d : null;
      const fromNode = parentId ? anchors.get(parentId) : void 0;
      const toNode = anchors.get(entry.id);
      if (fromNode && toNode) edges.push({ id: this.uniqueId("edge", usedEdgeIds), fromNode, toNode, fromSide: "right", toSide: "left" });
    }
    return this.normalizeBundle({
      nodes: canvasNodes,
      edges,
      placements: [...restoredByItem.entries()].map(([itemId, nodeIds]) => ({ itemId, nodeIds })),
      metadata,
      warnings,
      items: entries.flatMap((entry) => entry.item ? [entry.item] : [])
    });
  }
  async itemFromNode(node, canvasPath) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j;
    const now = Date.now();
    const metadata = this.getMetadata(canvasPath, node.id);
    const common = { tags: (_a = metadata == null ? void 0 : metadata.tags) != null ? _a : [], label: (_b = metadata == null ? void 0 : metadata.label) != null ? _b : "", labelColor: (_c = metadata == null ? void 0 : metadata.labelColor) != null ? _c : "", caption: (_d = metadata == null ? void 0 : metadata.caption) != null ? _d : "", backContent: (_e = metadata == null ? void 0 : metadata.backContent) != null ? _e : "", facesEnabled: (_f = metadata == null ? void 0 : metadata.facesEnabled) != null ? _f : false, modifiedAt: (_g = metadata == null ? void 0 : metadata.modifiedAt) != null ? _g : now };
    if (node.type === "file" && node.file) {
      const file = this.app.vault.getAbstractFileByPath(node.file);
      const isImage = file instanceof import_obsidian.TFile && IMAGE_EXTENSIONS.has(file.extension.toLowerCase());
      const type = isImage ? "image" : "markdown";
      return { id: createId(type), type, displayTitle: file instanceof import_obsidian.TFile ? file.basename : node.file, ...common, createdAt: now, origin: { canvasPath, canvasNodeId: node.id, filePath: node.file }, canvasPlacements: [], content: type === "markdown" && file instanceof import_obsidian.TFile ? await this.app.vault.cachedRead(file) : void 0 };
    }
    return { id: createId("card"), type: "card", displayTitle: ((_h = node.text) != null ? _h : "Canvas card").split(/\r?\n/, 1)[0].slice(0, 80), ...common, facesEnabled: (_i = metadata == null ? void 0 : metadata.facesEnabled) != null ? _i : false, createdAt: now, origin: { canvasPath, canvasNodeId: node.id }, canvasPlacements: [], content: (_j = node.text) != null ? _j : "" };
  }
  groupItem(nodes, edges, canvasPath, nodeId) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j;
    if (nodes.length === 0) return null;
    const now = Date.now();
    const metadata = this.getMetadata(canvasPath, nodeId);
    const snapshot = serializeGroup(nodes, edges);
    snapshot.nodeBacks = Object.fromEntries(nodes.map((node) => {
      var _a2, _b2;
      return [node.id, (_b2 = (_a2 = this.getMetadata(canvasPath, node.id)) == null ? void 0 : _a2.backContent) != null ? _b2 : ""];
    }).filter(([, back]) => Boolean(back)));
    snapshot.nodeMetadata = Object.fromEntries(nodes.map((node) => [node.id, this.getMetadata(canvasPath, node.id)]).filter((entry) => Boolean(entry[1])).map(([id, value]) => [id, { ...value, tags: [...value.tags] }]));
    const title = (_e = (_d = (_a = nodes.find((node) => node.type === "group")) == null ? void 0 : _a.label) != null ? _d : (_c = (_b = nodes.find((node) => node.text)) == null ? void 0 : _b.text) == null ? void 0 : _c.split(/\r?\n/, 1)[0]) != null ? _e : "Canvas group";
    return { id: createId("group"), type: "group", displayTitle: title.slice(0, 80), tags: (_f = metadata == null ? void 0 : metadata.tags) != null ? _f : [], label: (_g = metadata == null ? void 0 : metadata.label) != null ? _g : "", labelColor: (_h = metadata == null ? void 0 : metadata.labelColor) != null ? _h : "", caption: (_i = metadata == null ? void 0 : metadata.caption) != null ? _i : "", backContent: "", facesEnabled: false, createdAt: now, modifiedAt: (_j = metadata == null ? void 0 : metadata.modifiedAt) != null ? _j : now, origin: { canvasPath, canvasNodeId: nodeId }, canvasPlacements: [], group: snapshot };
  }
  materializeItem(item, x, y, usedNodeIds, usedEdgeIds, headingLevel) {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    if (item.type === "group") {
      if (!item.group) return null;
      const snapshot = restoreGroup(item.group, x, y, () => this.uniqueId("node", usedNodeIds), () => this.uniqueId("edge", usedEdgeIds));
      const groupNodeIds = snapshot.nodes.filter((node) => node.type === "group").map((node) => node.id);
      const placementNodeIds = groupNodeIds.length > 0 ? groupNodeIds : snapshot.nodes.map((node) => node.id);
      const outerGroup = (_a = snapshot.nodes.find((node) => node.type === "group" && !node.parentId)) != null ? _a : snapshot.nodes.find((node) => node.type === "group");
      const anchorNodeId = (_h = (_g = (_e = (_d = (_b = snapshot.nodes.find((node) => node.parentId === (outerGroup == null ? void 0 : outerGroup.id) && node.type !== "group")) == null ? void 0 : _b.id) != null ? _d : (_c = snapshot.nodes.find((node) => node.type !== "group")) == null ? void 0 : _c.id) != null ? _e : outerGroup == null ? void 0 : outerGroup.id) != null ? _g : (_f = snapshot.nodes[0]) == null ? void 0 : _f.id) != null ? _h : null;
      const metadata2 = [...snapshot.originalToRestored.entries()].flatMap(([originalId, restoredId]) => {
        var _a2, _b2, _c2, _d2, _e2;
        const legacyBack = (_b2 = (_a2 = item.group) == null ? void 0 : _a2.nodeBacks) == null ? void 0 : _b2[originalId];
        const source = (_e2 = (_d2 = (_c2 = item.group) == null ? void 0 : _c2.nodeMetadata) == null ? void 0 : _d2[originalId]) != null ? _e2 : legacyBack ? { tags: [], label: "", labelColor: "", caption: "", backContent: legacyBack, currentFace: "front", facesEnabled: true, modifiedAt: item.modifiedAt } : null;
        return source ? [{ nodeId: restoredId, metadata: { ...source, tags: [...source.tags] } }] : [];
      });
      return { nodes: snapshot.nodes, edges: snapshot.edges, anchorNodeId, placementNodeIds, metadata: metadata2, warnings: snapshot.discardedReferences > 0 ? [`${item.displayTitle}: ${snapshot.discardedReferences} damaged Group reference${snapshot.discardedReferences === 1 ? " was" : "s were"} skipped.`] : [] };
    }
    const restored = this.restoreNodeForItem(item, x, y, () => this.uniqueId("node", usedNodeIds), headingLevel);
    if (!restored.node) return { nodes: [], edges: [], anchorNodeId: null, placementNodeIds: [], metadata: [], warnings: restored.warning ? [restored.warning] : [] };
    const metadata = { tags: [...item.tags], label: item.label, labelColor: item.labelColor, caption: item.caption, backContent: item.backContent, currentFace: "front", facesEnabled: item.facesEnabled, modifiedAt: item.modifiedAt };
    return { nodes: [restored.node], edges: [], anchorNodeId: restored.node.id, placementNodeIds: [restored.node.id], metadata: [{ nodeId: restored.node.id, metadata }], warnings: restored.warning ? [restored.warning] : [] };
  }
  restoreNodeForItem(item, x, y, nextId, headingLevel) {
    const size = this.itemNodeSize(item, headingLevel);
    if (item.type === "markdown") {
      const file = !item.sourceDeletedAt && item.origin.filePath ? this.app.vault.getAbstractFileByPath(item.origin.filePath) : null;
      if (file instanceof import_obsidian.TFile) return { node: { id: nextId(), type: "file", file: file.path, x, y, width: size.width, height: size.height } };
      const text2 = this.exportCardText(item, headingLevel);
      return { node: { id: nextId(), type: "text", text: text2, x, y, width: size.width, height: size.height }, warning: `${item.displayTitle}: Markdown source was unavailable, so stored content was exported as a Card.` };
    }
    if (item.type === "image") {
      const file = item.origin.filePath ? this.app.vault.getAbstractFileByPath(item.origin.filePath) : null;
      if (!(file instanceof import_obsidian.TFile)) return { node: null, warning: `${item.displayTitle}: image source was unavailable and was skipped.` };
      return { node: { id: nextId(), type: "file", file: file.path, x, y, width: size.width, height: size.height } };
    }
    const text = this.exportCardText(item, headingLevel);
    return { node: { id: nextId(), type: "text", text, x, y, width: size.width, height: size.height } };
  }
  /** Split Canvas Markdown headings from the stored Palette title/body. */
  readHeading(text) {
    var _a;
    const lines = text.split(/\r?\n/);
    const match = /^(#{1,6})[ \t]+(.+?)\s*$/.exec((_a = lines[0]) != null ? _a : "");
    if (!match) return null;
    return { level: match[1].length, title: match[2], body: lines.slice(1).join("\n").replace(/^\s*\n?/, "") };
  }
  plainTitle(value) {
    let title = value.trim();
    while (/^#{1,6}[ \t]+/.test(title)) title = title.replace(/^#{1,6}[ \t]+/, "").trim();
    return title.slice(0, 80) || "Canvas card";
  }
  bodyWithoutOwnHeading(item) {
    var _a;
    const content = (_a = item.content) != null ? _a : "";
    const heading = this.readHeading(content);
    if (heading && this.plainTitle(heading.title) === this.plainTitle(item.displayTitle)) return heading.body;
    return content.trim() === this.plainTitle(item.displayTitle) ? "" : content;
  }
  exportCardText(item, headingLevel) {
    const body = this.bodyWithoutOwnHeading(item);
    if (!headingLevel) return body || item.displayTitle;
    const title = this.plainTitle(item.displayTitle);
    return `${"#".repeat(Math.min(6, headingLevel))} ${title}${body.trim() ? `

${body}` : ""}`;
  }
  syncedCardText(item, existingText) {
    var _a;
    const existingHeading = this.readHeading(existingText);
    if (!existingHeading || this.plainTitle(existingHeading.title) !== this.plainTitle(item.displayTitle)) return (_a = item.content) != null ? _a : "";
    const body = this.bodyWithoutOwnHeading(item);
    return `${"#".repeat(existingHeading.level)} ${this.plainTitle(item.displayTitle)}${body.trim() ? `

${body}` : ""}`;
  }
  headingNode(name, headingLevel, x, y, nextId) {
    const size = this.headingSize(headingLevel);
    return { id: nextId(), type: "text", text: `${"#".repeat(headingLevel)} ${name}`, x, y, width: size.width, height: size.height };
  }
  treeLayout(entries) {
    var _a, _b, _c, _d;
    const byId = new Map(entries.map((entry) => [entry.id, entry]));
    const children = /* @__PURE__ */ new Map();
    const roots = [];
    for (const entry of entries) {
      if (!entry.parentId || !byId.has(entry.parentId)) roots.push(entry.id);
      else children.set(entry.parentId, [...(_a = children.get(entry.parentId)) != null ? _a : [], entry.id]);
    }
    const depths = this.treeDepths(entries);
    const depthOf = (id) => {
      var _a2;
      return (_a2 = depths.get(id)) != null ? _a2 : 0;
    };
    const size = (entry) => entry.item ? this.itemNodeSize(entry.item, Math.min(6, depthOf(entry.id) + 1)) : this.headingSize(Math.min(6, depthOf(entry.id) + 1));
    const maxWidth = /* @__PURE__ */ new Map();
    for (const entry of entries) {
      const depth = depthOf(entry.id);
      maxWidth.set(depth, Math.max((_b = maxWidth.get(depth)) != null ? _b : 0, size(entry).width));
    }
    const xByDepth = /* @__PURE__ */ new Map();
    for (let depth = 1; depth <= Math.max(0, ...maxWidth.keys()); depth++) xByDepth.set(depth, ((_c = xByDepth.get(depth - 1)) != null ? _c : 0) + ((_d = maxWidth.get(depth - 1)) != null ? _d : 300) + 80);
    const layout = /* @__PURE__ */ new Map();
    const footprint = /* @__PURE__ */ new Map();
    const heightOf = (id) => {
      var _a2;
      if (footprint.has(id)) return footprint.get(id);
      const entry = byId.get(id);
      if (!entry) return 0;
      const own = size(entry).height;
      const childHeights = ((_a2 = children.get(id)) != null ? _a2 : []).map(heightOf);
      const height = Math.max(own, childHeights.reduce((sum, value) => sum + value, 0) + Math.max(0, childHeights.length - 1) * 56);
      footprint.set(id, height);
      return height;
    };
    const place = (id, top) => {
      var _a2, _b2;
      const entry = byId.get(id);
      if (!entry) return;
      const own = size(entry);
      const total = heightOf(id);
      const childIds = (_a2 = children.get(id)) != null ? _a2 : [];
      layout.set(id, { x: (_b2 = xByDepth.get(depthOf(id))) != null ? _b2 : 0, y: top + (total - own.height) / 2 });
      const childrenHeight = childIds.reduce((sum, childId) => sum + heightOf(childId), 0) + Math.max(0, childIds.length - 1) * 56;
      let childTop = top + (total - childrenHeight) / 2;
      for (const childId of childIds) {
        place(childId, childTop);
        childTop += heightOf(childId) + 56;
      }
    };
    let rootTop = 0;
    for (const id of roots) {
      place(id, rootTop);
      rootTop += heightOf(id) + 56;
    }
    return layout;
  }
  treeDepths(entries) {
    const byId = new Map(entries.map((entry) => [entry.id, entry]));
    const depths = /* @__PURE__ */ new Map();
    const depthOf = (id, visiting = /* @__PURE__ */ new Set()) => {
      if (depths.has(id)) return depths.get(id);
      const entry = byId.get(id);
      if (!(entry == null ? void 0 : entry.parentId) || !byId.has(entry.parentId) || visiting.has(id)) return 0;
      visiting.add(id);
      const depth = depthOf(entry.parentId, visiting) + 1;
      visiting.delete(id);
      depths.set(id, depth);
      return depth;
    };
    for (const entry of entries) depthOf(entry.id);
    return depths;
  }
  headingSize(headingLevel) {
    if (headingLevel <= 1) return { width: 300, height: 96 };
    if (headingLevel === 2) return { width: 270, height: 80 };
    return { width: 240, height: 68 };
  }
  itemNodeSize(item, headingLevel) {
    var _a, _b, _c, _d;
    if (item.type === "group") return { width: Math.max(280, (_b = (_a = item.group) == null ? void 0 : _a.bounds.width) != null ? _b : 280), height: Math.max(180, (_d = (_c = item.group) == null ? void 0 : _c.bounds.height) != null ? _d : 180) };
    const scale = headingLevel ? Math.max(0.72, 1 - (headingLevel - 1) * 0.08) : 1;
    if (item.type === "image") return { width: Math.round(360 * scale), height: Math.round(240 * scale) };
    return { width: Math.round(280 * scale), height: Math.round(180 * scale) };
  }
  bundleDuplicateItemIds(bundle, context) {
    const document2 = this.currentDocument(context);
    const present = new Set(document2.nodes.map((node) => node.id));
    return bundle.items.filter((item) => this.linkedNodes(item, context.file.path).some((id) => present.has(id))).map((item) => item.id);
  }
  bundleDuplicateNodeIds(bundle, context) {
    const document2 = this.currentDocument(context);
    const roots = bundle.items.flatMap((item) => this.linkedNodes(item, context.file.path));
    return new Set(this.expandGroupNodes(document2.nodes, roots).map((node) => node.id));
  }
  bundleCollides(context, bundle, origin, ignoredNodeIds = /* @__PURE__ */ new Set()) {
    const document2 = this.currentDocument(context);
    const left = origin.x;
    const top = origin.y;
    const right = left + bundle.bounds.width;
    const bottom = top + bundle.bounds.height;
    return document2.nodes.some((node) => !ignoredNodeIds.has(node.id) && left < node.x + node.width && right > node.x && top < node.y + node.height && bottom > node.y);
  }
  async commitBundle(context, bundle, origin, duplicateMode) {
    var _a, _b, _c, _d, _e, _f;
    if (bundle.nodes.length === 0 || bundle.placements.length === 0) {
      new import_obsidian.Notice((_a = bundle.warnings[0]) != null ? _a : "There is nothing available to place on Canvas.");
      return false;
    }
    const current = (_c = (_b = context.runtime).getData) == null ? void 0 : _c.call(_b);
    if (!current || typeof current !== "object" || !context.runtime.setData) {
      new import_obsidian.Notice("This Canvas runtime cannot accept placed items.");
      return false;
    }
    const document2 = this.parse(JSON.stringify(current));
    const linkedRoots = /* @__PURE__ */ new Map();
    for (const item of bundle.items) linkedRoots.set(item.id, this.linkedNodes(item, context.file.path).filter((id) => document2.nodes.some((node) => node.id === id)));
    const removedNodeIds = /* @__PURE__ */ new Set();
    if (duplicateMode === "replace") for (const ids of linkedRoots.values()) for (const node of this.expandGroupNodes(document2.nodes, ids)) removedNodeIds.add(node.id);
    if (this.bundleCollidesInDocument(document2, bundle, origin, removedNodeIds)) {
      new import_obsidian.Notice("Choose an empty Canvas area before placing this export.");
      return false;
    }
    const retainedNodeIds = new Set(document2.nodes.filter((node) => !removedNodeIds.has(node.id)).map((node) => node.id));
    const retainedEdgeIds = new Set(document2.edges.filter((edge) => !removedNodeIds.has(edge.fromNode) && !removedNodeIds.has(edge.toNode)).map((edge) => edge.id));
    if (bundle.nodes.some((node) => retainedNodeIds.has(node.id)) || bundle.edges.some((edge) => retainedEdgeIds.has(edge.id))) {
      new import_obsidian.Notice("Canvas changed while preparing this export. Start the placement again.");
      return false;
    }
    const placedNodes = bundle.nodes.map((node) => ({ ...node, x: node.x + origin.x, y: node.y + origin.y }));
    const next = {
      ...document2,
      nodes: [...document2.nodes.filter((node) => !removedNodeIds.has(node.id)), ...placedNodes],
      edges: [...document2.edges.filter((edge) => !removedNodeIds.has(edge.fromNode) && !removedNodeIds.has(edge.toNode)), ...bundle.edges]
    };
    try {
      await context.runtime.setData(next);
    } catch (error) {
      console.error("Canvas Palette failed to place an export bundle", error);
      new import_obsidian.Notice("Unable to place the export on Canvas.");
      return false;
    }
    const existingNodeIds = new Set(next.nodes.map((node) => node.id));
    for (const placement of bundle.placements) {
      const previous = (_d = linkedRoots.get(placement.itemId)) != null ? _d : [];
      if (duplicateMode === "replace" && previous.length > 0) this.onReplaced(placement.itemId, context.file.path, previous, placement.nodeIds, existingNodeIds);
      else this.onRestored(placement.itemId, context.file.path, placement.nodeIds);
    }
    this.restoreNodeMetadata(context.file.path, bundle.metadata);
    (_f = (_e = context.runtime).requestSave) == null ? void 0 : _f.call(_e);
    new import_obsidian.Notice(bundle.warnings.length > 0 ? `${bundle.placements.length} item${bundle.placements.length === 1 ? "" : "s"} placed with ${bundle.warnings.length} warning${bundle.warnings.length === 1 ? "" : "s"}.` : `${bundle.placements.length} item${bundle.placements.length === 1 ? "" : "s"} placed on Canvas.`);
    return true;
  }
  currentDocument(context) {
    var _a, _b;
    const current = (_b = (_a = context.runtime).getData) == null ? void 0 : _b.call(_a);
    return current && typeof current === "object" ? this.parse(JSON.stringify(current)) : { nodes: [], edges: [] };
  }
  emptyBundle() {
    return { nodes: [], edges: [], bounds: { x: 0, y: 0, width: 0, height: 0 }, placements: [], metadata: [], warnings: [], items: [] };
  }
  normalizeBundle(input) {
    if (input.nodes.length === 0) return { ...input, bounds: { x: 0, y: 0, width: 0, height: 0 } };
    const minX = Math.min(...input.nodes.map((node) => node.x));
    const minY = Math.min(...input.nodes.map((node) => node.y));
    const maxX = Math.max(...input.nodes.map((node) => node.x + node.width));
    const maxY = Math.max(...input.nodes.map((node) => node.y + node.height));
    return { ...input, nodes: input.nodes.map((node) => ({ ...node, x: node.x - minX, y: node.y - minY })), bounds: { x: 0, y: 0, width: maxX - minX, height: maxY - minY } };
  }
  bundleCollidesInDocument(document2, bundle, origin, ignoredNodeIds) {
    const left = origin.x;
    const top = origin.y;
    const right = left + bundle.bounds.width;
    const bottom = top + bundle.bounds.height;
    return document2.nodes.some((node) => !ignoredNodeIds.has(node.id) && left < node.x + node.width && right > node.x && top < node.y + node.height && bottom > node.y);
  }
  uniqueId(prefix, used) {
    let id = createId(prefix);
    while (used.has(id)) id = createId(prefix);
    used.add(id);
    return id;
  }
  async read(file) {
    return this.parse(await this.app.vault.cachedRead(file));
  }
  parse(raw) {
    try {
      const parsed = JSON.parse(raw);
      return { ...parsed, nodes: Array.isArray(parsed.nodes) ? parsed.nodes : [], edges: Array.isArray(parsed.edges) ? parsed.edges : [] };
    } catch (e) {
      return { nodes: [], edges: [] };
    }
  }
  runtimeSelectionIds(view) {
    var _a;
    const canvas = view.canvas;
    const candidate = (_a = canvas == null ? void 0 : canvas.selection) != null ? _a : canvas == null ? void 0 : canvas.selectedNodes;
    const values = candidate instanceof Set ? [...candidate] : Array.isArray(candidate) ? candidate : [];
    return values.map((value) => {
      const row = value;
      const data = row.data;
      const node = row.node;
      const nodeData = node == null ? void 0 : node.data;
      return typeof row.id === "string" ? row.id : typeof (data == null ? void 0 : data.id) === "string" ? data.id : typeof (node == null ? void 0 : node.id) === "string" ? node.id : typeof (nodeData == null ? void 0 : nodeData.id) === "string" ? nodeData.id : "";
    }).filter(Boolean);
  }
  runtimeNodeId(value) {
    const row = value;
    if (!row) return null;
    const data = row.data;
    const node = row.node;
    const nodeData = node == null ? void 0 : node.data;
    const id = typeof row.id === "string" ? row.id : typeof (data == null ? void 0 : data.id) === "string" ? data.id : typeof (node == null ? void 0 : node.id) === "string" ? node.id : typeof (nodeData == null ? void 0 : nodeData.id) === "string" ? nodeData.id : null;
    return id;
  }
  expandGroupNodes(nodes, selectedIds) {
    const ids = new Set(selectedIds);
    let changed = true;
    while (changed) {
      changed = false;
      for (const node of nodes) {
        if (ids.has(node.id)) continue;
        if (node.parentId && ids.has(node.parentId)) {
          ids.add(node.id);
          changed = true;
          continue;
        }
        const enclosingGroup = nodes.find((group) => ids.has(group.id) && group.type === "group" && this.isInside(node, group));
        if (enclosingGroup) {
          ids.add(node.id);
          changed = true;
        }
      }
    }
    return nodes.filter((node) => ids.has(node.id));
  }
  isInside(node, group) {
    return node.x >= group.x && node.y >= group.y && node.x + node.width <= group.x + group.width && node.y + node.height <= group.y + group.height;
  }
};

// src/canvas/export-placement-controller.ts
var import_obsidian2 = require("obsidian");
var ExportPlacementController = class {
  constructor(adapter) {
    this.adapter = adapter;
    __publicField(this, "session", null);
    __publicField(this, "onMove", (event) => this.update(event.clientX, event.clientY));
    __publicField(this, "onKey", (event) => {
      if (event.key === "Escape") {
        event.preventDefault();
        this.cancel();
      }
    });
    __publicField(this, "onDown", (event) => {
      if (event.button === 0) void this.place(event);
    });
  }
  start(context, bundle, mode) {
    var _a;
    this.cancel();
    const document2 = (_a = context.view.containerEl) == null ? void 0 : _a.ownerDocument;
    if (!document2 || !context.view.containerEl) {
      new import_obsidian2.Notice("Unable to show the Canvas placement preview.");
      return;
    }
    const overlay = document2.body.createDiv({ cls: "cp-export-placement" });
    overlay.setAttribute("aria-hidden", "true");
    this.session = { context, bundle, mode, overlay, lastClient: null };
    this.render(overlay, bundle);
    document2.addEventListener("pointermove", this.onMove, true);
    document2.addEventListener("pointerdown", this.onDown, true);
    document2.addEventListener("keydown", this.onKey, true);
    new import_obsidian2.Notice("Move to an empty Canvas area and click to place. Press Escape to cancel.");
  }
  cancel() {
    const session = this.session;
    if (!session) return;
    const document2 = session.overlay.ownerDocument;
    document2.removeEventListener("pointermove", this.onMove, true);
    document2.removeEventListener("pointerdown", this.onDown, true);
    document2.removeEventListener("keydown", this.onKey, true);
    session.overlay.remove();
    this.session = null;
  }
  isFor(context) {
    return Boolean(this.session && context && this.session.context.file.path === context.file.path);
  }
  update(clientX, clientY) {
    var _a, _b, _c, _d, _e, _f;
    const session = this.session;
    if (!session || !((_b = session.context.view.containerEl) == null ? void 0 : _b.contains((_a = session.overlay.ownerDocument.elementFromPoint(clientX, clientY)) != null ? _a : null))) return;
    const point = (_d = (_c = session.context.runtime).posFromClient) == null ? void 0 : _d.call(_c, { x: clientX, y: clientY });
    if (!point) return;
    const probe = (_f = (_e = session.context.runtime).posFromClient) == null ? void 0 : _f.call(_e, { x: clientX + 20, y: clientY + 20 });
    const scaleX = probe && Math.abs(probe.x - point.x) > 1e-3 ? 20 / Math.abs(probe.x - point.x) : 1;
    const scaleY = probe && Math.abs(probe.y - point.y) > 1e-3 ? 20 / Math.abs(probe.y - point.y) : scaleX;
    session.lastClient = { x: clientX, y: clientY };
    session.overlay.style.left = `${clientX}px`;
    session.overlay.style.top = `${clientY}px`;
    session.overlay.style.transform = `scale(${scaleX}, ${scaleY})`;
    const collision = this.adapter.bundleCollides(session.context, session.bundle, point, this.ignoredNodeIds(session));
    session.overlay.toggleClass("is-collision", collision);
  }
  async place(event) {
    var _a, _b, _c;
    const session = this.session;
    if (!session || !((_a = session.context.view.containerEl) == null ? void 0 : _a.contains(event.target))) return;
    const point = (_c = (_b = session.context.runtime).posFromClient) == null ? void 0 : _c.call(_b, { x: event.clientX, y: event.clientY });
    if (!point || this.adapter.bundleCollides(session.context, session.bundle, point, this.ignoredNodeIds(session))) {
      new import_obsidian2.Notice("That location overlaps an existing Canvas item.");
      return;
    }
    event.preventDefault();
    event.stopPropagation();
    const committed = await this.adapter.commitBundle(session.context, session.bundle, point, session.mode);
    if (committed) this.cancel();
  }
  ignoredNodeIds(session) {
    return session.mode === "replace" ? this.adapter.bundleDuplicateNodeIds(session.bundle, session.context) : /* @__PURE__ */ new Set();
  }
  render(overlay, bundle) {
    var _a, _b, _c, _d;
    overlay.empty();
    overlay.style.width = `${bundle.bounds.width}px`;
    overlay.style.height = `${bundle.bounds.height}px`;
    overlay.createDiv({ cls: "cp-export-placement__bounds" });
    const byId = new Map(bundle.nodes.map((node) => [node.id, node]));
    const svg = overlay.createSvg("svg", { cls: "cp-export-placement__edges", attr: { viewBox: `0 0 ${bundle.bounds.width} ${bundle.bounds.height}`, width: String(bundle.bounds.width), height: String(bundle.bounds.height) } });
    for (const edge of bundle.edges) {
      const from = byId.get(edge.fromNode);
      const to = byId.get(edge.toNode);
      if (!from || !to) continue;
      svg.createSvg("line", { attr: { x1: String(from.x + from.width), y1: String(from.y + from.height / 2), x2: String(to.x), y2: String(to.y + to.height / 2) } });
    }
    for (const node of bundle.nodes) {
      const outline = overlay.createDiv({ cls: `cp-export-placement__node cp-export-placement__node--${node.type}` });
      outline.style.left = `${node.x}px`;
      outline.style.top = `${node.y}px`;
      outline.style.width = `${node.width}px`;
      outline.style.height = `${node.height}px`;
      outline.setText(node.type === "text" ? ((_a = node.text) != null ? _a : "Card").slice(0, 60) : node.type === "group" ? (_b = node.label) != null ? _b : "Group" : (_d = (_c = node.file) == null ? void 0 : _c.split("/").at(-1)) != null ? _d : "File");
    }
  }
};

// src/core/canvas-node-presence.ts
function mergeCanvasNodeIds(savedNodeIds, openNodeIds) {
  return /* @__PURE__ */ new Set([...savedNodeIds, ...openNodeIds]);
}

// src/canvas/canvas-metadata-controller.ts
var import_obsidian4 = require("obsidian");

// src/editor/native-markdown-editor.ts
var import_obsidian3 = require("obsidian");
var NativeMarkdownEditor = class {
  constructor(app, target) {
    this.app = app;
    this.target = target;
    __publicField(this, "split", null);
    __publicField(this, "leaf", null);
    __publicField(this, "view", null);
  }
  async mount(containerEl, activateLeaf = true) {
    const Split = import_obsidian3.WorkspaceSplit;
    const split = new Split(this.app.workspace, "vertical");
    split.getRoot = () => this.app.workspace.rootSplit;
    split.getContainer = () => this.app.workspace.rootSplit.getContainer();
    containerEl.appendChild(split.containerEl);
    this.split = split;
    const leaf = this.app.workspace.createLeafInParent(split, 0);
    this.leaf = leaf;
    if (this.target.kind === "file" && this.target.file) {
      await leaf.openFile(this.target.file, {
        active: true,
        state: { mode: "source", source: false },
        eState: { focus: true }
      });
      await leaf.loadIfDeferred();
      if (!(leaf.view instanceof import_obsidian3.MarkdownView)) throw new Error("Could not open the Markdown editor.");
      this.view = leaf.view;
    } else {
      const view = new import_obsidian3.MarkdownView(leaf);
      await leaf.open(view);
      view.setViewData(this.target.initialText, true);
      this.view = view;
    }
    if (activateLeaf) this.app.workspace.setActiveLeaf(leaf, { focus: true });
    this.remeasure();
    if (!activateLeaf) window.requestAnimationFrame(() => {
      var _a;
      return (_a = containerEl.querySelector(".cm-content")) == null ? void 0 : _a.focus();
    });
  }
  getText() {
    var _a, _b;
    return (_b = (_a = this.view) == null ? void 0 : _a.getViewData()) != null ? _b : this.target.initialText;
  }
  async saveFile() {
    var _a;
    if (this.target.kind === "file") await ((_a = this.view) == null ? void 0 : _a.save());
  }
  remeasure() {
    var _a, _b, _c;
    (_c = (_b = (_a = this.view) == null ? void 0 : _a.editMode) == null ? void 0 : _b.reinit) == null ? void 0 : _c.call(_b);
  }
  detach() {
    var _a, _b;
    (_a = this.leaf) == null ? void 0 : _a.detach();
    this.leaf = null;
    this.view = null;
    (_b = this.split) == null ? void 0 : _b.containerEl.remove();
    this.split = null;
  }
};

// src/canvas/canvas-metadata-controller.ts
var CanvasMetadataController = class {
  constructor(plugin, adapter) {
    this.plugin = plugin;
    this.adapter = adapter;
    __publicField(this, "timer", null);
    __publicField(this, "nodesByElement", /* @__PURE__ */ new WeakMap());
    __publicField(this, "activeEditors", /* @__PURE__ */ new WeakSet());
    __publicField(this, "activeBackEditor", null);
    __publicField(this, "resizeObserver", new ResizeObserver((entries) => {
      for (const entry of entries) {
        const node = this.nodesByElement.get(entry.target);
        if (node) this.updateScale(node);
      }
    }));
  }
  refreshSoon() {
    if (this.timer !== null) window.clearTimeout(this.timer);
    this.timer = window.setTimeout(() => {
      this.timer = null;
      this.refresh();
    }, 60);
  }
  refresh() {
    for (const context of this.adapter.openContexts()) {
      const nodes = context.runtime.nodes;
      if (!(nodes instanceof Map)) continue;
      for (const [nodeId, node] of nodes) this.decorate(node, context.file.path, nodeId, this.plugin.store.getCanvasNodeMetadata(context.file.path, nodeId));
    }
  }
  destroy() {
    var _a;
    if (this.timer !== null) window.clearTimeout(this.timer);
    this.resizeObserver.disconnect();
    void ((_a = this.activeBackEditor) == null ? void 0 : _a.close(true));
    for (const context of this.adapter.openContexts()) {
      const nodes = context.runtime.nodes;
      if (!(nodes instanceof Map)) continue;
      for (const node of nodes.values()) this.remove(node);
    }
  }
  decorate(node, canvasPath, nodeId, metadata) {
    var _a, _b, _c;
    const nodeEl = node.nodeEl;
    if (!(nodeEl instanceof HTMLElement)) return;
    if (((_a = this.activeBackEditor) == null ? void 0 : _a.nodeEl) === nodeEl) return;
    const activeEditor = nodeEl.querySelector(":scope > .cp-canvas-metadata .cp-canvas-metadata__editor");
    if (activeEditor && this.activeEditors.has(activeEditor)) return;
    this.remove(node);
    const state = metadata != null ? metadata : { tags: [], label: "", labelColor: "", caption: "", backContent: "", currentFace: "front", facesEnabled: false, modifiedAt: Date.now() };
    const supportsFaces = this.adapter.supportsFrontBack(node);
    const linked = Boolean(this.plugin.store.linkedItemForNode(canvasPath, nodeId));
    const data = (_b = node.getData) == null ? void 0 : _b.call(node);
    const type = (_c = data == null ? void 0 : data.type) != null ? _c : "unknown";
    nodeEl.addClass("cp-canvas-has-metadata", `cp-canvas-has-metadata--${type}`);
    if (linked) nodeEl.addClass("cp-canvas-linked");
    const layer = nodeEl.createDiv({ cls: `cp-canvas-metadata cp-canvas-metadata--${type}`, attr: { "aria-label": "Canvas Palette metadata" } });
    if (linked) {
      const linkBadge = layer.createEl("button", { cls: "clickable-icon cp-canvas-link-badge", attr: { type: "button", "aria-label": "Show linked item in Side Palette", title: "Show linked item in Side Palette" } });
      (0, import_obsidian4.setIcon)(linkBadge, "link-2");
      linkBadge.addEventListener("pointerdown", (event) => event.stopPropagation());
      linkBadge.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        void this.plugin.revealPaletteItemForCanvasNode(canvasPath, nodeId);
      });
      linkBadge.addEventListener("dblclick", (event) => {
        event.preventDefault();
        event.stopPropagation();
      });
    }
    if (supportsFaces && state.facesEnabled) {
      const flip = layer.createEl("button", { cls: "clickable-icon cp-canvas-face-toggle", attr: { type: "button", "aria-label": state.currentFace === "front" ? "Show back" : "Show front", title: state.currentFace === "front" ? "Show back" : "Show front" } });
      (0, import_obsidian4.setIcon)(flip, "refresh-cw");
      flip.addEventListener("pointerdown", (event) => event.stopPropagation());
      flip.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        this.plugin.store.setCanvasNodeFace(canvasPath, nodeId, state.currentFace === "front" ? "back" : "front");
      });
    }
    if (supportsFaces && state.facesEnabled && state.currentFace === "back") {
      nodeEl.addClass("cp-canvas-showing-back");
      const back = layer.createDiv({ cls: "cp-canvas-back markdown-rendered", attr: { title: "Double-click to edit the back" } });
      void import_obsidian4.MarkdownRenderer.render(this.plugin.app, state.backContent, back, canvasPath, this.plugin).then(() => {
        if (!state.backContent && !back.hasClass("is-editing")) back.createDiv({ cls: "cp-empty", text: "Write on the back\u2026" });
      });
      back.addEventListener("pointerdown", (event) => {
        if (back.hasClass("is-editing") || !this.adapter.beginBackDrag(node, event)) return;
        event.preventDefault();
        event.stopPropagation();
      });
      back.addEventListener("dblclick", (event) => {
        var _a2, _b2, _c2;
        event.preventDefault();
        event.stopPropagation();
        void this.openInlineBackEditor(back, nodeEl, canvasPath, nodeId, state.backContent, (_c2 = (_b2 = data == null ? void 0 : data.label) != null ? _b2 : (_a2 = data == null ? void 0 : data.text) == null ? void 0 : _a2.split(/\r?\n/, 1)[0]) != null ? _c2 : "Canvas node");
      });
    }
    if (state.label) {
      const header = layer.createDiv({ cls: "cp-canvas-metadata__header" });
      const label = header.createDiv({ cls: "cp-canvas-metadata__label", text: state.label });
      if (state.labelColor) label.style.setProperty("--cp-label-color", state.labelColor);
      this.makeInlineEditable(label, "Edit label", state.label, (value) => {
        this.saveMetadata(canvasPath, nodeId, { label: value });
      });
    }
    if (state.tags.length > 0 || state.label || state.caption) {
      const footer = layer.createDiv({ cls: "cp-canvas-metadata__footer" });
      const tags = footer.createDiv({ cls: "cp-canvas-metadata__tags" });
      for (const [index, tag] of state.tags.entries()) {
        const tagEl = tags.createSpan({ cls: "cp-canvas-metadata__tag", text: `#${tag}` });
        this.makeInlineEditable(tagEl, "Edit tag", tag, (value) => {
          const current = this.plugin.store.getCanvasNodeMetadata(canvasPath, nodeId);
          if (!current) return;
          const nextTags = [...current.tags];
          const normalized = value.trim().replace(/^#/, "");
          if (normalized) nextTags[index] = normalized;
          else nextTags.splice(index, 1);
          this.saveMetadata(canvasPath, nodeId, { tags: [...new Set(nextTags)] });
        });
      }
      footer.createDiv({ cls: "cp-canvas-metadata__date", text: new Date(state.modifiedAt).toLocaleDateString() });
    }
    if (state.caption) {
      const caption = layer.createDiv({ cls: "cp-canvas-metadata__caption", text: state.caption });
      this.makeInlineEditable(caption, "Edit caption", state.caption, (value) => {
        this.saveMetadata(canvasPath, nodeId, { caption: value });
      });
    }
    this.nodesByElement.set(nodeEl, node);
    this.resizeObserver.observe(nodeEl);
    this.updateScale(node);
  }
  async openInlineBackEditor(back, nodeEl, canvasPath, nodeId, initialText, title) {
    var _a, _b;
    if (((_a = this.activeBackEditor) == null ? void 0 : _a.nodeEl) === nodeEl) return;
    await ((_b = this.activeBackEditor) == null ? void 0 : _b.close(true));
    back.empty();
    back.addClass("is-editing");
    const host = back.createDiv({ cls: "cp-canvas-back-editor cp-native-editor-host", attr: { "aria-label": `Edit ${title} back` } });
    const editor = new NativeMarkdownEditor(this.plugin.app, { itemId: `${canvasPath}:${nodeId}`, kind: "card", file: null, title: `${title} \u2014 Back`, initialText });
    let finishing = false;
    const doc = back.ownerDocument;
    const onOutsidePointer = (event) => {
      if (!back.contains(event.target)) void close(true);
    };
    const onKeyDown = (event) => {
      event.stopPropagation();
      if (event.key === "Escape") {
        event.preventDefault();
        void close(true);
      } else if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s") {
        event.preventDefault();
        this.plugin.store.setCanvasNodeBack(canvasPath, nodeId, editor.getText());
      }
    };
    const close = async (save) => {
      var _a2;
      if (finishing) return;
      finishing = true;
      doc.removeEventListener("pointerdown", onOutsidePointer, true);
      host.removeEventListener("keydown", onKeyDown, true);
      const text = editor.getText();
      editor.detach();
      if (((_a2 = this.activeBackEditor) == null ? void 0 : _a2.nodeEl) === nodeEl) this.activeBackEditor = null;
      if (save) this.plugin.store.setCanvasNodeBack(canvasPath, nodeId, text);
      else this.refreshSoon();
    };
    this.activeBackEditor = { nodeEl, close };
    host.addEventListener("pointerdown", (event) => event.stopPropagation());
    host.addEventListener("dblclick", (event) => event.stopPropagation());
    host.addEventListener("keydown", onKeyDown, true);
    try {
      await editor.mount(host, false);
      window.requestAnimationFrame(() => editor.remeasure());
      window.setTimeout(() => doc.addEventListener("pointerdown", onOutsidePointer, true), 0);
    } catch (error) {
      await close(false);
      console.error("Canvas Palette could not mount the inline Back editor", error);
    }
  }
  makeInlineEditable(element, label, value, onCommit) {
    element.setAttribute("title", `${label} (double-click)`);
    element.addEventListener("pointerdown", (event) => event.stopPropagation());
    element.addEventListener("click", (event) => event.stopPropagation());
    element.addEventListener("dblclick", (event) => {
      var _a;
      event.preventDefault();
      event.stopPropagation();
      if ((_a = element.closest(".cp-canvas-metadata")) == null ? void 0 : _a.querySelector(".cp-canvas-metadata__editor")) return;
      const editor = document.createElement("input");
      editor.type = "text";
      editor.className = `cp-canvas-metadata__editor ${element.className}`;
      this.activeEditors.add(editor);
      editor.value = value;
      editor.setAttribute("aria-label", label);
      editor.setAttribute("title", "Enter or focus out to save; Escape to cancel");
      if (element.style.getPropertyValue("--cp-label-color")) {
        editor.style.setProperty("--cp-label-color", element.style.getPropertyValue("--cp-label-color"));
      }
      element.replaceWith(editor);
      let finished = false;
      const finish = (save) => {
        if (finished) return;
        finished = true;
        editor.classList.remove("cp-canvas-metadata__editor");
        editor.disabled = true;
        if (save) onCommit(editor.value.trim());
        else this.refreshSoon();
      };
      editor.addEventListener("pointerdown", (inputEvent) => inputEvent.stopPropagation());
      editor.addEventListener("click", (inputEvent) => inputEvent.stopPropagation());
      editor.addEventListener("dblclick", (inputEvent) => inputEvent.stopPropagation());
      editor.addEventListener("keydown", (inputEvent) => {
        inputEvent.stopPropagation();
        if (inputEvent.isComposing) return;
        if (inputEvent.key === "Enter") {
          inputEvent.preventDefault();
          finish(true);
          editor.blur();
        } else if (inputEvent.key === "Escape") {
          inputEvent.preventDefault();
          finish(false);
        }
      });
      editor.addEventListener("blur", () => finish(true));
      window.requestAnimationFrame(() => {
        editor.focus();
        editor.select();
      });
    });
  }
  saveMetadata(canvasPath, nodeId, changes) {
    var _a, _b, _c, _d;
    const current = this.plugin.store.getCanvasNodeMetadata(canvasPath, nodeId);
    if (!current) {
      this.refreshSoon();
      return;
    }
    this.plugin.store.setCanvasNodeMetadata(canvasPath, nodeId, {
      tags: (_a = changes.tags) != null ? _a : current.tags,
      label: (_b = changes.label) != null ? _b : current.label,
      labelColor: ((_c = changes.label) != null ? _c : current.label) ? current.labelColor : "",
      caption: (_d = changes.caption) != null ? _d : current.caption
    });
  }
  remove(node) {
    var _a;
    const nodeEl = node.nodeEl;
    if (!(nodeEl instanceof HTMLElement)) return;
    this.resizeObserver.unobserve(nodeEl);
    nodeEl.removeClass("cp-canvas-has-metadata", "cp-canvas-has-metadata--text", "cp-canvas-has-metadata--file", "cp-canvas-has-metadata--group", "cp-canvas-has-metadata--unknown");
    nodeEl.removeClass("cp-canvas-showing-back", "cp-canvas-linked");
    (_a = nodeEl.querySelector(":scope > .cp-canvas-metadata")) == null ? void 0 : _a.remove();
    nodeEl.style.removeProperty("--cp-canvas-meta-scale");
  }
  updateScale(node) {
    var _a;
    const nodeEl = node.nodeEl;
    const data = (_a = node.getData) == null ? void 0 : _a.call(node);
    if (!(nodeEl instanceof HTMLElement) || !data) return;
    const widthScale = Math.max(data.width, 1) / 400;
    const heightScale = Math.max(data.height, 1) / 300;
    const scale = Math.min(2.5, Math.max(0.75, Math.min(widthScale, heightScale)));
    nodeEl.style.setProperty("--cp-canvas-meta-scale", scale.toFixed(3));
  }
};

// src/canvas/canvas-node-toolbar-controller.ts
var import_obsidian5 = require("obsidian");
var CanvasNodeToolbarController = class {
  constructor(adapter, actions) {
    this.adapter = adapter;
    this.actions = actions;
    __publicField(this, "frame", null);
    __publicField(this, "observers", /* @__PURE__ */ new Map());
    __publicField(this, "document", null);
    __publicField(this, "schedule", () => this.refreshSoon());
  }
  mount(document2) {
    this.document = document2;
    document2.addEventListener("pointerup", this.schedule, true);
    document2.addEventListener("keyup", this.schedule, true);
    this.refreshSoon();
    return () => this.destroy();
  }
  refreshSoon() {
    if (this.frame !== null) return;
    this.frame = window.requestAnimationFrame(() => {
      this.frame = null;
      this.refresh();
    });
  }
  refresh() {
    var _a;
    const activeMenus = /* @__PURE__ */ new Set();
    for (const context of this.adapter.openContexts()) {
      const menuEl = (_a = context.runtime.menu) == null ? void 0 : _a.menuEl;
      if (!(menuEl instanceof HTMLElement)) continue;
      activeMenus.add(menuEl);
      this.observe(menuEl);
      this.decorate(context);
    }
    for (const [menuEl, observer] of this.observers) {
      if (activeMenus.has(menuEl)) continue;
      observer.disconnect();
      this.observers.delete(menuEl);
    }
  }
  destroy() {
    var _a, _b;
    if (this.frame !== null) window.cancelAnimationFrame(this.frame);
    this.frame = null;
    (_a = this.document) == null ? void 0 : _a.removeEventListener("pointerup", this.schedule, true);
    (_b = this.document) == null ? void 0 : _b.removeEventListener("keyup", this.schedule, true);
    this.document = null;
    for (const observer of this.observers.values()) observer.disconnect();
    this.observers.clear();
    for (const context of this.adapter.openContexts()) this.remove(context);
  }
  observe(menuEl) {
    if (this.observers.has(menuEl)) return;
    const observer = new MutationObserver(() => this.refreshSoon());
    observer.observe(menuEl, { childList: true });
    this.observers.set(menuEl, observer);
  }
  decorate(context) {
    var _a;
    const runtime = context.runtime;
    const menuEl = (_a = runtime.menu) == null ? void 0 : _a.menuEl;
    if (!(menuEl instanceof HTMLElement)) return;
    const selection = runtime.selection instanceof Set ? [...runtime.selection] : [];
    const nodes = selection.filter((node) => Boolean(this.nodeId(node)));
    const singleNodeId = nodes.length === 1 ? this.nodeId(nodes[0]) : "";
    const supportsFaces = nodes.length === 1 && this.actions.supportsFaces(nodes[0]);
    const facesEnabled = singleNodeId && supportsFaces ? this.actions.facesEnabled(context.file.path, singleNodeId) : false;
    const linked = singleNodeId ? this.actions.isLinked(context.file.path, singleNodeId) : false;
    const selectionKey = `${nodes.map((node) => this.nodeId(node)).sort().join("|")}:${supportsFaces ? "eligible" : "excluded"}:${facesEnabled ? "faces" : "plain"}:${linked ? "linked" : "local"}`;
    const currentButtons = menuEl.querySelectorAll(":scope > .cp-canvas-toolbar-action");
    const separator = menuEl.querySelector(":scope > .cp-canvas-toolbar-separator");
    const expectedButtons = 3 + (singleNodeId && supportsFaces ? 1 : 0) + (linked ? 1 : 0);
    if (nodes.length === 0) {
      this.clear(menuEl);
      return;
    }
    if (menuEl.dataset.cpToolbarSelectionKey === selectionKey && currentButtons.length === expectedButtons && separator) return;
    this.clear(menuEl);
    menuEl.dataset.cpToolbarSelectionKey = selectionKey;
    menuEl.createSpan({ cls: "cp-canvas-toolbar-separator", attr: { "aria-hidden": "true" } });
    this.button(menuEl, "tags", "Edit Palette Metadata", () => this.actions.editMetadata(nodes));
    this.button(menuEl, "inbox", "Collect to Mini Palette", () => this.actions.collectToMini());
    this.button(menuEl, "panel-right", "Save directly to Side Palette", (button) => this.actions.saveToSide(button));
    if (singleNodeId && supportsFaces && !facesEnabled) this.button(menuEl, "refresh-cw", "Enable Front / Back", () => this.actions.enableFaces(context.file.path, singleNodeId));
    if (singleNodeId && supportsFaces && facesEnabled) this.button(menuEl, "circle-off", "Remove Front / Back", () => this.actions.disableFaces(context.file.path, singleNodeId));
    if (linked) this.button(menuEl, "unlink", "Unlink from Palette", () => this.actions.unlink(context.file.path, singleNodeId));
  }
  remove(context) {
    var _a;
    const menuEl = (_a = context.runtime.menu) == null ? void 0 : _a.menuEl;
    if (menuEl instanceof HTMLElement) this.clear(menuEl);
  }
  clear(menuEl) {
    var _a;
    (_a = menuEl.querySelector(":scope > .cp-canvas-toolbar-separator")) == null ? void 0 : _a.remove();
    for (const button of Array.from(menuEl.querySelectorAll(":scope > .cp-canvas-toolbar-action"))) button.remove();
    delete menuEl.dataset.cpToolbarNodeId;
    delete menuEl.dataset.cpToolbarSelectionKey;
  }
  button(parent, icon, label, action) {
    const button = parent.createEl("button", { cls: "clickable-icon cp-canvas-toolbar-action", attr: { "aria-label": label, "data-tooltip-position": "top", type: "button" } });
    (0, import_obsidian5.setIcon)(button, icon);
    button.addEventListener("pointerdown", (event) => event.stopPropagation());
    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      action(button);
    });
  }
  nodeId(node) {
    var _a;
    if (typeof node.id === "string") return node.id;
    const data = (_a = node.getData) == null ? void 0 : _a.call(node);
    return typeof (data == null ? void 0 : data.id) === "string" ? data.id : "";
  }
};

// src/canvas/palette-drop-controller.ts
var ITEM_MIME = "application/x-canvas-palette-item";
var TYPE_MIME = "application/x-canvas-palette-type";
var ITEMS_MIME = "application/x-canvas-palette-items";
var MINI_COLLECT_MIME = "application/x-canvas-palette-mini-collect";
var PaletteDropController = class {
  constructor(store, canvas) {
    this.store = store;
    this.canvas = canvas;
    __publicField(this, "onDragOver", (event) => {
      var _a;
      if (!((_a = event.dataTransfer) == null ? void 0 : _a.types.includes(ITEM_MIME)) || !this.canvas.contextForTarget(event.target)) return;
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      event.dataTransfer.dropEffect = "copy";
    });
    __publicField(this, "onDrop", (event) => {
      var _a;
      if (!((_a = event.dataTransfer) == null ? void 0 : _a.types.includes(ITEM_MIME)) || !this.canvas.contextForTarget(event.target)) return;
      const itemId = event.dataTransfer.getData(ITEM_MIME);
      const item = this.store.data.items[itemId];
      if (!item) return;
      const declaredType = event.dataTransfer.getData(TYPE_MIME);
      if (declaredType && declaredType !== item.type) console.warn(`Canvas Palette drag type mismatch: ${declaredType} != ${item.type}`);
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      let itemIds = [itemId];
      try {
        const parsed = JSON.parse(event.dataTransfer.getData(ITEMS_MIME));
        if (Array.isArray(parsed)) itemIds = parsed.filter((id) => typeof id === "string" && Boolean(this.store.data.items[id]));
      } catch (e) {
      }
      const items = itemIds.map((id) => this.store.data.items[id]).filter((candidate) => Boolean(candidate));
      const removeFromCollect = event.dataTransfer.getData(MINI_COLLECT_MIME) === "true";
      void this.canvas.restoreItemsFromDrop(items, event).then((restored) => {
        if (restored && removeFromCollect) this.store.completePendingCanvasPlacement(items.map((item2) => item2.id));
      });
    });
  }
  mount(document2) {
    document2.addEventListener("dragover", this.onDragOver, true);
    document2.addEventListener("drop", this.onDrop, true);
    return () => {
      document2.removeEventListener("dragover", this.onDragOver, true);
      document2.removeEventListener("drop", this.onDrop, true);
    };
  }
};

// src/canvas/text-scrap-highlights.ts
var import_view = require("@codemirror/view");
var import_state = require("@codemirror/state");
var refreshHighlights = import_state.StateEffect.define();
var TextScrapHighlights = class {
  constructor(plugin) {
    this.plugin = plugin;
  }
  extension() {
    const plugin = this.plugin;
    return import_view.ViewPlugin.fromClass(class {
      constructor(view) {
        __publicField(this, "decorations");
        this.decorations = buildDecorations(view, plugin);
      }
      update(update) {
        if (update.docChanged || update.transactions.some((transaction) => transaction.effects.some((effect) => effect.is(refreshHighlights)))) this.decorations = buildDecorations(update.view, plugin);
      }
    }, {
      decorations: (value) => value.decorations,
      eventHandlers: {
        click(event) {
          const target = event.target;
          if (!(target instanceof HTMLElement)) return false;
          const marker = target.closest("[data-canvas-palette-item]");
          const itemId = marker == null ? void 0 : marker.dataset.canvasPaletteItem;
          if (!itemId) return false;
          plugin.selectItem(itemId);
          void plugin.openSidePalette();
          return true;
        }
      }
    }).extension;
  }
  refreshVisibleEditors() {
    var _a, _b, _c;
    for (const leaf of this.plugin.app.workspace.getLeavesOfType("markdown")) {
      const view = leaf.view;
      if ((_a = view.containerEl) == null ? void 0 : _a.closest(".cp-native-editor-host")) continue;
      try {
        (_c = (_b = view.editor) == null ? void 0 : _b.cm) == null ? void 0 : _c.dispatch({ effects: refreshHighlights.of() });
      } catch (error) {
        console.warn("Canvas Palette skipped an incompatible Markdown editor while refreshing text highlights", error);
      }
    }
  }
};
function buildDecorations(view, plugin) {
  const builder = [];
  const text = view.state.doc.toString();
  for (const item of plugin.store.allItems()) {
    if (item.type !== "card" || !item.origin.textRange || !item.content) continue;
    const from = positionToOffset(view, item.origin.textRange.from.line, item.origin.textRange.from.ch, item.content, text);
    if (from < 0) continue;
    const to = Math.min(view.state.doc.length, from + item.content.length);
    builder.push({ from, to, decoration: import_view.Decoration.mark({ class: "cp-text-scrap-highlight", attributes: { "data-canvas-palette-item": item.id, title: "Open linked Canvas Palette card" } }) });
  }
  builder.sort((a, b) => a.from - b.from || a.to - b.to);
  return import_view.Decoration.set(builder.map((entry) => entry.decoration.range(entry.from, entry.to)), true);
}
function positionToOffset(view, line, ch, content, text) {
  if (line >= 0 && line < view.state.doc.lines) {
    const row = view.state.doc.line(line + 1);
    const candidate = Math.min(row.to, row.from + Math.max(0, ch));
    if (text.slice(candidate, candidate + content.length) === content) return candidate;
  }
  return text.indexOf(content);
}

// src/ui/asset-density.ts
var ASSET_DENSITY_MIN = 0;
var ASSET_DENSITY_MAX = 6;
var ASSET_DENSITY_DEFAULT = 4;
var STEPS = [
  { label: "Details", minWidth: 0, height: 96 },
  { label: "Extra small", minWidth: 116, height: 112 },
  { label: "Small", minWidth: 148, height: 144 },
  { label: "Compact", minWidth: 180, height: 178 },
  { label: "Medium", minWidth: 220, height: 220 },
  { label: "Large", minWidth: 268, height: 270 },
  { label: "Extra large", minWidth: 320, height: 320 }
];
function clampAssetDensity(value) {
  return Math.max(ASSET_DENSITY_MIN, Math.min(ASSET_DENSITY_MAX, Math.round(value != null ? value : ASSET_DENSITY_DEFAULT)));
}
function assetDensityLabel(value) {
  return STEPS[clampAssetDensity(value)].label;
}
function assetViewMode(value) {
  return clampAssetDensity(value) === 0 ? "list" : "grid";
}
function nextAssetDensity(value, deltaY) {
  return deltaY === 0 ? clampAssetDensity(value) : clampAssetDensity(value + (deltaY < 0 ? 1 : -1));
}
function legacyDensity(viewMode, cardHeight) {
  if (viewMode === "list") return 0;
  const height = cardHeight != null ? cardHeight : STEPS[ASSET_DENSITY_DEFAULT].height;
  let closest = 1;
  for (let index = 2; index < STEPS.length; index += 1) {
    if (Math.abs(STEPS[index].height - height) < Math.abs(STEPS[closest].height - height)) closest = index;
  }
  return closest;
}
function applyAssetDensity(element, value, prefix) {
  const density = clampAssetDensity(value);
  const step = STEPS[density];
  element.classList.remove(`${prefix}--grid`, `${prefix}--list`);
  element.classList.add(`${prefix}--${assetViewMode(density)}`);
  element.dataset.density = String(density);
  element.style.setProperty("--cp-density-card-width", `${step.minWidth}px`);
  element.style.setProperty("--cp-density-card-height", `${step.height}px`);
  return density;
}

// src/core/defaults.ts
var DEFAULT_SIDE_LAYOUT = {
  viewportRatio: 0.52,
  topRatio: 0.69,
  indexRatio: 0.5,
  viewMode: "grid",
  densityLevel: ASSET_DENSITY_DEFAULT,
  responsiveTab: "viewport",
  selectedCollectionId: null,
  focusedCollectionId: null,
  collapsedCollectionIds: [],
  collapsedItemIds: [],
  outlinerItemHeight: 30,
  outlinerFontSize: 13,
  outlinerIncludeDescendants: true,
  outlinerWrapTitles: false
};
var DEFAULT_DATA = {
  schemaVersion: 22,
  settings: { theme: "obsidian", accentMode: "obsidian", accentColor: "#7c3aed", labelColorPresets: [], cardHeight: 220, fontSize: 14, columns: 4 },
  items: {},
  workspaces: {},
  collections: {},
  pendingItemIds: [],
  canvasNodeMetadata: {},
  uiState: { activeWorkspaceId: null, lastCanvasPath: null, selectedItemId: null, sideSelectedItemIds: [], sideItemFaces: {}, miniItemFaces: {}, quickEditor: { x: null, y: null, width: null, height: null }, workspaceExplorer: { viewMode: "details", sort: "modified-desc" }, miniPalette: {
    tab: "collect",
    storageItemIds: [],
    isOpen: false,
    position: { x: 24, y: 62 },
    size: { width: 1120, height: 720 },
    leftPaneOpen: true,
    rightPaneOpen: true,
    leftPaneWidth: 248,
    rightPaneWidth: 310,
    viewMode: "grid",
    densityLevel: ASSET_DENSITY_DEFAULT,
    cardHeight: 220,
    sort: "modified-desc",
    collectSelectedItemIds: [],
    collectSelectionAnchorId: null,
    storageSelectedItemIds: [],
    storageSelectionAnchorId: null,
    focusedItemId: null,
    selectedItemIds: []
  } }
};
function migrateData(raw) {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _A, _B, _C, _D, _E, _F, _G, _H, _I, _J, _K, _L, _M, _N, _O, _P, _Q, _R, _S, _T, _U, _V;
  if (!raw) return structuredClone(DEFAULT_DATA);
  const rawSettings = raw.settings;
  const { cardSize: _legacyCardSize, ...migratedSettings } = rawSettings != null ? rawSettings : {};
  const legacyUi = (_a = raw.uiState) != null ? _a : {};
  const migratedAt = Date.now();
  const workspaces = Object.fromEntries(Object.entries((_b = raw.workspaces) != null ? _b : {}).map(([id, workspace]) => {
    var _a2, _b2, _c2, _d2, _e2, _f2, _g2, _h2, _i2;
    return [id, {
      ...workspace,
      kind: (_a2 = workspace.kind) != null ? _a2 : "general",
      ownerCanvasPath: (_b2 = workspace.ownerCanvasPath) != null ? _b2 : null,
      representativeCanvasPath: (_c2 = workspace.representativeCanvasPath) != null ? _c2 : null,
      sideLayout: { ...DEFAULT_SIDE_LAYOUT, ...workspace.sideLayout, densityLevel: (_f2 = (_d2 = workspace.sideLayout) == null ? void 0 : _d2.densityLevel) != null ? _f2 : legacyDensity((_e2 = workspace.sideLayout) == null ? void 0 : _e2.viewMode, rawSettings == null ? void 0 : rawSettings.cardHeight) },
      createdAt: (_g2 = workspace.createdAt) != null ? _g2 : migratedAt,
      modifiedAt: (_i2 = (_h2 = workspace.modifiedAt) != null ? _h2 : workspace.createdAt) != null ? _i2 : migratedAt
    }];
  }));
  const { storageWorkspaceFilter: _legacyStorageWorkspaceFilter, hiddenStorageItemIds: _legacyHiddenStorageItemIds, ...legacyMiniPalette } = (_c = legacyUi.miniPalette) != null ? _c : {};
  return {
    ...structuredClone(DEFAULT_DATA),
    ...raw,
    settings: { ...DEFAULT_DATA.settings, ...migratedSettings, labelColorPresets: [...new Set((_d = rawSettings == null ? void 0 : rawSettings.labelColorPresets) != null ? _d : [])] },
    schemaVersion: 22,
    items: Object.fromEntries(Object.entries((_e = raw.items) != null ? _e : {}).map(([id, item]) => {
      var _a2, _b2, _c2, _d2, _e2, _f2, _g2, _h2, _i2, _j2;
      const repairedType = item.type === "markdown" && !((_a2 = item.origin) == null ? void 0 : _a2.filePath) ? "card" : item.type;
      const supportsFaces = repairedType !== "group";
      const group = repairedType === "group" && item.group ? {
        ...item.group,
        nodeBacks: (_b2 = item.group.nodeBacks) != null ? _b2 : {},
        nodeMetadata: (_d2 = item.group.nodeMetadata) != null ? _d2 : Object.fromEntries(Object.entries((_c2 = item.group.nodeBacks) != null ? _c2 : {}).map(([nodeId, backContent]) => {
          var _a3;
          return [nodeId, { tags: [], label: "", labelColor: "", caption: "", backContent, currentFace: "front", facesEnabled: true, modifiedAt: (_a3 = item.modifiedAt) != null ? _a3 : migratedAt }];
        }))
      } : item.group;
      return [id, { ...item, group, type: repairedType, sourceDeletedAt: repairedType === "markdown" ? item.sourceDeletedAt : void 0, backContent: supportsFaces ? (_e2 = item.backContent) != null ? _e2 : "" : "", facesEnabled: supportsFaces && ((_f2 = item.facesEnabled) != null ? _f2 : Boolean(item.backContent)), labelColor: (_g2 = item.labelColor) != null ? _g2 : "", canvasPlacements: (_h2 = item.canvasPlacements) != null ? _h2 : [], parentItemId: (_i2 = item.parentItemId) != null ? _i2 : null, childItemIds: (_j2 = item.childItemIds) != null ? _j2 : [] }];
    })),
    workspaces,
    collections: (_f = raw.collections) != null ? _f : {},
    pendingItemIds: (_g = raw.pendingItemIds) != null ? _g : [],
    canvasNodeMetadata: Object.fromEntries(Object.entries((_h = raw.canvasNodeMetadata) != null ? _h : {}).map(([canvasPath, nodes]) => [
      canvasPath,
      Object.fromEntries(Object.entries(nodes).map(([nodeId, metadata]) => {
        var _a2, _b2, _c2, _d2;
        return [nodeId, {
          ...metadata,
          backContent: (_a2 = metadata.backContent) != null ? _a2 : "",
          currentFace: (_b2 = metadata.currentFace) != null ? _b2 : "front",
          facesEnabled: (_c2 = metadata.facesEnabled) != null ? _c2 : Boolean(metadata.backContent || metadata.currentFace === "back"),
          labelColor: (_d2 = metadata.labelColor) != null ? _d2 : ""
        }];
      }))
    ])),
    uiState: {
      ...DEFAULT_DATA.uiState,
      ...legacyUi,
      sideSelectedItemIds: (_i = legacyUi.sideSelectedItemIds) != null ? _i : [],
      sideItemFaces: (_j = legacyUi.sideItemFaces) != null ? _j : {},
      miniItemFaces: (_k = legacyUi.miniItemFaces) != null ? _k : {},
      quickEditor: { ...DEFAULT_DATA.uiState.quickEditor, ...legacyUi.quickEditor },
      workspaceExplorer: { ...DEFAULT_DATA.uiState.workspaceExplorer, ...legacyUi.workspaceExplorer },
      miniPalette: {
        ...DEFAULT_DATA.uiState.miniPalette,
        ...legacyMiniPalette,
        storageItemIds: (_m = (_l = legacyMiniPalette.storageItemIds) == null ? void 0 : _l.filter((id) => {
          var _a2, _b2;
          return Boolean((_a2 = raw.items) == null ? void 0 : _a2[id]) && !((_b2 = raw.pendingItemIds) != null ? _b2 : []).includes(id);
        })) != null ? _m : [],
        densityLevel: (_q = (_n = legacyUi.miniPalette) == null ? void 0 : _n.densityLevel) != null ? _q : legacyDensity((_o = legacyUi.miniPalette) == null ? void 0 : _o.viewMode, (_p = legacyUi.miniPalette) == null ? void 0 : _p.cardHeight),
        collectSelectedItemIds: (_v = (_r = legacyUi.miniPalette) == null ? void 0 : _r.collectSelectedItemIds) != null ? _v : ((_s = legacyUi.miniPalette) == null ? void 0 : _s.tab) === "collect" ? (_u = (_t = legacyUi.miniPalette) == null ? void 0 : _t.selectedItemIds) != null ? _u : [] : [],
        collectSelectionAnchorId: (_x = (_w = legacyUi.miniPalette) == null ? void 0 : _w.collectSelectionAnchorId) != null ? _x : null,
        storageSelectedItemIds: (_C = (_y = legacyUi.miniPalette) == null ? void 0 : _y.storageSelectedItemIds) != null ? _C : ((_z = legacyUi.miniPalette) == null ? void 0 : _z.tab) === "storage" ? (_B = (_A = legacyUi.miniPalette) == null ? void 0 : _A.selectedItemIds) != null ? _B : [] : [],
        storageSelectionAnchorId: (_E = (_D = legacyUi.miniPalette) == null ? void 0 : _D.storageSelectionAnchorId) != null ? _E : null,
        focusedItemId: (_G = (_F = legacyUi.miniPalette) == null ? void 0 : _F.focusedItemId) != null ? _G : null,
        selectedItemIds: [],
        tab: (_J = (_I = (_H = legacyUi.miniPalette) == null ? void 0 : _H.tab) != null ? _I : legacyUi.miniTab) != null ? _J : DEFAULT_DATA.uiState.miniPalette.tab,
        leftPaneOpen: (_M = (_L = (_K = legacyUi.miniPalette) == null ? void 0 : _K.leftPaneOpen) != null ? _L : legacyUi.leftPaneOpen) != null ? _M : DEFAULT_DATA.uiState.miniPalette.leftPaneOpen,
        rightPaneOpen: (_P = (_O = (_N = legacyUi.miniPalette) == null ? void 0 : _N.rightPaneOpen) != null ? _O : legacyUi.rightPaneOpen) != null ? _P : DEFAULT_DATA.uiState.miniPalette.rightPaneOpen,
        leftPaneWidth: (_S = (_R = (_Q = legacyUi.miniPalette) == null ? void 0 : _Q.leftPaneWidth) != null ? _R : legacyUi.leftPaneWidth) != null ? _S : DEFAULT_DATA.uiState.miniPalette.leftPaneWidth,
        rightPaneWidth: (_V = (_U = (_T = legacyUi.miniPalette) == null ? void 0 : _T.rightPaneWidth) != null ? _U : legacyUi.rightPaneWidth) != null ? _V : DEFAULT_DATA.uiState.miniPalette.rightPaneWidth
      }
    }
  };
}

// src/core/store.ts
var PaletteStore = class {
  constructor(plugin) {
    this.plugin = plugin;
    __publicField(this, "data", migrateData(null));
    __publicField(this, "listeners", /* @__PURE__ */ new Set());
    __publicField(this, "saveTimer", null);
  }
  async load() {
    this.data = migrateData(await this.plugin.loadData());
    const repairedDuplicates = this.repairDuplicateCanvasItems();
    if (Object.keys(this.data.workspaces).length === 0) this.createWorkspace("My Workspace");
    else if (repairedDuplicates) await this.flush();
  }
  subscribe(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }
  changed() {
    for (const listener of this.listeners) listener();
    if (this.saveTimer !== null) window.clearTimeout(this.saveTimer);
    this.saveTimer = window.setTimeout(() => void this.flush(), 150);
  }
  async flush() {
    if (this.saveTimer !== null) window.clearTimeout(this.saveTimer);
    this.saveTimer = null;
    await this.plugin.saveData(this.data);
  }
  createWorkspace(name, kind = "general", ownerCanvasPath = null, representative = false) {
    var _a, _b;
    const id = createId("workspace");
    const now = Date.now();
    const owner = kind === "canvas" ? ownerCanvasPath : null;
    const workspace = { id, name, kind, ownerCanvasPath: owner, canvasPaths: owner ? [owner] : [], representativeCanvasPath: representative && owner ? owner : null, rootCollectionIds: [], looseItemIds: [], sideLayout: structuredClone(DEFAULT_SIDE_LAYOUT), createdAt: now, modifiedAt: now };
    this.data.workspaces[id] = workspace;
    if (representative && owner) this.setRepresentativeWorkspace(id, owner, false);
    (_b = (_a = this.data.uiState).activeWorkspaceId) != null ? _b : _a.activeWorkspaceId = id;
    this.changed();
    return workspace;
  }
  ensureCanvasWorkspace(canvasPath, name) {
    var _a;
    const existing = this.canvasWorkspaces(canvasPath);
    if (existing.length > 0) {
      if (!existing.some((workspace) => workspace.representativeCanvasPath === canvasPath)) this.setRepresentativeWorkspace(existing[0].id, canvasPath);
      return (_a = this.representativeWorkspaceForCanvas(canvasPath)) != null ? _a : existing[0];
    }
    return this.createWorkspace(name, "canvas", canvasPath, true);
  }
  canvasWorkspaces(canvasPath) {
    return Object.values(this.data.workspaces).filter((workspace) => workspace.kind === "canvas" && workspace.ownerCanvasPath === canvasPath);
  }
  representativeWorkspaceForCanvas(canvasPath) {
    return this.canvasWorkspaces(canvasPath).find((workspace) => workspace.representativeCanvasPath === canvasPath);
  }
  setRepresentativeWorkspace(workspaceId, canvasPath, notify = true) {
    const workspace = this.data.workspaces[workspaceId];
    if (!workspace || workspace.kind !== "canvas" || workspace.ownerCanvasPath !== canvasPath) return false;
    const now = Date.now();
    for (const candidate of this.canvasWorkspaces(canvasPath)) {
      candidate.representativeCanvasPath = candidate.id === workspaceId ? canvasPath : null;
      candidate.modifiedAt = now;
    }
    if (notify) this.changed();
    return true;
  }
  canStoreItem(workspaceId, item) {
    const workspace = this.data.workspaces[workspaceId];
    if (!workspace) return false;
    if (workspace.kind === "general") return true;
    const owner = workspace.ownerCanvasPath;
    if (!owner) return false;
    return item.origin.canvasPath === owner || item.canvasPlacements.some((placement) => placement.canvasPath === owner && placement.nodeIds.length > 0);
  }
  createCollection(workspaceId, name, parentId = null) {
    var _a, _b;
    const id = createId("collection");
    const collection = { id, workspaceId, parentId, name, childCollectionIds: [], itemIds: [] };
    this.data.collections[id] = collection;
    if (parentId) (_a = this.data.collections[parentId]) == null ? void 0 : _a.childCollectionIds.push(id);
    else (_b = this.data.workspaces[workspaceId]) == null ? void 0 : _b.rootCollectionIds.push(id);
    this.changed();
    return collection;
  }
  renameWorkspace(id, name) {
    const workspace = this.data.workspaces[id];
    const next = name.trim();
    if (!workspace || !next) return false;
    workspace.name = next;
    workspace.modifiedAt = Date.now();
    this.changed();
    return true;
  }
  removeWorkspace(id) {
    var _a;
    const workspace = this.data.workspaces[id];
    if (!workspace || Object.keys(this.data.workspaces).length <= 1) return false;
    const itemIds = this.itemsForWorkspace(id).map((item) => item.id);
    for (const itemId of itemIds) {
      const item = this.data.items[itemId];
      if (!item) continue;
      if (item.origin.workspaceId === id) delete item.origin.workspaceId;
      if (!this.data.pendingItemIds.includes(itemId)) this.data.pendingItemIds.push(itemId);
    }
    const removeCollection = (collectionId) => {
      const collection = this.data.collections[collectionId];
      if (!collection) return;
      for (const childId of collection.childCollectionIds) removeCollection(childId);
      delete this.data.collections[collectionId];
    };
    for (const collectionId of workspace.rootCollectionIds) removeCollection(collectionId);
    delete this.data.workspaces[id];
    if (workspace.kind === "canvas" && workspace.ownerCanvasPath && workspace.representativeCanvasPath === workspace.ownerCanvasPath) {
      const replacement = this.canvasWorkspaces(workspace.ownerCanvasPath)[0];
      if (replacement) this.setRepresentativeWorkspace(replacement.id, workspace.ownerCanvasPath, false);
    }
    if (this.data.uiState.activeWorkspaceId === id) this.data.uiState.activeWorkspaceId = (_a = Object.keys(this.data.workspaces)[0]) != null ? _a : null;
    this.changed();
    return true;
  }
  addPending(item) {
    if (this.existingCollectedItem(item)) return;
    this.data.items[item.id] = item;
    if (!this.data.pendingItemIds.includes(item.id)) this.data.pendingItemIds.push(item.id);
    this.changed();
  }
  collectCanvasItems(items) {
    var _a;
    const collected = [];
    for (const captured of items) {
      const item = (_a = this.existingCollectedItem(captured)) != null ? _a : captured;
      if (!this.data.items[item.id]) this.data.items[item.id] = item;
      if (!this.data.pendingItemIds.includes(item.id)) this.data.pendingItemIds.push(item.id);
      if (!collected.includes(item.id)) collected.push(item.id);
    }
    this.changed();
    return collected;
  }
  addToWorkspace(workspaceId, item) {
    return this.addToWorkspaceWithCanvasOverride(workspaceId, item, false);
  }
  addToWorkspaceAsUnlinked(workspaceId, item) {
    return this.addToWorkspaceWithCanvasOverride(workspaceId, item, true);
  }
  addToWorkspaceWithCanvasOverride(workspaceId, item, allowForeignCanvas) {
    var _a, _b, _c;
    item = (_a = this.existingCollectedItem(item)) != null ? _a : item;
    const workspace = this.data.workspaces[workspaceId];
    if (!workspace || !allowForeignCanvas && !this.canStoreItem(workspaceId, item)) return false;
    this.detachWorkspaceLinks(item.id);
    if (allowForeignCanvas) this.detachCanvasLinks(item);
    item.origin.workspaceId = workspaceId;
    (_b = item.parentItemId) != null ? _b : item.parentItemId = null;
    (_c = item.childItemIds) != null ? _c : item.childItemIds = [];
    this.data.items[item.id] = item;
    if (!workspace.looseItemIds.includes(item.id)) workspace.looseItemIds.push(item.id);
    if (item.origin.canvasPath && !workspace.canvasPaths.includes(item.origin.canvasPath)) workspace.canvasPaths.push(item.origin.canvasPath);
    if (workspace.kind === "general" && item.origin.canvasPath && !workspace.representativeCanvasPath) workspace.representativeCanvasPath = item.origin.canvasPath;
    this.changed();
    return true;
  }
  importPending(workspaceId, itemIds, asUnlinked = false) {
    var _a, _b;
    const workspace = this.data.workspaces[workspaceId];
    if (!workspace) return { imported: [], rejected: [...itemIds], alreadySaved: [] };
    const imported = [];
    const rejected = [];
    const alreadySaved = [];
    for (const id of itemIds) {
      const item = this.data.items[id];
      if (!item) continue;
      if (((_a = this.workspaceForItem(id)) == null ? void 0 : _a.id) === workspaceId) {
        alreadySaved.push(id);
        continue;
      }
      this.detachWorkspaceLinks(id);
      if (asUnlinked) this.detachCanvasLinks(item);
      item.origin.workspaceId = workspaceId;
      item.parentItemId = null;
      (_b = item.childItemIds) != null ? _b : item.childItemIds = [];
      if (workspace.kind === "general" && item.origin.canvasPath && !workspace.canvasPaths.includes(item.origin.canvasPath)) workspace.canvasPaths.push(item.origin.canvasPath);
      if (workspace.kind === "general" && item.origin.canvasPath && !workspace.representativeCanvasPath) workspace.representativeCanvasPath = item.origin.canvasPath;
      if (!workspace.looseItemIds.includes(id)) workspace.looseItemIds.push(id);
      imported.push(id);
    }
    this.data.pendingItemIds = this.data.pendingItemIds.filter((id) => !imported.includes(id));
    this.changed();
    return { imported, rejected, alreadySaved };
  }
  updateItem(id, changes) {
    const item = this.data.items[id];
    if (!item) return;
    Object.assign(item, changes, { modifiedAt: Date.now() });
    this.applyItemMetadataToLinkedNodes(item);
    this.changed();
    void this.plugin.syncPaletteItemToCanvas(item);
  }
  convertCardToMarkdown(id, filePath) {
    const item = this.data.items[id];
    if (!item || item.type !== "card") return false;
    item.type = "markdown";
    item.origin.filePath = filePath;
    delete item.sourceDeletedAt;
    delete item.origin.textRange;
    item.modifiedAt = Date.now();
    this.changed();
    return true;
  }
  setItemBack(id, backContent) {
    const item = this.data.items[id];
    if (!item || item.backContent === backContent) return;
    item.facesEnabled = true;
    this.updateItem(id, { displayTitle: item.displayTitle, tags: item.tags, label: item.label, labelColor: item.labelColor, caption: item.caption, backContent });
  }
  setPaletteFace(location, itemId, face) {
    var _a, _b, _c, _d;
    if (location === "side") ((_b = (_a = this.data.uiState).sideItemFaces) != null ? _b : _a.sideItemFaces = {})[itemId] = face;
    else ((_d = (_c = this.data.uiState).miniItemFaces) != null ? _d : _c.miniItemFaces = {})[itemId] = face;
    this.changed();
  }
  enableItemFaces(itemId) {
    const item = this.data.items[itemId];
    if (!item || item.type === "group" || item.facesEnabled) return;
    item.facesEnabled = true;
    item.modifiedAt = Date.now();
    this.applyItemMetadataToLinkedNodes(item);
    this.changed();
  }
  disableItemFaces(itemId) {
    var _a, _b, _c, _d;
    const item = this.data.items[itemId];
    if (!item || item.type === "group" || !item.facesEnabled) return;
    const modifiedAt = Date.now();
    item.facesEnabled = false;
    item.modifiedAt = modifiedAt;
    delete ((_b = (_a = this.data.uiState).sideItemFaces) != null ? _b : _a.sideItemFaces = {})[item.id];
    delete ((_d = (_c = this.data.uiState).miniItemFaces) != null ? _d : _c.miniItemFaces = {})[item.id];
    for (const location of this.linkedCanvasNodes(item)) {
      const linkedState = this.canvasNodeState(location.canvasPath, location.nodeId);
      this.setMetadataRecord(location.canvasPath, location.nodeId, { ...linkedState, currentFace: "front", facesEnabled: false }, modifiedAt);
    }
    this.changed();
  }
  getCanvasNodeMetadata(canvasPath, nodeId) {
    var _a;
    return (_a = this.data.canvasNodeMetadata[canvasPath]) == null ? void 0 : _a[nodeId];
  }
  linkedItemForNode(canvasPath, nodeId) {
    return this.allItems().find((item) => this.itemHasLinkedNode(item, canvasPath, nodeId));
  }
  existingCollectedItem(item) {
    for (const location of this.linkedCanvasNodes(item)) {
      const existing = this.linkedItemForNode(location.canvasPath, location.nodeId);
      if (existing && existing.id !== item.id) return existing;
    }
    return this.data.items[item.id];
  }
  setCanvasNodeMetadata(canvasPath, nodeId, metadata) {
    var _a;
    const modifiedAt = Date.now();
    const normalized = {
      tags: [...new Set(metadata.tags)],
      label: metadata.label,
      labelColor: metadata.label ? (_a = metadata.labelColor) != null ? _a : "" : "",
      caption: metadata.caption
    };
    this.setMetadataRecord(canvasPath, nodeId, normalized, modifiedAt);
    const linkedItems = Object.values(this.data.items).filter((item) => this.itemHasLinkedNode(item, canvasPath, nodeId));
    for (const item of linkedItems) {
      Object.assign(item, normalized, { modifiedAt });
      this.applyItemMetadataToLinkedNodes(item);
    }
    this.changed();
    for (const item of linkedItems) void this.plugin.syncPaletteItemToCanvas(item);
  }
  setCanvasNodeBack(canvasPath, nodeId, backContent) {
    const current = this.canvasNodeState(canvasPath, nodeId);
    const modifiedAt = Date.now();
    this.setMetadataRecord(canvasPath, nodeId, { ...current, backContent, facesEnabled: true }, modifiedAt);
    const linkedItems = Object.values(this.data.items).filter((item) => this.itemHasLinkedNode(item, canvasPath, nodeId));
    for (const item of linkedItems) {
      item.backContent = backContent;
      item.facesEnabled = true;
      item.modifiedAt = modifiedAt;
      this.applyItemMetadataToLinkedNodes(item);
    }
    this.changed();
  }
  setCanvasNodeFace(canvasPath, nodeId, currentFace) {
    const current = this.canvasNodeState(canvasPath, nodeId);
    this.setMetadataRecord(canvasPath, nodeId, { ...current, currentFace }, current.modifiedAt);
    this.changed();
  }
  enableCanvasNodeFaces(canvasPath, nodeId) {
    const current = this.canvasNodeState(canvasPath, nodeId);
    const linkedItems = Object.values(this.data.items).filter((item) => this.itemHasLinkedNode(item, canvasPath, nodeId));
    if (current.facesEnabled && linkedItems.every((item) => item.facesEnabled)) return;
    this.setMetadataRecord(canvasPath, nodeId, { ...current, facesEnabled: true }, current.modifiedAt);
    for (const item of linkedItems) {
      item.facesEnabled = true;
      this.applyItemMetadataToLinkedNodes(item);
    }
    this.changed();
  }
  disableCanvasNodeFaces(canvasPath, nodeId) {
    var _a, _b, _c, _d;
    const current = this.canvasNodeState(canvasPath, nodeId);
    const linkedItems = Object.values(this.data.items).filter((item) => this.itemHasLinkedNode(item, canvasPath, nodeId));
    const modifiedAt = Date.now();
    this.setMetadataRecord(canvasPath, nodeId, { ...current, currentFace: "front", facesEnabled: false }, modifiedAt);
    for (const item of linkedItems) {
      item.facesEnabled = false;
      item.modifiedAt = modifiedAt;
      delete ((_b = (_a = this.data.uiState).sideItemFaces) != null ? _b : _a.sideItemFaces = {})[item.id];
      delete ((_d = (_c = this.data.uiState).miniItemFaces) != null ? _d : _c.miniItemFaces = {})[item.id];
      this.applyItemMetadataToLinkedNodes(item);
      for (const location of this.linkedCanvasNodes(item)) {
        const linkedState = this.canvasNodeState(location.canvasPath, location.nodeId);
        this.setMetadataRecord(location.canvasPath, location.nodeId, { ...linkedState, currentFace: "front", facesEnabled: false }, modifiedAt);
      }
    }
    this.changed();
  }
  unlinkCanvasNode(canvasPath, nodeId) {
    var _a;
    const item = this.allItems().find((candidate) => this.itemHasLinkedNode(candidate, canvasPath, nodeId));
    if (!item) return false;
    const current = this.canvasNodeState(canvasPath, nodeId);
    this.setMetadataRecord(canvasPath, nodeId, { ...current, tags: [...item.tags], label: item.label, labelColor: (_a = item.labelColor) != null ? _a : "", caption: item.caption, backContent: item.backContent, facesEnabled: item.facesEnabled }, item.modifiedAt);
    if (item.origin.canvasPath === canvasPath && item.origin.canvasNodeId === nodeId) {
      delete item.origin.canvasPath;
      delete item.origin.canvasNodeId;
    }
    for (const placement of item.canvasPlacements) if (placement.canvasPath === canvasPath) placement.nodeIds = placement.nodeIds.filter((id) => id !== nodeId);
    item.canvasPlacements = item.canvasPlacements.filter((placement) => placement.nodeIds.length > 0);
    this.promotePlacement(item);
    this.changed();
    return true;
  }
  addLabelColorPreset(color) {
    const normalized = color.trim().toLowerCase();
    if (!/^#[0-9a-f]{6}$/.test(normalized) || this.data.settings.labelColorPresets.includes(normalized)) return;
    this.data.settings.labelColorPresets.push(normalized);
    this.changed();
  }
  reorderItems(workspaceId, sourceId, targetId, insertAfter = false) {
    const workspace = this.data.workspaces[workspaceId];
    if (!workspace || sourceId === targetId) return;
    const containers = this.itemContainers(workspaceId);
    const target = containers.find((ids) => ids.includes(targetId));
    if (!target || !containers.some((ids) => ids.includes(sourceId))) return;
    for (const ids of containers) {
      const index = ids.indexOf(sourceId);
      if (index >= 0) ids.splice(index, 1);
    }
    const targetIndex = target.indexOf(targetId);
    target.splice(targetIndex + (insertAfter ? 1 : 0), 0, sourceId);
    this.changed();
  }
  moveItems(workspaceId, itemIds, collectionId, targetId = null, insertAfter = false, parentItemId = null) {
    var _a;
    const workspace = this.data.workspaces[workspaceId];
    if (!workspace) return;
    const requested = [...new Set(itemIds)].filter((id) => this.data.items[id]);
    const valid = requested.filter((id) => !requested.some((candidate) => candidate !== id && this.isItemDescendant(id, candidate)));
    if (parentItemId && (valid.includes(parentItemId) || valid.some((id) => this.isItemDescendant(parentItemId, id)))) return;
    const containers = this.itemContainers(workspaceId);
    if (!valid.some((id) => containers.some((ids) => ids.includes(id)))) return;
    for (const ids of containers) for (const id of valid) {
      const index = ids.indexOf(id);
      if (index >= 0) ids.splice(index, 1);
    }
    for (const id of valid) this.data.items[id].parentItemId = parentItemId;
    const collection = collectionId ? this.data.collections[collectionId] : null;
    const parentItem = parentItemId ? this.data.items[parentItemId] : null;
    const target = parentItem ? (_a = parentItem.childItemIds) != null ? _a : parentItem.childItemIds = [] : (collection == null ? void 0 : collection.workspaceId) === workspaceId ? collection.itemIds : workspace.looseItemIds;
    const targetIndex = targetId ? target.indexOf(targetId) : -1;
    target.splice(targetIndex >= 0 ? targetIndex + (insertAfter ? 1 : 0) : target.length, 0, ...valid);
    this.changed();
  }
  assignItemsToCollection(workspaceId, itemIds, collectionId) {
    this.moveItems(workspaceId, itemIds, collectionId);
  }
  renameCollection(id, name) {
    const collection = this.data.collections[id];
    if (!collection || !name.trim()) return;
    collection.name = name.trim();
    this.changed();
  }
  removeCollection(id) {
    var _a, _b;
    const collection = this.data.collections[id];
    if (!collection) return;
    const workspace = this.data.workspaces[collection.workspaceId];
    if (!workspace) return;
    const parent = collection.parentId ? this.data.collections[collection.parentId] : void 0;
    const siblingIds = (_a = parent == null ? void 0 : parent.childCollectionIds) != null ? _a : workspace.rootCollectionIds;
    const index = siblingIds.indexOf(id);
    const promotedChildren = collection.childCollectionIds.filter((childId) => this.data.collections[childId]);
    if (index >= 0) siblingIds.splice(index, 1, ...promotedChildren);
    else siblingIds.push(...promotedChildren.filter((childId) => !siblingIds.includes(childId)));
    for (const childId of promotedChildren) this.data.collections[childId].parentId = collection.parentId;
    const itemTarget = (_b = parent == null ? void 0 : parent.itemIds) != null ? _b : workspace.looseItemIds;
    itemTarget.push(...collection.itemIds.filter((itemId) => !itemTarget.includes(itemId)));
    workspace.sideLayout.collapsedCollectionIds = workspace.sideLayout.collapsedCollectionIds.filter((collectionId) => collectionId !== id);
    if (workspace.sideLayout.focusedCollectionId === id) workspace.sideLayout.focusedCollectionId = collection.parentId;
    if (workspace.sideLayout.selectedCollectionId === id) workspace.sideLayout.selectedCollectionId = collection.parentId;
    delete this.data.collections[id];
    this.changed();
  }
  moveCollection(id, parentId, targetId = null, insertAfter = false) {
    var _a, _b, _c;
    const collection = this.data.collections[id];
    if (!collection || id === parentId || this.wouldCreateCycle(id, parentId)) return;
    const workspace = this.data.workspaces[collection.workspaceId];
    if (!workspace) return;
    if (collection.parentId) {
      const siblings = (_a = this.data.collections[collection.parentId]) == null ? void 0 : _a.childCollectionIds;
      const index = (_b = siblings == null ? void 0 : siblings.indexOf(id)) != null ? _b : -1;
      if (siblings && index >= 0) siblings.splice(index, 1);
    } else workspace.rootCollectionIds = workspace.rootCollectionIds.filter((childId) => childId !== id);
    collection.parentId = parentId;
    const target = parentId ? (_c = this.data.collections[parentId]) == null ? void 0 : _c.childCollectionIds : workspace.rootCollectionIds;
    if (!target) return;
    const targetIndex = targetId ? target.indexOf(targetId) : -1;
    target.splice(targetIndex >= 0 ? targetIndex + (insertAfter ? 1 : 0) : target.length, 0, id);
    this.changed();
  }
  associateCanvas(workspaceId, canvasPath, representative = false) {
    const workspace = this.data.workspaces[workspaceId];
    if (!workspace) return;
    if (!workspace.canvasPaths.includes(canvasPath)) workspace.canvasPaths.push(canvasPath);
    if (workspace.kind === "canvas") {
      if (representative && workspace.ownerCanvasPath === canvasPath) this.setRepresentativeWorkspace(workspaceId, canvasPath, false);
    } else if (representative || !workspace.representativeCanvasPath) workspace.representativeCanvasPath = canvasPath;
    this.changed();
  }
  recordCanvasPlacement(itemId, canvasPath, nodeIds) {
    const item = this.data.items[itemId];
    if (!item) return;
    const placement = item.canvasPlacements.find((candidate) => candidate.canvasPath === canvasPath);
    if (placement) {
      placement.nodeIds = [.../* @__PURE__ */ new Set([...placement.nodeIds, ...nodeIds])];
      placement.placedAt = Date.now();
    } else item.canvasPlacements.push({ canvasPath, nodeIds: [...new Set(nodeIds)], placedAt: Date.now() });
    this.applyItemMetadataToLinkedNodes(item);
    const workspaceId = item.origin.workspaceId;
    if (workspaceId) this.associateCanvas(workspaceId, canvasPath);
    else this.changed();
  }
  restoreCanvasNodeMetadata(canvasPath, records) {
    if (records.length === 0) return;
    for (const { nodeId, metadata } of records) {
      this.setMetadataRecord(canvasPath, nodeId, metadata, metadata.modifiedAt);
    }
    this.changed();
  }
  linkedCanvasNodes(item) {
    const locations = [];
    if (item.origin.canvasPath && item.origin.canvasNodeId) locations.push({ canvasPath: item.origin.canvasPath, nodeId: item.origin.canvasNodeId });
    for (const placement of item.canvasPlacements) for (const nodeId of placement.nodeIds) locations.push({ canvasPath: placement.canvasPath, nodeId });
    return locations.filter((location, index, all) => all.findIndex((candidate) => candidate.canvasPath === location.canvasPath && candidate.nodeId === location.nodeId) === index);
  }
  linkedCanvasLocations(item) {
    const locations = /* @__PURE__ */ new Map();
    for (const location of this.linkedCanvasNodes(item)) if (!locations.has(location.canvasPath)) locations.set(location.canvasPath, location);
    return [...locations.values()];
  }
  reconcileCanvasLinks(canvasPath, existingNodeIds) {
    let changed = false;
    for (const item of this.allItems()) {
      if (item.origin.canvasPath === canvasPath && item.origin.canvasNodeId && !existingNodeIds.has(item.origin.canvasNodeId)) {
        delete item.origin.canvasPath;
        delete item.origin.canvasNodeId;
        changed = true;
      }
      for (const placement of item.canvasPlacements.filter((candidate) => candidate.canvasPath === canvasPath)) {
        const next = placement.nodeIds.filter((nodeId) => existingNodeIds.has(nodeId));
        if (next.length !== placement.nodeIds.length) {
          placement.nodeIds = next;
          changed = true;
        }
      }
      const before = item.canvasPlacements.length;
      item.canvasPlacements = item.canvasPlacements.filter((placement) => placement.nodeIds.length > 0);
      if (item.canvasPlacements.length !== before) changed = true;
      if (!item.origin.canvasPath || !item.origin.canvasNodeId) changed = this.promotePlacement(item) || changed;
    }
    const metadata = this.data.canvasNodeMetadata[canvasPath];
    if (metadata) {
      for (const nodeId of Object.keys(metadata)) if (!existingNodeIds.has(nodeId)) {
        delete metadata[nodeId];
        changed = true;
      }
      if (Object.keys(metadata).length === 0) delete this.data.canvasNodeMetadata[canvasPath];
    }
    return changed;
  }
  unlinkItemsFromCanvas(itemIds, canvasPath) {
    let changed = false;
    for (const id of itemIds) {
      const item = this.data.items[id];
      if (!item) continue;
      const linkedNodeIds = this.linkedCanvasNodes(item).filter((location) => location.canvasPath === canvasPath).map((location) => location.nodeId);
      if (item.origin.canvasPath === canvasPath) {
        delete item.origin.canvasPath;
        delete item.origin.canvasNodeId;
        changed = true;
      }
      const before = item.canvasPlacements.length;
      item.canvasPlacements = item.canvasPlacements.filter((placement) => placement.canvasPath !== canvasPath);
      if (item.canvasPlacements.length !== before) changed = true;
      for (const nodeId of linkedNodeIds) this.setMetadataRecord(canvasPath, nodeId, { tags: [], label: "", labelColor: "", caption: "" }, Date.now());
      this.promotePlacement(item);
    }
    if (changed) this.changed();
  }
  reconcileDeletedFile(path, folder = false) {
    let changed = !folder && path.toLocaleLowerCase().endsWith(".canvas") ? this.reconcileCanvasLinks(path, /* @__PURE__ */ new Set()) : false;
    const prefix = `${path}/`;
    for (const item of this.allItems()) {
      if (!item.origin.filePath || (folder ? !item.origin.filePath.startsWith(prefix) : item.origin.filePath !== path)) continue;
      item.sourceDeletedAt = Date.now();
      changed = true;
    }
    if (changed) this.changed();
  }
  renameSourcePath(oldPath, newPath, folder = false) {
    const changedItems = [];
    const prefix = `${oldPath}/`;
    for (const item of this.allItems()) {
      const current = item.origin.filePath;
      if (!current || (folder ? !current.startsWith(prefix) : current !== oldPath)) continue;
      item.origin.filePath = folder ? `${newPath}/${current.slice(prefix.length)}` : newPath;
      delete item.sourceDeletedAt;
      item.modifiedAt = Date.now();
      changedItems.push(item);
    }
    if (changedItems.length > 0) this.changed();
    return changedItems;
  }
  renameCanvasPath(oldPath, newPath, folder = false) {
    var _a;
    const prefix = `${oldPath}/`;
    const moved = (path) => folder && path.startsWith(prefix) ? `${newPath}/${path.slice(prefix.length)}` : path === oldPath ? newPath : path;
    let changed = false;
    for (const item of this.allItems()) {
      if (item.origin.canvasPath) {
        const next = moved(item.origin.canvasPath);
        if (next !== item.origin.canvasPath) {
          item.origin.canvasPath = next;
          changed = true;
        }
      }
      for (const placement of item.canvasPlacements) {
        const next = moved(placement.canvasPath);
        if (next !== placement.canvasPath) {
          placement.canvasPath = next;
          changed = true;
        }
      }
    }
    for (const workspace of Object.values(this.data.workspaces)) {
      if (workspace.ownerCanvasPath) {
        const next = moved(workspace.ownerCanvasPath);
        if (next !== workspace.ownerCanvasPath) {
          workspace.ownerCanvasPath = next;
          changed = true;
        }
      }
      const nextPaths = [...new Set(workspace.canvasPaths.map(moved))];
      if (nextPaths.some((path, index) => path !== workspace.canvasPaths[index]) || nextPaths.length !== workspace.canvasPaths.length) {
        workspace.canvasPaths = nextPaths;
        changed = true;
      }
      if (workspace.representativeCanvasPath) {
        const next = moved(workspace.representativeCanvasPath);
        if (next !== workspace.representativeCanvasPath) {
          workspace.representativeCanvasPath = next;
          changed = true;
        }
      }
    }
    for (const [canvasPath, metadata] of Object.entries(this.data.canvasNodeMetadata)) {
      const next = moved(canvasPath);
      if (next === canvasPath) continue;
      this.data.canvasNodeMetadata[next] = { ...(_a = this.data.canvasNodeMetadata[next]) != null ? _a : {}, ...metadata };
      delete this.data.canvasNodeMetadata[canvasPath];
      changed = true;
    }
    if (changed) this.changed();
  }
  restoreSource(itemId, filePath) {
    const item = this.data.items[itemId];
    if (!item || item.type !== "markdown") return null;
    const previousPath = item.origin.filePath;
    const now = Date.now();
    for (const candidate of this.allItems()) {
      if (candidate.type !== "markdown" || candidate.origin.filePath !== previousPath) continue;
      candidate.origin.filePath = filePath;
      delete candidate.sourceDeletedAt;
      candidate.modifiedAt = now;
    }
    this.changed();
    return item;
  }
  updateMarkdownSource(path, content) {
    let changed = false;
    for (const item of this.allItems()) {
      if (item.type !== "markdown" || item.origin.filePath !== path) continue;
      if (item.content !== content || item.sourceDeletedAt) {
        item.content = content;
        delete item.sourceDeletedAt;
        item.modifiedAt = Date.now();
        changed = true;
      }
    }
    if (changed) this.changed();
  }
  itemHasLinkedNode(item, canvasPath, nodeId) {
    return this.linkedCanvasNodes(item).some((location) => location.canvasPath === canvasPath && location.nodeId === nodeId);
  }
  promotePlacement(item) {
    if (item.origin.canvasPath && item.origin.canvasNodeId) return false;
    const placement = item.canvasPlacements.find((candidate) => candidate.nodeIds.length > 0);
    const nodeId = placement == null ? void 0 : placement.nodeIds.shift();
    if (!placement || !nodeId) return false;
    item.origin.canvasPath = placement.canvasPath;
    item.origin.canvasNodeId = nodeId;
    if (placement.nodeIds.length === 0) item.canvasPlacements = item.canvasPlacements.filter((candidate) => candidate !== placement);
    return true;
  }
  applyItemMetadataToLinkedNodes(item) {
    var _a, _b, _c, _d;
    const normalized = { tags: [...new Set(item.tags)], label: item.label, labelColor: item.label ? (_a = item.labelColor) != null ? _a : "" : "", caption: item.caption, backContent: item.backContent, facesEnabled: item.facesEnabled };
    for (const location of this.linkedCanvasNodes(item)) {
      const currentFace = (_d = (_c = (_b = this.data.canvasNodeMetadata[location.canvasPath]) == null ? void 0 : _b[location.nodeId]) == null ? void 0 : _c.currentFace) != null ? _d : "front";
      this.setMetadataRecord(location.canvasPath, location.nodeId, { ...normalized, currentFace }, item.modifiedAt);
    }
  }
  replaceCanvasPlacement(itemId, canvasPath, removedNodeIds, newNodeIds, existingNodeIds) {
    const item = this.data.items[itemId];
    if (!item) return;
    const removed = new Set(removedNodeIds);
    const replacedOrigin = item.origin.canvasPath === canvasPath && Boolean(item.origin.canvasNodeId && removed.has(item.origin.canvasNodeId));
    if (replacedOrigin) {
      item.origin.canvasPath = canvasPath;
      item.origin.canvasNodeId = newNodeIds[0];
    }
    for (const placement of item.canvasPlacements) {
      if (placement.canvasPath === canvasPath) placement.nodeIds = placement.nodeIds.filter((nodeId) => !removed.has(nodeId));
    }
    item.canvasPlacements = item.canvasPlacements.filter((placement) => placement.nodeIds.length > 0);
    const placementIds = replacedOrigin ? newNodeIds.slice(1) : newNodeIds;
    if (placementIds.length > 0) {
      const placement = item.canvasPlacements.find((candidate) => candidate.canvasPath === canvasPath);
      if (placement) {
        placement.nodeIds = [.../* @__PURE__ */ new Set([...placement.nodeIds, ...placementIds])];
        placement.placedAt = Date.now();
      } else item.canvasPlacements.push({ canvasPath, nodeIds: [...new Set(placementIds)], placedAt: Date.now() });
    }
    this.reconcileCanvasLinks(canvasPath, existingNodeIds);
    this.applyItemMetadataToLinkedNodes(item);
    const workspaceId = item.origin.workspaceId;
    if (workspaceId) this.associateCanvas(workspaceId, canvasPath);
    else this.changed();
  }
  canvasNodeState(canvasPath, nodeId) {
    var _a, _b;
    return (_b = (_a = this.data.canvasNodeMetadata[canvasPath]) == null ? void 0 : _a[nodeId]) != null ? _b : { tags: [], label: "", labelColor: "", caption: "", backContent: "", currentFace: "front", facesEnabled: false, modifiedAt: Date.now() };
  }
  setMetadataRecord(canvasPath, nodeId, metadata, modifiedAt) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i;
    const previous = (_a = this.data.canvasNodeMetadata[canvasPath]) == null ? void 0 : _a[nodeId];
    const record = { tags: metadata.tags, label: metadata.label, labelColor: metadata.labelColor, caption: metadata.caption, backContent: (_c = (_b = metadata.backContent) != null ? _b : previous == null ? void 0 : previous.backContent) != null ? _c : "", currentFace: (_e = (_d = metadata.currentFace) != null ? _d : previous == null ? void 0 : previous.currentFace) != null ? _e : "front", facesEnabled: (_g = (_f = metadata.facesEnabled) != null ? _f : previous == null ? void 0 : previous.facesEnabled) != null ? _g : false, modifiedAt };
    const isEmpty = record.tags.length === 0 && !record.label && !record.caption && !record.backContent && record.currentFace === "front" && !record.facesEnabled;
    if (isEmpty) {
      const canvas2 = this.data.canvasNodeMetadata[canvasPath];
      if (!canvas2) return;
      delete canvas2[nodeId];
      if (Object.keys(canvas2).length === 0) delete this.data.canvasNodeMetadata[canvasPath];
      return;
    }
    const canvas = (_i = (_h = this.data.canvasNodeMetadata)[canvasPath]) != null ? _i : _h[canvasPath] = {};
    canvas[nodeId] = record;
  }
  itemsForWorkspace(workspaceId, includeCollections = true) {
    if (!workspaceId) return [];
    const workspace = this.data.workspaces[workspaceId];
    if (!workspace) return [];
    const ids = new Set(workspace.looseItemIds);
    if (includeCollections) {
      for (const collection of Object.values(this.data.collections)) if (collection.workspaceId === workspaceId) for (const id of collection.itemIds) ids.add(id);
    }
    const addChildren = (id) => {
      var _a;
      const item = this.data.items[id];
      if (!item) return;
      for (const childId of (_a = item.childItemIds) != null ? _a : []) {
        ids.add(childId);
        addChildren(childId);
      }
    };
    for (const id of [...ids]) addChildren(id);
    return [...ids].map((id) => this.data.items[id]).filter((item) => Boolean(item));
  }
  workspaceForItem(itemId) {
    var _a;
    const contains = (workspace) => {
      if (workspace.looseItemIds.includes(itemId)) return true;
      return this.itemsForWorkspace(workspace.id).some((item) => item.id === itemId);
    };
    const preferredId = (_a = this.data.items[itemId]) == null ? void 0 : _a.origin.workspaceId;
    const preferred = preferredId ? this.data.workspaces[preferredId] : void 0;
    if (preferred && contains(preferred)) return preferred;
    return Object.values(this.data.workspaces).find(contains);
  }
  allItems() {
    return Object.values(this.data.items);
  }
  miniStorageHas(itemId) {
    return this.data.uiState.miniPalette.storageItemIds.includes(itemId);
  }
  addMiniStorageItems(itemIds) {
    const linked = new Set(this.data.uiState.miniPalette.storageItemIds);
    const added = [];
    for (const id of itemIds) if (this.data.items[id] && !linked.has(id)) {
      linked.add(id);
      added.push(id);
    }
    this.data.uiState.miniPalette.storageItemIds = [...linked];
    this.changed();
    return added;
  }
  itemLinkedToWorkspace(item, workspaceId) {
    const workspace = this.data.workspaces[workspaceId];
    if (!workspace) return false;
    const locations = this.linkedCanvasNodes(item);
    return workspace.kind === "canvas" ? Boolean(workspace.ownerCanvasPath && locations.some((location) => location.canvasPath === workspace.ownerCanvasPath)) : locations.length > 0;
  }
  removeMiniStorageItems(itemIds) {
    const removed = new Set(itemIds);
    this.data.uiState.miniPalette.storageItemIds = this.data.uiState.miniPalette.storageItemIds.filter((id) => !removed.has(id));
    this.data.uiState.miniPalette.storageSelectedItemIds = this.data.uiState.miniPalette.storageSelectedItemIds.filter((id) => !removed.has(id));
    if (this.data.uiState.selectedItemId && removed.has(this.data.uiState.selectedItemId)) this.data.uiState.selectedItemId = null;
    this.changed();
  }
  removePendingItems(itemIds) {
    const pending = new Set(itemIds.filter((id) => this.data.pendingItemIds.includes(id)));
    if (pending.size === 0) return;
    this.data.pendingItemIds = this.data.pendingItemIds.filter((id) => !pending.has(id));
    const disposable = [...pending].filter((id) => !this.workspaceForItem(id) && !this.miniStorageHas(id));
    if (disposable.length > 0) this.removeItems(disposable);
    else this.changed();
  }
  completePendingCanvasPlacement(itemIds) {
    const completed = new Set(itemIds.filter((id) => this.data.pendingItemIds.includes(id)));
    if (completed.size === 0) return;
    this.data.pendingItemIds = this.data.pendingItemIds.filter((id) => !completed.has(id));
    this.data.uiState.miniPalette.collectSelectedItemIds = this.data.uiState.miniPalette.collectSelectedItemIds.filter((id) => !completed.has(id));
    if (this.data.uiState.miniPalette.collectSelectionAnchorId && completed.has(this.data.uiState.miniPalette.collectSelectionAnchorId)) this.data.uiState.miniPalette.collectSelectionAnchorId = null;
    if (this.data.uiState.miniPalette.focusedItemId && completed.has(this.data.uiState.miniPalette.focusedItemId)) this.data.uiState.miniPalette.focusedItemId = null;
    this.changed();
  }
  wouldCreateCycle(id, parentId) {
    var _a, _b;
    let cursor = parentId;
    while (cursor) {
      if (cursor === id) return true;
      cursor = (_b = (_a = this.data.collections[cursor]) == null ? void 0 : _a.parentId) != null ? _b : null;
    }
    return false;
  }
  removeItems(itemIds) {
    var _a, _b, _c, _d, _e, _f;
    const removed = new Set(itemIds);
    for (const id of itemIds) {
      const item = this.data.items[id];
      if (!item) continue;
      const destination = item.parentItemId ? (_a = this.data.items[item.parentItemId]) == null ? void 0 : _a.childItemIds : void 0;
      const workspace = this.workspaceForItem(id);
      const collection = workspace ? Object.values(this.data.collections).find((entry) => entry.workspaceId === workspace.id && entry.itemIds.includes(id)) : void 0;
      const fallback = (_b = destination != null ? destination : collection == null ? void 0 : collection.itemIds) != null ? _b : workspace == null ? void 0 : workspace.looseItemIds;
      if (fallback) fallback.push(...((_c = item.childItemIds) != null ? _c : []).filter((childId) => !removed.has(childId) && !fallback.includes(childId)));
      for (const childId of (_d = item.childItemIds) != null ? _d : []) if (!removed.has(childId) && this.data.items[childId]) this.data.items[childId].parentItemId = (_e = item.parentItemId) != null ? _e : null;
    }
    for (const id of itemIds) delete this.data.items[id];
    this.data.pendingItemIds = this.data.pendingItemIds.filter((id) => !itemIds.includes(id));
    for (const workspace of Object.values(this.data.workspaces)) workspace.looseItemIds = workspace.looseItemIds.filter((id) => !itemIds.includes(id));
    for (const collection of Object.values(this.data.collections)) collection.itemIds = collection.itemIds.filter((id) => !itemIds.includes(id));
    for (const item of Object.values(this.data.items)) item.childItemIds = ((_f = item.childItemIds) != null ? _f : []).filter((id) => !itemIds.includes(id));
    this.data.uiState.sideSelectedItemIds = this.data.uiState.sideSelectedItemIds.filter((id) => !itemIds.includes(id));
    for (const id of itemIds) {
      delete this.data.uiState.sideItemFaces[id];
      delete this.data.uiState.miniItemFaces[id];
    }
    this.data.uiState.miniPalette.collectSelectedItemIds = this.data.uiState.miniPalette.collectSelectedItemIds.filter((id) => !itemIds.includes(id));
    this.data.uiState.miniPalette.storageSelectedItemIds = this.data.uiState.miniPalette.storageSelectedItemIds.filter((id) => !itemIds.includes(id));
    this.data.uiState.miniPalette.storageItemIds = this.data.uiState.miniPalette.storageItemIds.filter((id) => !itemIds.includes(id));
    this.data.uiState.miniPalette.selectedItemIds = [];
    if (this.data.uiState.miniPalette.focusedItemId && itemIds.includes(this.data.uiState.miniPalette.focusedItemId)) this.data.uiState.miniPalette.focusedItemId = null;
    if (this.data.uiState.selectedItemId && itemIds.includes(this.data.uiState.selectedItemId)) this.data.uiState.selectedItemId = null;
    this.changed();
  }
  itemContainers(workspaceId) {
    const workspace = this.data.workspaces[workspaceId];
    if (!workspace) return [];
    return [workspace.looseItemIds, ...Object.values(this.data.collections).filter((entry) => entry.workspaceId === workspaceId).map((entry) => entry.itemIds), ...this.itemsForWorkspace(workspaceId).map((item) => {
      var _a;
      return (_a = item.childItemIds) != null ? _a : item.childItemIds = [];
    })];
  }
  detachWorkspaceLinks(itemId) {
    var _a;
    for (const workspace of Object.values(this.data.workspaces)) workspace.looseItemIds = workspace.looseItemIds.filter((id) => id !== itemId);
    for (const collection of Object.values(this.data.collections)) collection.itemIds = collection.itemIds.filter((id) => id !== itemId);
    for (const item of Object.values(this.data.items)) if (item.id !== itemId) item.childItemIds = ((_a = item.childItemIds) != null ? _a : []).filter((id) => id !== itemId);
  }
  /** Keeps the saved item content, but removes every Canvas-node relationship. */
  detachCanvasLinks(item) {
    delete item.origin.canvasPath;
    delete item.origin.canvasNodeId;
    item.canvasPlacements = [];
  }
  repairDuplicateCanvasItems() {
    var _a, _b, _c, _d, _e, _f, _g;
    const ownerByLocation = /* @__PURE__ */ new Map();
    const replacements = /* @__PURE__ */ new Map();
    const ordered = Object.values(this.data.items).sort((a, b) => a.createdAt - b.createdAt || a.id.localeCompare(b.id));
    for (const item of ordered) {
      const owners = this.linkedCanvasNodes(item).map((location) => ownerByLocation.get(`${location.canvasPath}
${location.nodeId}`)).filter((owner) => Boolean(owner));
      const canonical = owners[0];
      if (!canonical) {
        for (const location of this.linkedCanvasNodes(item)) ownerByLocation.set(`${location.canvasPath}
${location.nodeId}`, item);
        continue;
      }
      replacements.set(item.id, canonical.id);
      canonical.canvasPlacements = [...canonical.canvasPlacements, ...item.canvasPlacements].filter((placement, index, all) => all.findIndex((candidate) => candidate.canvasPath === placement.canvasPath && candidate.nodeIds.join("\n") === placement.nodeIds.join("\n")) === index);
      canonical.childItemIds = [.../* @__PURE__ */ new Set([...(_a = canonical.childItemIds) != null ? _a : [], ...(_b = item.childItemIds) != null ? _b : []])];
      if (item.modifiedAt > canonical.modifiedAt) {
        const createdAt = canonical.createdAt;
        Object.assign(canonical, item, { id: canonical.id, createdAt, origin: { ...item.origin, workspaceId: (_c = canonical.origin.workspaceId) != null ? _c : item.origin.workspaceId }, canvasPlacements: canonical.canvasPlacements, childItemIds: canonical.childItemIds });
      }
      for (const location of this.linkedCanvasNodes(item)) ownerByLocation.set(`${location.canvasPath}
${location.nodeId}`, canonical);
    }
    if (replacements.size === 0) return false;
    const replace = (ids) => [...new Set(ids.map((id) => {
      var _a2;
      return (_a2 = replacements.get(id)) != null ? _a2 : id;
    }))];
    for (const workspace of Object.values(this.data.workspaces)) workspace.looseItemIds = replace(workspace.looseItemIds);
    for (const collection of Object.values(this.data.collections)) collection.itemIds = replace(collection.itemIds);
    for (const item of Object.values(this.data.items)) {
      item.childItemIds = replace((_d = item.childItemIds) != null ? _d : []);
      if (item.parentItemId) item.parentItemId = (_e = replacements.get(item.parentItemId)) != null ? _e : item.parentItemId;
    }
    this.data.pendingItemIds = replace(this.data.pendingItemIds).filter((id) => !this.workspaceForItem(id));
    this.data.uiState.sideSelectedItemIds = replace(this.data.uiState.sideSelectedItemIds);
    this.data.uiState.miniPalette.collectSelectedItemIds = replace(this.data.uiState.miniPalette.collectSelectedItemIds);
    this.data.uiState.miniPalette.storageSelectedItemIds = replace(this.data.uiState.miniPalette.storageSelectedItemIds);
    this.data.uiState.miniPalette.storageItemIds = replace(this.data.uiState.miniPalette.storageItemIds);
    if (this.data.uiState.selectedItemId) this.data.uiState.selectedItemId = (_f = replacements.get(this.data.uiState.selectedItemId)) != null ? _f : this.data.uiState.selectedItemId;
    if (this.data.uiState.miniPalette.focusedItemId) this.data.uiState.miniPalette.focusedItemId = (_g = replacements.get(this.data.uiState.miniPalette.focusedItemId)) != null ? _g : this.data.uiState.miniPalette.focusedItemId;
    for (const duplicateId of replacements.keys()) delete this.data.items[duplicateId];
    return true;
  }
  isItemDescendant(itemId, ancestorId) {
    var _a, _b, _c, _d;
    let cursor = (_b = (_a = this.data.items[itemId]) == null ? void 0 : _a.parentItemId) != null ? _b : null;
    while (cursor) {
      if (cursor === ancestorId) return true;
      cursor = (_d = (_c = this.data.items[cursor]) == null ? void 0 : _c.parentItemId) != null ? _d : null;
    }
    return false;
  }
};

// src/editor/editor-manager.ts
var import_obsidian7 = require("obsidian");

// src/editor/floating-editor.ts
var import_obsidian6 = require("obsidian");
var FloatingEditor = class {
  constructor(app, target, geometry, onSave, onGeometryChanged, onClosed) {
    this.app = app;
    this.target = target;
    this.geometry = geometry;
    this.onSave = onSave;
    this.onGeometryChanged = onGeometryChanged;
    this.onClosed = onClosed;
    __publicField(this, "overlayEl", null);
    __publicField(this, "panelEl", null);
    __publicField(this, "editor", null);
    __publicField(this, "resizeObserver", null);
    __publicField(this, "geometryTimer", null);
    __publicField(this, "geometryReady", false);
    __publicField(this, "saving", false);
    __publicField(this, "closed", false);
    __publicField(this, "statusEl", null);
  }
  async open() {
    var _a, _b;
    const doc = this.app.workspace.containerEl.ownerDocument;
    const win = (_a = doc.defaultView) != null ? _a : window;
    const overlay = doc.body.createDiv({ cls: "cp-quick-editor-overlay" });
    this.overlayEl = overlay;
    const panel = overlay.createDiv({ cls: "cp-quick-editor-panel canvas-palette" });
    this.panelEl = panel;
    this.applyInitialGeometry(panel, win);
    const header = panel.createDiv({ cls: "cp-quick-editor-header" });
    header.createDiv({ cls: "cp-quick-editor-title", text: this.target.title });
    const actions = header.createDiv({ cls: "cp-quick-editor-actions" });
    this.createIconButton(actions, "save", "Save (Ctrl+S)", () => void this.save());
    this.createIconButton(actions, "x", "Save and close (Esc)", () => void this.close(true));
    this.registerDragging(header, panel, win);
    const body = panel.createDiv({ cls: "cp-quick-editor-body" });
    const editorHost = body.createDiv({ cls: "cp-native-editor-host" });
    this.statusEl = panel.createDiv({ cls: "cp-quick-editor-status", text: this.target.kind === "file" ? this.target.file.path : "Canvas Palette card" });
    this.editor = new NativeMarkdownEditor(this.app, this.target);
    try {
      await this.editor.mount(editorHost);
    } catch (error) {
      this.editor.detach();
      (_b = this.overlayEl) == null ? void 0 : _b.remove();
      this.overlayEl = null;
      this.panelEl = null;
      throw error;
    }
    panel.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        event.preventDefault();
        event.stopPropagation();
        void this.close(true);
      } else if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s") {
        event.preventDefault();
        event.stopPropagation();
        void this.save();
      }
    }, true);
    this.resizeObserver = new ResizeObserver(() => {
      var _a2;
      (_a2 = this.editor) == null ? void 0 : _a2.remeasure();
      if (this.geometryReady) this.scheduleGeometrySave();
    });
    this.resizeObserver.observe(panel);
    win.setTimeout(() => {
      this.geometryReady = true;
    }, 0);
  }
  async close(saveChanges) {
    var _a, _b, _c;
    if (this.closed) return;
    this.closed = true;
    if (saveChanges) {
      try {
        await this.save();
      } catch (e) {
        this.closed = false;
        return;
      }
    }
    this.saveGeometryNow();
    (_a = this.resizeObserver) == null ? void 0 : _a.disconnect();
    this.resizeObserver = null;
    (_b = this.editor) == null ? void 0 : _b.detach();
    this.editor = null;
    (_c = this.overlayEl) == null ? void 0 : _c.remove();
    this.overlayEl = null;
    this.panelEl = null;
    this.onClosed();
  }
  async save() {
    var _a, _b, _c;
    if (this.saving) return;
    this.saving = true;
    this.updateStatus("Saving\u2026");
    try {
      const text = (_b = (_a = this.editor) == null ? void 0 : _a.getText()) != null ? _b : this.target.initialText;
      await ((_c = this.editor) == null ? void 0 : _c.saveFile());
      await this.onSave(text);
      this.updateStatus("Saved");
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      new import_obsidian6.Notice(`Canvas Palette could not save: ${message}`);
      this.updateStatus("Save failed");
      throw error;
    } finally {
      this.saving = false;
    }
  }
  applyInitialGeometry(panel, win) {
    var _a, _b, _c, _d;
    const margin = 12;
    const minWidth = Math.min(480, win.innerWidth - margin * 2);
    const minHeight = Math.min(320, win.innerHeight - margin * 2);
    const width = Math.max(minWidth, Math.min((_a = this.geometry.width) != null ? _a : win.innerWidth * 0.75, win.innerWidth - margin * 2));
    const height = Math.max(minHeight, Math.min((_b = this.geometry.height) != null ? _b : win.innerHeight * 0.8, win.innerHeight - margin * 2));
    const left = this.clamp((_c = this.geometry.x) != null ? _c : (win.innerWidth - width) / 2, margin, Math.max(margin, win.innerWidth - width - margin));
    const top = this.clamp((_d = this.geometry.y) != null ? _d : (win.innerHeight - height) / 2, margin, Math.max(margin, win.innerHeight - height - margin));
    panel.style.left = `${left}px`;
    panel.style.top = `${top}px`;
    panel.style.width = `${width}px`;
    panel.style.height = `${height}px`;
  }
  registerDragging(header, panel, win) {
    header.addEventListener("pointerdown", (event) => {
      if (event.button !== 0 || event.target.closest("button")) return;
      event.preventDefault();
      const startX = event.clientX;
      const startY = event.clientY;
      const startLeft = panel.offsetLeft;
      const startTop = panel.offsetTop;
      header.setPointerCapture(event.pointerId);
      header.addClass("is-dragging");
      const move = (moveEvent) => {
        panel.style.left = `${this.clamp(startLeft + moveEvent.clientX - startX, 0, Math.max(0, win.innerWidth - panel.offsetWidth))}px`;
        panel.style.top = `${this.clamp(startTop + moveEvent.clientY - startY, 0, Math.max(0, win.innerHeight - panel.offsetHeight))}px`;
      };
      const finish = () => {
        header.removeClass("is-dragging");
        header.removeEventListener("pointermove", move);
        header.removeEventListener("pointerup", finish);
        header.removeEventListener("pointercancel", finish);
        this.saveGeometryNow();
      };
      header.addEventListener("pointermove", move);
      header.addEventListener("pointerup", finish);
      header.addEventListener("pointercancel", finish);
    });
  }
  scheduleGeometrySave() {
    var _a, _b;
    const win = (_b = (_a = this.panelEl) == null ? void 0 : _a.ownerDocument.defaultView) != null ? _b : window;
    if (this.geometryTimer !== null) win.clearTimeout(this.geometryTimer);
    this.geometryTimer = win.setTimeout(() => {
      this.geometryTimer = null;
      this.saveGeometryNow();
    }, 200);
  }
  saveGeometryNow() {
    var _a;
    const panel = this.panelEl;
    if (!panel) return;
    const win = (_a = panel.ownerDocument.defaultView) != null ? _a : window;
    if (this.geometryTimer !== null) {
      win.clearTimeout(this.geometryTimer);
      this.geometryTimer = null;
    }
    this.geometry.x = panel.offsetLeft;
    this.geometry.y = panel.offsetTop;
    this.geometry.width = panel.offsetWidth;
    this.geometry.height = panel.offsetHeight;
    this.onGeometryChanged();
  }
  createIconButton(parent, icon, label, onClick) {
    const button = parent.createEl("button", { cls: "clickable-icon", attr: { type: "button", "aria-label": label } });
    (0, import_obsidian6.setIcon)(button, icon);
    button.addEventListener("click", (event) => {
      event.preventDefault();
      onClick();
    });
    return button;
  }
  updateStatus(text) {
    var _a;
    (_a = this.statusEl) == null ? void 0 : _a.setText(text);
  }
  clamp(value, minimum, maximum) {
    return Math.max(minimum, Math.min(maximum, value));
  }
};

// src/editor/editor-manager.ts
var PaletteEditorManager = class {
  constructor(app, plugin) {
    this.app = app;
    this.plugin = plugin;
    __publicField(this, "activeEditor", null);
  }
  async openItem(itemId) {
    const target = await this.buildTarget(itemId);
    if (!target) return false;
    return this.openTarget(target, (text) => {
      const item = this.plugin.store.data.items[itemId];
      if (!item) return;
      this.plugin.store.updateItem(itemId, { displayTitle: item.displayTitle, tags: item.tags, label: item.label, caption: item.caption, content: text });
    });
  }
  async openBack(itemId) {
    const item = this.plugin.store.data.items[itemId];
    if (!item) return false;
    return this.openTarget({ itemId, kind: "card", file: null, title: `${item.displayTitle} \u2014 Back`, initialText: item.backContent }, (text) => this.plugin.store.setItemBack(itemId, text));
  }
  async openTarget(target, onSave) {
    if (this.activeEditor) await this.activeEditor.close(true);
    const editor = new FloatingEditor(
      this.app,
      target,
      this.plugin.store.data.uiState.quickEditor,
      onSave,
      () => this.plugin.store.changed(),
      () => {
        if (this.activeEditor === editor) this.activeEditor = null;
      }
    );
    this.activeEditor = editor;
    try {
      await editor.open();
    } catch (error) {
      this.activeEditor = null;
      const message = error instanceof Error ? error.message : String(error);
      new import_obsidian7.Notice(`Could not open the Obsidian editor: ${message}`);
    }
    return true;
  }
  async close() {
    var _a;
    await ((_a = this.activeEditor) == null ? void 0 : _a.close(true));
  }
  async buildTarget(itemId) {
    var _a;
    const item = this.plugin.store.data.items[itemId];
    if (!item || item.type !== "card" && item.type !== "markdown") return null;
    if (item.type === "markdown") {
      const file = item.origin.filePath ? this.app.vault.getAbstractFileByPath(item.origin.filePath) : null;
      if (!(file instanceof import_obsidian7.TFile) || file.extension.toLowerCase() !== "md") {
        new import_obsidian7.Notice("The original Markdown file is unavailable.");
        return null;
      }
      return { itemId, kind: "file", file, title: item.displayTitle, initialText: await this.app.vault.cachedRead(file) };
    }
    return { itemId, kind: "card", file: null, title: item.displayTitle, initialText: (_a = item.content) != null ? _a : "" };
  }
};

// src/mini-palette/floating-mini-palette.ts
var import_obsidian10 = require("obsidian");

// src/ui/modal.ts
var import_obsidian8 = require("obsidian");

// src/ui/label-color-picker.ts
var DEFAULT_LABEL_COLORS = ["#a3a3a3", "#ef3340", "#f97300", "#eab308", "#16b85a", "#14b8a6", "#7c3aed"];
function createLabelColorPicker(parent, initialValue, savedCustomColors, onAddCustomColor) {
  var _a;
  const root = parent.createDiv({ cls: "cp-label-color-picker" });
  const defaults = root.createDiv({ cls: "cp-label-color-presets" });
  const customSection = root.createDiv({ cls: "cp-label-color-custom" });
  customSection.createDiv({ cls: "cp-label-color-custom__title", text: "Custom colors" });
  const custom = customSection.createDiv({ cls: "cp-label-color-presets" });
  const native = root.createEl("input", { cls: "cp-label-color-native", attr: { type: "color", "aria-label": "Add custom label color" } });
  const normalizedCustom = [...new Set(savedCustomColors.map(normalizeColor).filter((color) => Boolean(color) && !DEFAULT_LABEL_COLORS.includes(color)))];
  let value = (_a = normalizeColor(initialValue)) != null ? _a : DEFAULT_LABEL_COLORS[6];
  if (!DEFAULT_LABEL_COLORS.includes(value) && !normalizedCustom.includes(value)) normalizedCustom.unshift(value);
  const select = (color) => {
    value = color;
    render();
  };
  const swatch = (target, color) => {
    const button = target.createEl("button", { cls: `cp-label-color-swatch${value === color ? " is-selected" : ""}`, attr: { type: "button", "aria-label": `Label color ${color}`, "aria-pressed": String(value === color) } });
    button.style.setProperty("--cp-swatch-color", color);
    button.addEventListener("click", () => select(color));
  };
  const render = () => {
    defaults.empty();
    for (const color of DEFAULT_LABEL_COLORS) swatch(defaults, color);
    const add = defaults.createEl("button", { cls: "cp-label-color-swatch cp-label-color-add", text: "+", attr: { type: "button", "aria-label": "Add custom label color" } });
    add.addEventListener("click", () => {
      native.value = value;
      native.click();
    });
    custom.empty();
    for (const color of normalizedCustom) swatch(custom, color);
    customSection.toggleClass("is-empty", normalizedCustom.length === 0);
  };
  native.addEventListener("change", () => {
    const color = normalizeColor(native.value);
    if (!color) return;
    if (!DEFAULT_LABEL_COLORS.includes(color) && !normalizedCustom.includes(color)) {
      normalizedCustom.push(color);
      onAddCustomColor(color);
    }
    select(color);
  });
  render();
  return { get value() {
    return value;
  } };
}
function normalizeColor(value) {
  const color = value == null ? void 0 : value.trim().toLowerCase();
  return color && /^#[0-9a-f]{6}$/.test(color) ? color : null;
}

// src/ui/modal.ts
var MetadataEditorModal = class extends import_obsidian8.Modal {
  constructor(app, plugin, initial, onSave) {
    super(app);
    this.plugin = plugin;
    this.initial = initial;
    this.onSave = onSave;
  }
  onOpen() {
    this.contentEl.addClass("canvas-palette", "cp-metadata-editor");
    this.contentEl.createEl("h2", { text: "Palette metadata" });
    this.contentEl.createEl("label", { text: "Tags" });
    const tags = this.contentEl.createEl("input", { value: this.initial.tags.join(", "), attr: { placeholder: "tag1, tag2" } });
    this.contentEl.createEl("label", { text: "Label" });
    const label = this.contentEl.createEl("input", { value: this.initial.label, attr: { placeholder: "e.g. In progress" } });
    this.contentEl.createEl("label", { text: "Label color" });
    const labelColor = createLabelColorPicker(this.contentEl, this.initial.labelColor, this.plugin.store.data.settings.labelColorPresets, (color) => this.plugin.store.addLabelColorPreset(color));
    this.contentEl.createEl("label", { text: "Caption" });
    const caption = this.contentEl.createEl("textarea", { text: this.initial.caption, attr: { placeholder: "Short description" } });
    const actions = this.contentEl.createDiv({ cls: "cp-modal-actions" });
    actions.createEl("button", { text: "Cancel" }).addEventListener("click", () => this.close());
    actions.createEl("button", { text: "Save", cls: "mod-cta" }).addEventListener("click", () => {
      const labelValue = label.value.trim();
      this.onSave({ tags: [...new Set(tags.value.split(",").map((tag) => tag.trim().replace(/^#/, "")).filter(Boolean))], label: labelValue, labelColor: labelValue ? labelColor.value : "", caption: caption.value.trim() });
      this.close();
    });
  }
  onClose() {
    this.contentEl.empty();
  }
};
var TextPromptModal = class extends import_obsidian8.Modal {
  constructor(app, title, initial, onSubmit, placeholder = "") {
    super(app);
    this.title = title;
    this.onSubmit = onSubmit;
    this.placeholder = placeholder;
    __publicField(this, "value");
    this.value = initial;
  }
  onOpen() {
    this.contentEl.createEl("h2", { text: this.title });
    new import_obsidian8.Setting(this.contentEl).addText((text) => text.setValue(this.value).setPlaceholder(this.placeholder).onChange((value) => {
      this.value = value;
    }));
    new import_obsidian8.Setting(this.contentEl).addButton((button) => button.setButtonText("Save").setCta().onClick(async () => {
      const value = this.value.trim();
      if (!value) return;
      button.setDisabled(true);
      try {
        if (await this.onSubmit(value) !== false) this.close();
      } finally {
        button.setDisabled(false);
      }
    }));
  }
  onClose() {
    this.contentEl.empty();
  }
};
var ConfirmDeleteModal = class extends import_obsidian8.Modal {
  constructor(app, count, onConfirm) {
    super(app);
    this.count = count;
    this.onConfirm = onConfirm;
  }
  onOpen() {
    this.contentEl.addClass("canvas-palette", "cp-confirm-modal");
    this.contentEl.createEl("h2", { text: "Delete Palette items?" });
    this.contentEl.createEl("p", { text: `${this.count} selected item${this.count === 1 ? "" : "s"} will be removed from Canvas Palette. Original Vault files and Canvas nodes will not be deleted.` });
    const actions = this.contentEl.createDiv({ cls: "cp-modal-actions" });
    actions.createEl("button", { text: "Cancel" }).addEventListener("click", () => this.close());
    actions.createEl("button", { text: "Delete", cls: "mod-warning" }).addEventListener("click", () => {
      this.onConfirm();
      this.close();
    });
  }
  onClose() {
    this.contentEl.empty();
  }
};
var ConfirmMiniStorageRemovalModal = class extends import_obsidian8.Modal {
  constructor(app, count, onConfirm) {
    super(app);
    this.count = count;
    this.onConfirm = onConfirm;
  }
  onOpen() {
    this.contentEl.addClass("canvas-palette", "cp-confirm-modal");
    this.contentEl.createEl("h2", { text: "Remove from Mini Palette?" });
    this.contentEl.createEl("p", { text: `${this.count} selected link${this.count === 1 ? "" : "s"} will be removed from Mini Palette only. Side Palette, Workspace items, original Vault files, and Canvas nodes will remain unchanged.` });
    const actions = this.contentEl.createDiv({ cls: "cp-modal-actions" });
    actions.createEl("button", { text: "Cancel" }).addEventListener("click", () => this.close());
    actions.createEl("button", { text: "Remove from Mini", cls: "mod-warning" }).addEventListener("click", () => {
      this.onConfirm();
      this.close();
    });
  }
  onClose() {
    this.contentEl.empty();
  }
};
var ConfirmForeignCanvasWorkspaceModal = class extends import_obsidian8.Modal {
  constructor(app, workspaceName, onConfirm) {
    super(app);
    this.workspaceName = workspaceName;
    this.onConfirm = onConfirm;
  }
  onOpen() {
    this.contentEl.addClass("canvas-palette", "cp-confirm-modal");
    this.contentEl.createEl("h2", { text: "\uB2E4\uB978 Canvas\uC758 \uB300\uD45C Workspace\uC5D0 \uC800\uC7A5\uD560\uAE4C\uC694?" });
    this.contentEl.createEl("p", { text: `\u201C${this.workspaceName}\u201D\uC740 \uD604\uC7AC Canvas\uAC00 \uC544\uB2CC \uB2E4\uB978 Canvas\uC758 \uB300\uD45C Workspace\uC785\uB2C8\uB2E4.` });
    this.contentEl.createEl("p", { text: "\uC120\uD0DD\uD55C \uD56D\uBAA9\uC740 \uD604\uC7AC Canvas\uC640 \uC5F0\uACB0\uB418\uC9C0 \uC54A\uC740 \uC0C1\uD0DC\uB85C \uC800\uC7A5\uB429\uB2C8\uB2E4." });
    const actions = this.contentEl.createDiv({ cls: "cp-modal-actions" });
    actions.createEl("button", { text: "\uCDE8\uC18C" }).addEventListener("click", () => this.close());
    actions.createEl("button", { text: "\uC800\uC7A5", cls: "mod-cta" }).addEventListener("click", () => {
      this.onConfirm();
      this.close();
    });
  }
  onClose() {
    this.contentEl.empty();
  }
};
var AlreadySavedToWorkspaceModal = class extends import_obsidian8.Modal {
  constructor(app, workspaceName, savedCount, alreadySavedCount) {
    super(app);
    this.workspaceName = workspaceName;
    this.savedCount = savedCount;
    this.alreadySavedCount = alreadySavedCount;
  }
  onOpen() {
    this.contentEl.addClass("canvas-palette", "cp-confirm-modal");
    this.contentEl.createEl("h2", { text: "\uC774\uBBF8 Side Palette\uC5D0 \uC800\uC7A5\uB41C \uD56D\uBAA9\uC785\uB2C8\uB2E4" });
    this.contentEl.createEl("p", { text: `\u201C${this.workspaceName}\u201D\uC5D0 \uC774\uBBF8 \uC800\uC7A5\uB41C \uD56D\uBAA9 ${this.alreadySavedCount}\uAC1C\uB294 \uC911\uBCF5 \uC800\uC7A5\uD558\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.` });
    if (this.savedCount > 0) this.contentEl.createEl("p", { text: `${this.savedCount}\uAC1C \uD56D\uBAA9\uC740 \uC0C8\uB85C \uC800\uC7A5\uB418\uC5C8\uC2B5\uB2C8\uB2E4.` });
    const actions = this.contentEl.createDiv({ cls: "cp-modal-actions" });
    actions.createEl("button", { text: "\uD655\uC778", cls: "mod-cta" }).addEventListener("click", () => this.close());
  }
  onClose() {
    this.contentEl.empty();
  }
};
var ConfirmDeleteCollectionModal = class extends import_obsidian8.Modal {
  constructor(app, name, destination, itemCount, childCount, onConfirm) {
    super(app);
    this.name = name;
    this.destination = destination;
    this.itemCount = itemCount;
    this.childCount = childCount;
    this.onConfirm = onConfirm;
  }
  onOpen() {
    this.contentEl.addClass("canvas-palette", "cp-confirm-modal");
    this.contentEl.createEl("h2", { text: "Delete Collection?" });
    this.contentEl.createEl("p", { text: `\u201C${this.name}\u201D will be removed. Its ${this.itemCount} item${this.itemCount === 1 ? "" : "s"} and ${this.childCount} nested Collection${this.childCount === 1 ? "" : "s"} will move to ${this.destination}. No Palette items, Vault files, or Canvas nodes will be deleted.` });
    const actions = this.contentEl.createDiv({ cls: "cp-modal-actions" });
    actions.createEl("button", { text: "Cancel" }).addEventListener("click", () => this.close());
    actions.createEl("button", { text: "Delete Collection", cls: "mod-warning" }).addEventListener("click", () => {
      this.onConfirm();
      this.close();
    });
  }
  onClose() {
    this.contentEl.empty();
  }
};
var CanvasTargetModal = class extends import_obsidian8.Modal {
  constructor(app, files, activePath, onResolve) {
    var _a, _b;
    super(app);
    this.files = files;
    this.onResolve = onResolve;
    __publicField(this, "selectedPath");
    __publicField(this, "resolved", false);
    this.selectedPath = activePath && files.some((file) => file.path === activePath) ? activePath : (_b = (_a = files[0]) == null ? void 0 : _a.path) != null ? _b : null;
  }
  onOpen() {
    this.contentEl.addClass("canvas-palette", "cp-canvas-target-modal");
    this.contentEl.createEl("h2", { text: "Choose Canvas" });
    this.contentEl.createEl("p", { text: "Choose an existing Canvas, then click an empty area to place the export." });
    const search = this.contentEl.createEl("input", { attr: { type: "search", placeholder: "Search Canvas files\u2026", "aria-label": "Search Canvas files" } });
    const list = this.contentEl.createDiv({ cls: "cp-canvas-target-list" });
    const render = () => {
      list.empty();
      const query = search.value.trim().toLocaleLowerCase();
      for (const file of this.files.filter((candidate) => !query || candidate.path.toLocaleLowerCase().includes(query))) {
        const row = list.createEl("button", { cls: "cp-canvas-target-row", text: file.path, attr: { type: "button", "aria-pressed": String(file.path === this.selectedPath) } });
        if (file.path === this.selectedPath) row.addClass("is-active");
        row.addEventListener("click", () => {
          this.selectedPath = file.path;
          render();
        });
      }
      if (list.childElementCount === 0) list.createDiv({ cls: "cp-empty", text: "No matching Canvas files." });
    };
    search.addEventListener("input", render);
    render();
    const actions = this.contentEl.createDiv({ cls: "cp-modal-actions" });
    actions.createEl("button", { text: "Cancel" }).addEventListener("click", () => this.finish(null));
    actions.createEl("button", { text: "Choose Canvas", cls: "mod-cta" }).addEventListener("click", () => {
      var _a;
      return this.finish((_a = this.files.find((file) => file.path === this.selectedPath)) != null ? _a : null);
    });
    window.requestAnimationFrame(() => search.focus());
  }
  onClose() {
    if (!this.resolved) this.finish(null);
    this.contentEl.empty();
  }
  finish(file) {
    if (this.resolved) return;
    this.resolved = true;
    this.onResolve(file);
    this.close();
  }
};
var ConfirmExportDuplicateModal = class extends import_obsidian8.Modal {
  constructor(app, count, onResolve) {
    super(app);
    this.count = count;
    this.onResolve = onResolve;
    __publicField(this, "resolved", false);
  }
  onOpen() {
    this.contentEl.addClass("canvas-palette", "cp-confirm-modal");
    this.contentEl.createEl("h2", { text: "Some exported items are already on this Canvas" });
    this.contentEl.createEl("p", { text: `${this.count} linked item${this.count === 1 ? " is" : "s are"} already placed on the target Canvas.` });
    const actions = this.contentEl.createDiv({ cls: "cp-modal-actions" });
    actions.createEl("button", { text: "Cancel" }).addEventListener("click", () => this.finish(null));
    actions.createEl("button", { text: "Keep existing and add", cls: "mod-cta" }).addEventListener("click", () => this.finish("copy"));
    actions.createEl("button", { text: "Replace existing", cls: "mod-warning" }).addEventListener("click", () => this.finish("replace"));
  }
  onClose() {
    if (!this.resolved) this.finish(null);
    this.contentEl.empty();
  }
  finish(choice) {
    if (this.resolved) return;
    this.resolved = true;
    this.onResolve(choice);
    this.close();
  }
};
var TagLabelModal = class extends import_obsidian8.Modal {
  constructor(app, plugin, itemIds) {
    super(app);
    this.plugin = plugin;
    this.itemIds = itemIds;
    __publicField(this, "outsideClick", null);
  }
  onOpen() {
    const items = this.itemIds.map((id) => this.plugin.store.data.items[id]).filter((item) => Boolean(item));
    if (items.length === 0) {
      this.close();
      return;
    }
    const workspaceItems = this.plugin.store.itemsForWorkspace(this.plugin.store.data.uiState.activeWorkspaceId);
    const knownTags = [.../* @__PURE__ */ new Set([...workspaceItems.flatMap((item) => item.tags), ...items.flatMap((item) => item.tags)])].sort((a, b) => a.localeCompare(b));
    const knownLabels = [...new Set([...workspaceItems.map((item) => item.label), ...items.map((item) => item.label)].filter(Boolean))].sort((a, b) => a.localeCompare(b));
    const labelColors = /* @__PURE__ */ new Map();
    for (const item of [...workspaceItems, ...items]) if (item.label && item.labelColor && !labelColors.has(item.label)) labelColors.set(item.label, item.labelColor);
    this.modalEl.addClass("cp-tag-label-shell");
    this.contentEl.addClass("canvas-palette", "cp-tag-label-modal");
    this.contentEl.createEl("h2", { text: items.length === 1 ? "Tags, label & caption" : `Tags, label & caption \xB7 ${items.length} items` });
    const tagSection = this.contentEl.createDiv({ cls: "cp-metadata-picker-section" });
    const tagHeading = tagSection.createDiv({ cls: "cp-metadata-picker-heading" });
    tagHeading.createEl("h3", { text: "Tags" });
    const tagCount = tagHeading.createSpan({ cls: "cp-metadata-picker-count" });
    const tagPicker = tagSection.createDiv({ cls: "cp-metadata-picker" });
    const tagSummary = tagPicker.createEl("button", { cls: "cp-metadata-picker-summary", attr: { type: "button", "aria-haspopup": "listbox", "aria-expanded": "false" } });
    const tagPanel = tagPicker.createDiv({ cls: "cp-metadata-picker-panel" });
    tagPanel.hidden = true;
    const tagSearch = tagPanel.createEl("input", { cls: "cp-metadata-picker-search", attr: { type: "search", placeholder: "Search tags", "aria-label": "Search tags" } });
    const tagStates = /* @__PURE__ */ new Map();
    const touchedTags = /* @__PURE__ */ new Set();
    for (const tag of knownTags) {
      const count = items.filter((item) => item.tags.includes(tag)).length;
      tagStates.set(tag, count === items.length ? "all" : count > 0 ? "mixed" : "none");
    }
    const tagListHost = tagPanel.createDiv({ cls: "cp-metadata-picker-list" });
    const updateTagSummary = () => {
      const selected = knownTags.filter((tag) => tagStates.get(tag) !== "none");
      tagCount.setText(`Selected ${selected.length} / Total ${knownTags.length}`);
      tagSummary.empty();
      const visible = selected.slice(0, 2);
      for (const tag of visible) tagSummary.createSpan({ cls: "cp-metadata-picker-chip", text: `#${tag}` });
      if (selected.length > visible.length) tagSummary.createSpan({ cls: "cp-metadata-picker-more", text: `+${selected.length - visible.length}` });
      if (selected.length === 0) tagSummary.createSpan({ cls: "cp-metadata-picker-placeholder", text: "Select tags" });
      tagSummary.createSpan({ cls: "cp-metadata-picker-chevron", text: "\u2304" });
    };
    const renderTags = this.virtualList(tagListHost, (tag) => {
      var _a;
      const row = createDiv({ cls: "cp-metadata-picker-row" });
      row.setAttribute("role", "option");
      row.tabIndex = 0;
      const checkbox = row.createEl("input", { attr: { type: "checkbox", tabindex: "-1" } });
      const state = (_a = tagStates.get(tag)) != null ? _a : "none";
      checkbox.checked = state === "all";
      checkbox.indeterminate = state === "mixed";
      row.createSpan({ text: `#${tag}` });
      const toggleTag = () => {
        tagStates.set(tag, state === "all" ? "none" : "all");
        touchedTags.add(tag);
        updateTagSummary();
        filterTags();
      };
      row.addEventListener("click", toggleTag);
      row.addEventListener("keydown", (event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          toggleTag();
        }
      });
      return row;
    });
    const filterTags = () => {
      const query = tagSearch.value.trim().toLocaleLowerCase();
      renderTags(knownTags.filter((tag) => !query || tag.toLocaleLowerCase().includes(query)));
    };
    tagSearch.addEventListener("input", filterTags);
    const newTagRow = tagPanel.createDiv({ cls: "cp-metadata-picker-create" });
    const newTag = newTagRow.createEl("input", { attr: { placeholder: "New tag", "aria-label": "New tag" } });
    const addTag = newTagRow.createEl("button", { text: "Add", attr: { type: "button" } });
    const createTag = () => {
      const tag = newTag.value.trim().replace(/^#/, "");
      if (!tag) return;
      if (!tagStates.has(tag)) {
        knownTags.push(tag);
        knownTags.sort((a, b) => a.localeCompare(b));
      }
      tagStates.set(tag, "all");
      touchedTags.add(tag);
      newTag.value = "";
      tagSearch.value = "";
      updateTagSummary();
      filterTags();
    };
    addTag.addEventListener("click", createTag);
    newTag.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        createTag();
      }
    });
    updateTagSummary();
    filterTags();
    const labelSection = this.contentEl.createDiv({ cls: "cp-metadata-picker-section" });
    labelSection.createEl("h3", { text: "Label" });
    const currentLabels = new Set(items.map((item) => item.label));
    let selectedLabel = currentLabels.size === 1 ? items[0].label : "__keep__";
    let labelTouched = false;
    const labelPicker = labelSection.createDiv({ cls: "cp-metadata-picker" });
    const labelSummary = labelPicker.createEl("button", { cls: "cp-metadata-picker-summary", attr: { type: "button", "aria-haspopup": "listbox", "aria-expanded": "false" } });
    const labelPanel = labelPicker.createDiv({ cls: "cp-metadata-picker-panel" });
    labelPanel.hidden = true;
    const labelSearch = labelPanel.createEl("input", { cls: "cp-metadata-picker-search", attr: { type: "search", placeholder: "Search labels", "aria-label": "Search labels" } });
    const labelListHost = labelPanel.createDiv({ cls: "cp-metadata-picker-list" });
    const sharedColors = new Set(items.map((item) => {
      var _a;
      return (_a = item.labelColor) != null ? _a : "";
    }));
    const labelCreate = labelPanel.createDiv({ cls: "cp-metadata-picker-create" });
    const newLabel = labelCreate.createEl("input", { attr: { placeholder: "New label", "aria-label": "New label" } });
    const labelColor = labelCreate.createEl("input", { cls: "cp-metadata-picker-color", attr: { type: "color", "aria-label": "Label color" } });
    labelColor.value = sharedColors.size === 1 && items[0].labelColor ? items[0].labelColor : "#8b5cf6";
    let colorTouched = false;
    labelColor.addEventListener("input", () => {
      colorTouched = true;
    });
    const addLabel = labelCreate.createEl("button", { text: "Add", attr: { type: "button" } });
    const updateLabelSummary = () => {
      var _a;
      labelSummary.empty();
      if (selectedLabel === "__keep__") labelSummary.createSpan({ cls: "cp-metadata-picker-placeholder", text: "Keep current labels" });
      else if (!selectedLabel) labelSummary.createSpan({ cls: "cp-metadata-picker-placeholder", text: "No label" });
      else {
        const swatch = labelSummary.createSpan({ cls: "cp-metadata-picker-swatch" });
        swatch.style.backgroundColor = (_a = labelColors.get(selectedLabel)) != null ? _a : labelColor.value;
        labelSummary.createSpan({ cls: "cp-metadata-picker-value", text: selectedLabel });
      }
      labelSummary.createSpan({ cls: "cp-metadata-picker-chevron", text: "\u2304" });
    };
    const labelChoices = () => [...currentLabels.size > 1 ? ["__keep__"] : [], "", ...knownLabels];
    const renderLabels = this.virtualList(labelListHost, (label) => {
      var _a;
      const row = createDiv({ cls: "cp-metadata-picker-row" });
      row.setAttribute("role", "option");
      row.tabIndex = 0;
      const radio = row.createEl("input", { attr: { type: "radio", tabindex: "-1" } });
      radio.checked = label === selectedLabel;
      if (label && label !== "__keep__") {
        const swatch = row.createSpan({ cls: "cp-metadata-picker-swatch" });
        swatch.style.backgroundColor = (_a = labelColors.get(label)) != null ? _a : "#8b5cf6";
      }
      row.createSpan({ text: label === "__keep__" ? "Keep current labels" : label || "No label" });
      const chooseLabel = () => {
        selectedLabel = label;
        labelTouched = true;
        const knownColor = labelColors.get(label);
        if (knownColor) labelColor.value = knownColor;
        updateLabelSummary();
        filterLabels();
        closePanel(labelPanel, labelSummary);
      };
      row.addEventListener("click", chooseLabel);
      row.addEventListener("keydown", (event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          chooseLabel();
        }
      });
      return row;
    });
    const filterLabels = () => {
      const query = labelSearch.value.trim().toLocaleLowerCase();
      renderLabels(labelChoices().filter((label) => label === "__keep__" || !query || label.toLocaleLowerCase().includes(query)));
    };
    labelSearch.addEventListener("input", filterLabels);
    const createLabel = () => {
      const label = newLabel.value.trim();
      if (!label) return;
      if (!knownLabels.includes(label)) {
        knownLabels.push(label);
        knownLabels.sort((a, b) => a.localeCompare(b));
      }
      labelColors.set(label, labelColor.value);
      selectedLabel = label;
      labelTouched = true;
      colorTouched = true;
      newLabel.value = "";
      labelSearch.value = "";
      updateLabelSummary();
      filterLabels();
      closePanel(labelPanel, labelSummary);
    };
    addLabel.addEventListener("click", createLabel);
    newLabel.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        createLabel();
      }
    });
    updateLabelSummary();
    filterLabels();
    const closePanel = (panel, summary) => {
      panel.hidden = true;
      summary.setAttribute("aria-expanded", "false");
    };
    const togglePanel = (panel, summary, otherPanel, otherSummary, search) => {
      const opening = panel.hidden;
      closePanel(otherPanel, otherSummary);
      panel.hidden = !opening;
      summary.setAttribute("aria-expanded", opening ? "true" : "false");
      if (opening) {
        search.focus();
        search.select();
      }
    };
    tagSummary.addEventListener("click", () => togglePanel(tagPanel, tagSummary, labelPanel, labelSummary, tagSearch));
    labelSummary.addEventListener("click", () => togglePanel(labelPanel, labelSummary, tagPanel, tagSummary, labelSearch));
    this.outsideClick = (event) => {
      const target = event.target;
      if (target && !tagPicker.contains(target)) closePanel(tagPanel, tagSummary);
      if (target && !labelPicker.contains(target)) closePanel(labelPanel, labelSummary);
    };
    document.addEventListener("pointerdown", this.outsideClick);
    this.contentEl.createEl("h3", { text: "Caption" });
    const sharedCaptions = new Set(items.map((item) => item.caption));
    const caption = this.contentEl.createEl("textarea", {
      cls: "cp-tag-label-caption",
      text: sharedCaptions.size === 1 ? items[0].caption : "",
      attr: { placeholder: sharedCaptions.size === 1 ? "Short description" : "Keep current captions unless changed" }
    });
    let captionTouched = false;
    caption.addEventListener("input", () => {
      captionTouched = true;
    });
    const actions = this.contentEl.createDiv({ cls: "cp-modal-actions" });
    actions.createEl("button", { text: "Cancel" }).addEventListener("click", () => this.close());
    actions.createEl("button", { text: "Apply", cls: "mod-cta" }).addEventListener("click", () => {
      var _a, _b;
      for (const item of items) {
        const tags = new Set(item.tags);
        for (const tag of touchedTags) {
          if (tagStates.get(tag) === "all") tags.add(tag);
          else tags.delete(tag);
        }
        const label = selectedLabel === "__keep__" ? item.label : selectedLabel;
        const labelChanged = labelTouched && selectedLabel !== "__keep__";
        const labelColorValue = !label ? "" : colorTouched || labelChanged ? labelColor.value : (_a = item.labelColor) != null ? _a : "";
        this.plugin.store.updateItem(item.id, { displayTitle: item.displayTitle, tags: [...tags], label, labelColor: labelColorValue, caption: captionTouched || sharedCaptions.size === 1 ? caption.value.trim() : item.caption, ...item.type === "card" ? { content: (_b = item.content) != null ? _b : "" } : {} });
      }
      this.close();
    });
  }
  onClose() {
    if (this.outsideClick) document.removeEventListener("pointerdown", this.outsideClick);
    this.outsideClick = null;
    this.contentEl.empty();
  }
  virtualList(host, createRow) {
    const rowHeight = 36;
    const overscan = 4;
    const spacer = host.createDiv({ cls: "cp-virtual-list-spacer" });
    let values = [];
    const render = () => {
      const viewportHeight = host.clientHeight || 216;
      const start = Math.max(0, Math.floor(host.scrollTop / rowHeight) - overscan);
      const end = Math.min(values.length, Math.ceil((host.scrollTop + viewportHeight) / rowHeight) + overscan);
      spacer.empty();
      spacer.style.height = `${values.length * rowHeight}px`;
      for (let index = start; index < end; index += 1) {
        const row = createRow(values[index]);
        row.style.position = "absolute";
        row.style.top = `${index * rowHeight}px`;
        row.style.height = `${rowHeight}px`;
        spacer.appendChild(row);
      }
    };
    host.addEventListener("scroll", render);
    return (nextValues) => {
      values = nextValues;
      host.scrollTop = 0;
      render();
    };
  }
};
var CardToMarkdownModal = class extends import_obsidian8.Modal {
  constructor(app, initialName, initialFolder, onConvert) {
    super(app);
    this.initialName = initialName;
    this.initialFolder = initialFolder;
    this.onConvert = onConvert;
  }
  onOpen() {
    this.contentEl.addClass("canvas-palette", "cp-card-to-markdown-modal");
    this.contentEl.createEl("h2", { text: "Convert Card to shared Markdown" });
    this.contentEl.createEl("p", { text: "Create one real Markdown file in the Vault. This Palette Card and every linked Canvas Card will both become Markdown references to that same file." });
    this.contentEl.createEl("label", { text: "File name" });
    const fileName = this.contentEl.createEl("input", { value: this.initialName, attr: { placeholder: "Card title.md" } });
    this.contentEl.createEl("label", { text: "Folder" });
    const folder = this.contentEl.createEl("input", { value: this.initialFolder, attr: { placeholder: "Vault root" } });
    const actions = this.contentEl.createDiv({ cls: "cp-modal-actions" });
    actions.createEl("button", { text: "Cancel" }).addEventListener("click", () => this.close());
    const convert = actions.createEl("button", { text: "Convert", cls: "mod-cta" });
    convert.addEventListener("click", async () => {
      convert.disabled = true;
      try {
        if (await this.onConvert(fileName.value, folder.value)) this.close();
      } finally {
        convert.disabled = false;
      }
    });
    window.requestAnimationFrame(() => {
      fileName.focus();
      fileName.select();
    });
  }
  onClose() {
    this.contentEl.empty();
  }
};
var MoveItemsModal = class extends import_obsidian8.Modal {
  constructor(app, workspaceName, collections, count, onMove) {
    super(app);
    this.workspaceName = workspaceName;
    this.collections = collections;
    this.count = count;
    this.onMove = onMove;
    __publicField(this, "query", "");
  }
  onOpen() {
    this.contentEl.addClass("canvas-palette", "cp-move-items-modal");
    this.contentEl.createEl("h2", { text: this.count === 1 ? "Move to\u2026" : `Move ${this.count} items to\u2026` });
    const search = this.contentEl.createEl("input", { cls: "cp-move-items-search", attr: { type: "search", placeholder: "Search collections\u2026", "aria-label": "Search collections" } });
    const list = this.contentEl.createDiv({ cls: "cp-move-items-list" });
    const paths = this.collectionPaths();
    const render = () => {
      list.empty();
      const needle = this.query.trim().toLocaleLowerCase();
      const destinations = [{ id: null, name: `${this.workspaceName} / Workspace root`, depth: 0 }, ...paths].filter((destination) => !needle || destination.name.toLocaleLowerCase().includes(needle));
      for (const destination of destinations) {
        const row = list.createEl("button", { cls: "cp-move-items-row", attr: { type: "button" } });
        row.style.setProperty("--cp-depth", String(destination.depth));
        row.createSpan({ cls: "cp-move-items-row__icon", text: destination.id ? "\u25B8" : "\u2302" });
        row.createSpan({ cls: "cp-move-items-row__name", text: destination.name });
        row.addEventListener("click", () => {
          this.onMove(destination.id);
          this.close();
        });
      }
      if (destinations.length === 0) list.createDiv({ cls: "cp-empty", text: "No matching collections." });
    };
    search.addEventListener("input", () => {
      this.query = search.value;
      render();
    });
    render();
    window.requestAnimationFrame(() => search.focus());
  }
  onClose() {
    this.contentEl.empty();
  }
  collectionPaths() {
    var _a;
    const byParent = /* @__PURE__ */ new Map();
    for (const collection of this.collections) byParent.set(collection.parentId, [...(_a = byParent.get(collection.parentId)) != null ? _a : [], collection]);
    const rows = [];
    const walk = (parentId, parents, depth) => {
      var _a2;
      for (const collection of (_a2 = byParent.get(parentId)) != null ? _a2 : []) {
        const path = [...parents, collection.name];
        rows.push({ id: collection.id, name: path.join(" / "), depth });
        walk(collection.id, path, depth + 1);
      }
    };
    walk(null, [], 0);
    return rows;
  }
};
var ItemEditorModal = class extends import_obsidian8.Modal {
  constructor(app, plugin, itemId) {
    super(app);
    this.plugin = plugin;
    this.itemId = itemId;
  }
  onOpen() {
    var _a;
    const item = this.plugin.store.data.items[this.itemId];
    if (!item) {
      this.close();
      return;
    }
    this.contentEl.addClass("canvas-palette", "cp-item-editor");
    const heading = this.contentEl.createDiv({ cls: "cp-item-editor__heading" });
    heading.createEl("h2", { text: "Palette item" });
    heading.createSpan({ cls: "cp-chip", text: item.type.toUpperCase() });
    const title = this.field("Title", item.displayTitle);
    const tags = this.field("Tags", item.tags.join(", "), "tag1, tag2");
    const label = this.field("Label", item.label, "e.g. Idea");
    this.contentEl.createEl("label", { text: "Label color" });
    const labelColor = this.contentEl.createEl("input", { attr: { type: "color", "aria-label": "Label color" } });
    labelColor.value = item.labelColor || "#8b5cf6";
    const caption = this.area("Caption", item.caption);
    let content;
    if (item.type === "card") content = this.area("Content", (_a = item.content) != null ? _a : "", "Write card content\u2026");
    this.contentEl.createEl("h3", { text: "Preview" });
    const preview = this.contentEl.createDiv({ cls: "cp-preview cp-item-editor__preview" });
    void this.plugin.preview.render(preview, item);
    this.renderCanvasLinks(item);
    const actions = this.contentEl.createDiv({ cls: "cp-modal-actions" });
    actions.createEl("button", { text: "Delete", cls: "mod-warning" }).addEventListener("click", () => new ConfirmDeleteModal(this.app, 1, () => {
      this.plugin.store.removeItems([item.id]);
      this.close();
    }).open());
    if (item.origin.canvasPath && item.origin.canvasNodeId) actions.createEl("button", { text: "Locate on Canvas" }).addEventListener("click", () => void this.plugin.locateItemOnCanvas(item));
    else if (item.origin.filePath) actions.createEl("button", { text: "Open source file" }).addEventListener("click", () => void this.plugin.openOriginal(item));
    actions.createEl("button", { text: "Cancel" }).addEventListener("click", () => this.close());
    actions.createEl("button", { text: "Save", cls: "mod-cta" }).addEventListener("click", () => {
      const labelValue = label.value.trim();
      this.plugin.store.updateItem(item.id, { displayTitle: title.value.trim() || "Untitled", tags: this.parseTags(tags.value), label: labelValue, labelColor: labelValue ? labelColor.value : "", caption: caption.value, ...content ? { content: content.value } : {} });
      this.close();
    });
  }
  onClose() {
    this.contentEl.empty();
  }
  field(labelText, value, placeholder = "") {
    this.contentEl.createEl("label", { text: labelText });
    return this.contentEl.createEl("input", { value, attr: { placeholder } });
  }
  area(labelText, value, placeholder = "") {
    this.contentEl.createEl("label", { text: labelText });
    return this.contentEl.createEl("textarea", { text: value, attr: { placeholder } });
  }
  parseTags(value) {
    return [...new Set(value.split(",").map((tag) => tag.trim().replace(/^#/, "")).filter(Boolean))];
  }
  renderCanvasLinks(item) {
    const paths = [...new Set([item.origin.canvasPath, ...item.canvasPlacements.map((placement) => placement.canvasPath)].filter((path) => Boolean(path)))];
    this.contentEl.createEl("h3", { text: "Linked canvases" });
    if (paths.length === 0) {
      this.contentEl.createDiv({ cls: "cp-empty cp-item-editor__empty", text: "Not linked to a Canvas yet." });
      return;
    }
    const list = this.contentEl.createDiv({ cls: "cp-canvas-link-list" });
    for (const path of paths) list.createDiv({ cls: "cp-canvas-link", text: path });
  }
};

// src/ui/resizable.ts
function makeDivider(divider, axis, onMove, onEnd) {
  divider.addEventListener("pointerdown", (event) => {
    if (event.button !== 0) return;
    event.preventDefault();
    event.stopPropagation();
    const body = divider.ownerDocument.body;
    const resizeClass = axis === "column" ? "cp-is-resizing--column" : "cp-is-resizing--row";
    let finished = false;
    divider.setPointerCapture(event.pointerId);
    body.addClass("cp-is-resizing", resizeClass);
    const move = (pointer) => {
      pointer.preventDefault();
      onMove(axis === "column" ? pointer.clientX : pointer.clientY);
    };
    const end = () => {
      if (finished) return;
      finished = true;
      body.removeClass("cp-is-resizing", resizeClass);
      divider.removeEventListener("pointermove", move);
      divider.removeEventListener("pointerup", end);
      divider.removeEventListener("pointercancel", end);
      divider.removeEventListener("lostpointercapture", end);
      onEnd == null ? void 0 : onEnd();
    };
    divider.addEventListener("pointermove", move);
    divider.addEventListener("pointerup", end);
    divider.addEventListener("pointercancel", end);
    divider.addEventListener("lostpointercapture", end);
  });
}
function makeHorizontalDivider(divider, onMove, onEnd) {
  makeDivider(divider, "column", onMove, onEnd);
}
function makeVerticalDivider(divider, onMove, onEnd) {
  makeDivider(divider, "row", onMove, onEnd);
}

// src/ui/render.ts
var import_obsidian9 = require("obsidian");
var TYPE_ICON = {
  card: "sticky-note",
  markdown: "file-text",
  image: "image",
  group: "boxes"
};
function iconButton(parent, icon, label, onClick) {
  const button = parent.createEl("button", { cls: "clickable-icon cp-icon-button", attr: { "aria-label": label, title: label, "data-tooltip-position": "top", type: "button" } });
  (0, import_obsidian9.setIcon)(button, icon);
  button.addEventListener("click", onClick);
  return button;
}
function supportsFrontBack(item) {
  return item.type !== "group";
}
function renderItem(parent, item, options) {
  var _a, _b, _c, _d, _e, _f, _g, _h;
  const canvasPaths = [...new Set([
    item.origin.canvasPath && item.origin.canvasNodeId ? item.origin.canvasPath : void 0,
    ...item.canvasPlacements.filter((placement) => placement.nodeIds.length > 0).map((placement) => placement.canvasPath)
  ].filter((path) => Boolean(path)))];
  const unlinked = (_a = options.unlinked) != null ? _a : canvasPaths.length === 0;
  const card = parent.createDiv({ cls: `cp-item cp-item--${item.type}${options.selected ? " is-selected" : ""}${options.compact ? " is-compact" : ""}` });
  card.dataset.itemId = item.id;
  card.tabIndex = 0;
  if (options.selected && options.showSelectionMarker !== false) {
    const marker = card.createSpan({ cls: "cp-item__selection", attr: { "aria-label": "Selected" } });
    (0, import_obsidian9.setIcon)(marker, "check");
  }
  const header = card.createDiv({ cls: "cp-item__header" });
  const icon = header.createSpan({ cls: "cp-item__icon" });
  (0, import_obsidian9.setIcon)(icon, TYPE_ICON[item.type]);
  icon.addClass("cp-item__type-badge", `cp-item__type-badge--${item.type}`);
  header.createSpan({ cls: "cp-item__title", text: item.displayTitle || "Untitled" });
  const face = (_b = options.currentFace) != null ? _b : "front";
  if (item.label) {
    const label = header.createSpan({ cls: "cp-label", text: item.label });
    if (item.labelColor) label.style.setProperty("--cp-label-color", item.labelColor);
  }
  if (unlinked || options.onToggleFace || options.markdownSourceStatus) {
    const actions = header.createSpan({ cls: "cp-item__header-actions" });
    if (options.markdownSourceStatus) {
      const source = options.markdownSourceStatus;
      const labels = {
        deleted: "\uC6D0\uBCF8 MD\uAC00 \uC0AD\uC81C\uB418\uC5C8\uC2B5\uB2C8\uB2E4. \uBCF5\uAD6C\uD558\uAC70\uB098 Palette\uC5D0\uC11C \uC0AD\uC81C\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4."
      };
      const icons = { deleted: "file-x" };
      const state = actions.createEl("button", { cls: `clickable-icon cp-source-state cp-source-state--${source}`, attr: { type: "button", "aria-label": labels[source], title: labels[source] } });
      (0, import_obsidian9.setIcon)(state, icons[source]);
      state.addEventListener("pointerdown", (event) => event.stopPropagation());
      state.addEventListener("click", (event) => {
        var _a2;
        event.preventDefault();
        event.stopPropagation();
        (_a2 = options.onMarkdownSourceStatus) == null ? void 0 : _a2.call(options, event);
      });
      state.addEventListener("dblclick", (event) => event.stopPropagation());
    } else if (unlinked) {
      const unlinkedBadge = actions.createSpan({ cls: "cp-item__link-state cp-item__link-state--unlinked", attr: { "aria-label": "Unlinked from Canvas", title: "Unlinked from Canvas" } });
      (0, import_obsidian9.setIcon)(unlinkedBadge, "unlink");
    }
    if (options.onToggleFace) {
      const flip = actions.createEl("button", { cls: "clickable-icon cp-face-toggle", attr: { type: "button", "aria-label": face === "front" ? "Show back" : "Show front", title: face === "front" ? "Show back" : "Show front" } });
      (0, import_obsidian9.setIcon)(flip, "refresh-cw");
      flip.addEventListener("pointerdown", (event) => event.stopPropagation());
      flip.addEventListener("click", (event) => {
        var _a2;
        event.preventDefault();
        event.stopPropagation();
        (_a2 = options.onToggleFace) == null ? void 0 : _a2.call(options, face === "front" ? "back" : "front");
      });
      flip.addEventListener("dblclick", (event) => event.stopPropagation());
    }
  }
  const body = card.createDiv({ cls: "cp-item__body" });
  body.dataset.face = face;
  if (face === "back") body.setText(item.backContent || "Write on the back\u2026");
  else if (item.type === "image" && item.origin.filePath) body.createDiv({ cls: "cp-image-placeholder", text: item.origin.filePath });
  else if (item.type === "group") body.createDiv({ text: `${(_d = (_c = item.group) == null ? void 0 : _c.nodes.length) != null ? _d : 0} nodes \xB7 ${(_f = (_e = item.group) == null ? void 0 : _e.edges.length) != null ? _f : 0} edges` });
  else body.setText(((_h = (_g = item.content) != null ? _g : item.origin.filePath) != null ? _h : "No preview").slice(0, 240));
  if (canvasPaths.length > 0) {
    const links = card.createDiv({ cls: "cp-item__canvas-links", attr: { title: canvasPaths.join("\n") } });
    const linkIcon = links.createSpan();
    (0, import_obsidian9.setIcon)(linkIcon, "workflow");
    links.createSpan({ text: canvasPaths.map(canvasName).slice(0, 2).join(", ") + (canvasPaths.length > 2 ? ` +${canvasPaths.length - 2}` : "") });
    if (item.origin.canvasPath && item.origin.canvasNodeId && options.onLocate) {
      links.addClass("is-clickable");
      links.tabIndex = 0;
      links.setAttribute("role", "button");
      links.setAttribute("aria-label", "Locate original item on Canvas");
      const locate = (event) => {
        var _a2;
        event.preventDefault();
        event.stopPropagation();
        (_a2 = options.onLocate) == null ? void 0 : _a2.call(options);
      };
      links.addEventListener("click", locate);
      links.addEventListener("dblclick", locate);
      links.addEventListener("keydown", (event) => {
        if (event.key === "Enter" || event.key === " ") locate(event);
      });
    }
  }
  const footer = card.createDiv({ cls: "cp-item__footer" });
  footer.createSpan({ text: item.tags.map((tag) => `#${tag}`).join(" ") });
  footer.createSpan({ text: new Date(item.modifiedAt).toLocaleDateString() });
  if (item.caption) card.createDiv({ cls: "cp-item__caption", text: item.caption });
  if (options.draggable) {
    card.draggable = true;
    card.addEventListener("dragstart", (event) => {
      var _a2;
      if (event.dataTransfer) {
        const draggedIds = ((_a2 = options.dragItemIds) == null ? void 0 : _a2.includes(item.id)) ? options.dragItemIds : [item.id];
        event.dataTransfer.clearData();
        event.dataTransfer.setData("application/x-canvas-palette-item", item.id);
        event.dataTransfer.setData("application/x-canvas-palette-items", JSON.stringify(draggedIds));
        event.dataTransfer.setData("application/x-canvas-palette-type", item.type);
        if (options.miniCollect) event.dataTransfer.setData("application/x-canvas-palette-mini-collect", "true");
        event.dataTransfer.effectAllowed = "copyMove";
        if (draggedIds.length > 1) {
          const dragImage = document.body.createDiv({ cls: "cp-multi-drag-image" });
          dragImage.createSpan({ text: item.displayTitle || "Selected items" });
          dragImage.createEl("strong", { text: String(draggedIds.length) });
          event.dataTransfer.setDragImage(dragImage, 20, 20);
          window.setTimeout(() => dragImage.remove(), 0);
        } else event.dataTransfer.setDragImage(card, Math.max(0, Math.min(event.offsetX, card.clientWidth)), Math.max(0, Math.min(event.offsetY, card.clientHeight)));
      }
      card.addClass("is-dragging");
    }, true);
    card.addEventListener("dragend", () => card.removeClass("is-dragging"));
  }
  let clickTimer = null;
  card.addEventListener("click", (event) => {
    if (!options.onOpen) {
      options.onSelect(event);
      return;
    }
    if (clickTimer !== null) window.clearTimeout(clickTimer);
    clickTimer = window.setTimeout(() => {
      clickTimer = null;
      options.onSelect(event);
    }, 220);
  });
  card.addEventListener("dblclick", (event) => {
    var _a2;
    if (clickTimer !== null) window.clearTimeout(clickTimer);
    clickTimer = null;
    event.preventDefault();
    event.stopPropagation();
    (_a2 = options.onOpen) == null ? void 0 : _a2.call(options);
  });
  card.addEventListener("contextmenu", (event) => {
    var _a2;
    return (_a2 = options.onContextMenu) == null ? void 0 : _a2.call(options, event);
  });
  card.addEventListener("keydown", (event) => {
    var _a2;
    if (event.key === "Enter") (_a2 = options.onOpen) == null ? void 0 : _a2.call(options);
    else if (event.key === " ") options.onSelect(event);
  });
  return card;
}
function canvasName(path) {
  var _a, _b;
  return (_b = (_a = path.split("/").pop()) == null ? void 0 : _a.replace(/\.canvas$/i, "")) != null ? _b : path;
}
function workspaceSelect(plugin, parent, value, onChange) {
  const select = parent.createEl("select", { cls: "dropdown cp-workspace-select" });
  const currentCanvas = plugin.currentCanvasPath();
  const workspaces = Object.values(plugin.store.data.workspaces).sort((a, b) => {
    const aCurrent = a.kind === "canvas" && a.ownerCanvasPath === currentCanvas;
    const bCurrent = b.kind === "canvas" && b.ownerCanvasPath === currentCanvas;
    return Number(bCurrent) - Number(aCurrent) || a.name.localeCompare(b.name, void 0, { numeric: true });
  });
  for (const workspace of workspaces) {
    const option = select.createEl("option", { text: plugin.workspaceDisplayName(workspace), value: workspace.id });
    option.selected = workspace.id === value;
  }
  select.addEventListener("change", () => onChange(select.value));
  return select;
}

// src/ui/responsive-layout.ts
var MINI_BREAKPOINTS = { wide: 900, medium: 680, narrow: 480, minimum: 360 };
var SIDE_BREAKPOINTS = { wide: 520, medium: 360, minimum: 300 };
function miniLayoutMode(width) {
  if (width >= MINI_BREAKPOINTS.wide) return "wide";
  if (width >= MINI_BREAKPOINTS.medium) return "medium";
  if (width >= MINI_BREAKPOINTS.narrow) return "narrow";
  return "minimum";
}
function sideLayoutMode(width) {
  if (width >= SIDE_BREAKPOINTS.wide) return "wide";
  if (width >= SIDE_BREAKPOINTS.medium) return "medium";
  return "very-narrow";
}
function attachedFlyoutPlacement(hostWidth, panelLeft, panelWidth, preferredSide, requestedWidth, gap = 8) {
  const rightSpace = Math.max(0, hostWidth - panelLeft - panelWidth - gap);
  const leftSpace = Math.max(0, panelLeft - gap);
  const opposite = preferredSide === "right" ? "left" : "right";
  const preferredSpace = preferredSide === "right" ? rightSpace : leftSpace;
  const oppositeSpace = opposite === "right" ? rightSpace : leftSpace;
  let side = preferredSpace >= requestedWidth || preferredSpace >= oppositeSpace ? preferredSide : opposite;
  const totalWidth = panelWidth + requestedWidth + gap;
  let nextLeft = panelLeft;
  if (totalWidth <= hostWidth) {
    if (side === "right" && rightSpace < requestedWidth) nextLeft = Math.max(0, hostWidth - totalWidth);
    if (side === "left" && leftSpace < requestedWidth) nextLeft = Math.min(hostWidth - panelWidth, requestedWidth + gap);
  }
  const available = side === "right" ? Math.max(0, hostWidth - nextLeft - panelWidth - gap) : Math.max(0, nextLeft - gap);
  return { side, width: Math.max(0, Math.min(requestedWidth, available)), panelLeft: nextLeft };
}

// src/mini-palette/floating-mini-palette.ts
var FloatingMiniPalette = class {
  constructor(plugin) {
    this.plugin = plugin;
    __publicField(this, "host");
    __publicField(this, "panel");
    __publicField(this, "unsubscribe");
    __publicField(this, "search", "");
    __publicField(this, "typeFilter", "all");
    __publicField(this, "tagFilter", "");
    __publicField(this, "labelFilter", "");
    __publicField(this, "dateFilter", "all");
    __publicField(this, "inspectorItemId", null);
    __publicField(this, "hoverItemId", null);
    __publicField(this, "rightPane");
    __publicField(this, "detachDrop");
    __publicField(this, "suppressBlankClick", false);
    __publicField(this, "layoutMode", "wide");
    __publicField(this, "resizeObserver");
    __publicField(this, "openFlyout", null);
    __publicField(this, "flyoutSide", "right");
    __publicField(this, "flyoutWidth", 320);
    __publicField(this, "responsivePanelLeft", null);
    __publicField(this, "flyoutCleanup");
    __publicField(this, "isResizing", false);
    __publicField(this, "scrollMemory", {});
  }
  mount() {
    const canvas = this.plugin.canvas.activeContainer();
    if (!canvas) return;
    this.attach(canvas);
    if (this.plugin.store.data.uiState.miniPalette.isOpen) this.render();
  }
  open() {
    const canvas = this.plugin.canvas.activeContainer();
    if (!canvas) {
      new import_obsidian10.Notice("Open a Canvas to use Mini Palette.");
      return;
    }
    this.attach(canvas);
    this.plugin.store.data.uiState.miniPalette.isOpen = true;
    this.plugin.store.changed();
    this.render();
  }
  toggle() {
    if (this.plugin.store.data.uiState.miniPalette.isOpen) this.close();
    else this.open();
  }
  close() {
    this.plugin.store.data.uiState.miniPalette.isOpen = false;
    this.plugin.store.changed();
    this.destroyPanel();
  }
  refresh() {
    if (this.panel) this.render();
  }
  destroy() {
    var _a, _b, _c;
    this.destroyPanel();
    (_a = this.host) == null ? void 0 : _a.remove();
    this.host = void 0;
    (_b = this.unsubscribe) == null ? void 0 : _b.call(this);
    this.unsubscribe = void 0;
    (_c = this.detachDrop) == null ? void 0 : _c.call(this);
    this.detachDrop = void 0;
  }
  attach(canvas) {
    var _a;
    const workspace = this.plugin.app.workspace.containerEl;
    if (((_a = this.host) == null ? void 0 : _a.parentElement) === workspace) return;
    this.destroy();
    this.host = workspace.createDiv({ cls: "cp-mini-host" });
    this.unsubscribe = this.plugin.store.subscribe(() => this.refresh());
    const onDragOver = (event) => {
      var _a2;
      if ((_a2 = event.dataTransfer) == null ? void 0 : _a2.types.includes("application/x-canvas-palette-item")) {
        event.preventDefault();
        event.stopPropagation();
        if (event.dataTransfer) event.dataTransfer.dropEffect = "copy";
      }
    };
    const onDrop = (event) => {
      const ids = this.dragIds(event.dataTransfer);
      if (ids.length === 0) return;
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      const items = ids.map((id) => this.plugin.store.data.items[id]).filter((item) => Boolean(item));
      if (items.length > 0) void this.plugin.canvas.restoreItems(items, event.clientX, event.clientY);
    };
    canvas.addEventListener("dragover", onDragOver, true);
    canvas.addEventListener("drop", onDrop, true);
    this.detachDrop = () => {
      canvas.removeEventListener("dragover", onDragOver, true);
      canvas.removeEventListener("drop", onDrop, true);
    };
  }
  destroyPanel() {
    var _a, _b, _c;
    (_a = this.resizeObserver) == null ? void 0 : _a.disconnect();
    this.resizeObserver = void 0;
    (_b = this.flyoutCleanup) == null ? void 0 : _b.call(this);
    this.flyoutCleanup = void 0;
    (_c = this.panel) == null ? void 0 : _c.remove();
    this.panel = void 0;
    this.rightPane = void 0;
    this.inspectorItemId = null;
    this.hoverItemId = null;
    this.openFlyout = null;
    this.responsivePanelLeft = null;
  }
  render() {
    var _a, _b, _c, _d;
    if (!this.host || !this.plugin.store.data.uiState.miniPalette.isOpen) return;
    const viewState = this.captureViewState();
    (_a = this.resizeObserver) == null ? void 0 : _a.disconnect();
    this.resizeObserver = void 0;
    (_b = this.flyoutCleanup) == null ? void 0 : _b.call(this);
    this.flyoutCleanup = void 0;
    (_c = this.panel) == null ? void 0 : _c.remove();
    const state = this.plugin.store.data.uiState.miniPalette;
    const geometryChanged = this.clampGeometry();
    this.layoutMode = miniLayoutMode(state.size.width);
    const panel = this.host.createDiv({ cls: `canvas-palette cp-mini-float cp-mini-layout--${this.layoutMode} cp-theme-${this.plugin.store.data.settings.theme}` });
    this.panel = panel;
    panel.dataset.layoutMode = this.layoutMode;
    panel.style.left = `${(_d = this.responsivePanelLeft) != null ? _d : state.position.x}px`;
    panel.style.top = `${state.position.y}px`;
    panel.style.width = `${state.size.width}px`;
    panel.style.height = `${state.size.height}px`;
    panel.style.setProperty("--cp-left-pane-width", `${state.leftPaneWidth}px`);
    panel.style.setProperty("--cp-right-pane-width", `${state.rightPaneWidth}px`);
    this.applyAccent(panel);
    const header = panel.createDiv({ cls: "cp-mini-float__header" });
    const handle = header.createDiv({ cls: "cp-window-handle" });
    (0, import_obsidian10.setIcon)(handle, "grip-vertical");
    handle.createSpan({ text: "Mini Palette" });
    this.makeDraggable(header, panel);
    const tabs = header.createDiv({ cls: "cp-tabs", attr: { role: "tablist", "aria-label": "Mini Palette spaces" } });
    this.tabButton(tabs, "collect", `Collect (${this.plugin.store.data.pendingItemIds.length})`);
    this.tabButton(tabs, "storage", `Storage (${this.storageCandidates().length})`);
    const actions = header.createDiv({ cls: "cp-window-actions" });
    iconButton(actions, "settings", "Canvas Palette settings", () => this.plugin.openSettings());
    iconButton(actions, "x", "Close Mini Palette", () => this.close());
    if (state.tab === "collect") this.renderCollect(panel);
    else this.renderStorage(panel);
    for (const direction of ["n", "ne", "e", "se", "s", "sw", "w", "nw"]) {
      const resize = panel.createDiv({ cls: `cp-window-resize cp-window-resize--${direction}` });
      this.makeResizable(resize, panel, direction);
    }
    if (state.tab === "collect" && this.inspectorItemId) this.renderInspector();
    this.observePanel(panel);
    this.restoreViewState(viewState);
    if (geometryChanged) window.setTimeout(() => this.plugin.store.changed(), 0);
  }
  tabButton(parent, tab, label) {
    const selected = this.plugin.store.data.uiState.miniPalette.tab === tab;
    const button = parent.createEl("button", { text: label, cls: selected ? "is-active" : "", attr: { role: "tab", id: `cp-mini-tab-${tab}`, "aria-selected": String(selected), "aria-controls": "cp-mini-content", tabindex: selected ? "0" : "-1" } });
    button.addEventListener("click", () => this.selectMiniTab(tab));
    button.addEventListener("keydown", (event) => {
      const tabs = ["collect", "storage"];
      const index = tabs.indexOf(tab);
      const next = event.key === "ArrowLeft" ? tabs[(index + 1) % tabs.length] : event.key === "ArrowRight" ? tabs[(index + 1) % tabs.length] : event.key === "Home" ? "collect" : event.key === "End" ? "storage" : event.key === "Enter" || event.key === " " ? tab : null;
      if (!next) return;
      event.preventDefault();
      this.selectMiniTab(next);
    });
  }
  selectMiniTab(tab) {
    const state = this.plugin.store.data.uiState.miniPalette;
    if (state.tab === tab) return;
    state.tab = tab;
    this.inspectorItemId = null;
    if (tab === "storage") state.focusedItemId = null;
    this.plugin.store.changed();
    queueMicrotask(() => {
      var _a, _b;
      return (_b = (_a = this.panel) == null ? void 0 : _a.querySelector(`#cp-mini-tab-${tab}`)) == null ? void 0 : _b.focus();
    });
  }
  renderCollect(panel) {
    const body = panel.createDiv({ cls: "cp-collect-screen", attr: { id: "cp-mini-content", role: "tabpanel", "aria-labelledby": "cp-mini-tab-collect" } });
    const search = body.createEl("input", { cls: "cp-search", attr: { type: "search", placeholder: "Search pending items\u2026" }, value: this.search });
    const summary = body.createDiv({ cls: "cp-collect-summary" });
    const list = body.createDiv({ cls: "cp-pending-list cp-asset-grid" });
    const update = () => {
      list.empty();
      summary.empty();
      const state = this.plugin.store.data.uiState.miniPalette;
      state.densityLevel = applyAssetDensity(list, state.densityLevel, "cp-asset-grid");
      state.viewMode = state.densityLevel === 0 ? "list" : "grid";
      const visible = this.collectItems();
      const selected = this.collectSelectedIds();
      summary.createSpan({ text: `Pending ${this.plugin.store.data.pendingItemIds.length} \xB7 Selected ${selected.length}` });
      const allVisibleSelected = visible.length > 0 && visible.every((item) => selected.includes(item.id));
      const all = summary.createEl("button", { text: allVisibleSelected ? "Clear selection" : "Select all results" });
      all.addEventListener("click", () => {
        this.setCollectSelectedIds(allVisibleSelected ? selected.filter((id) => !visible.some((item) => item.id === id)) : [.../* @__PURE__ */ new Set([...selected, ...visible.map((item) => item.id)])]);
        this.plugin.store.changed();
      });
      if (selected.length > 0) {
        const openSettings = summary.createEl("button", { text: "Open selected item settings" });
        openSettings.disabled = selected.length !== 1;
        openSettings.addEventListener("click", () => {
          if (selected.length === 1) this.openCollectInspector(selected[0]);
        });
        const multiEdit = summary.createEl("button", { text: "Multiple selection editing" });
        multiEdit.disabled = selected.length < 2;
        multiEdit.addEventListener("click", () => {
          if (selected.length > 1) new TagLabelModal(this.plugin.app, this.plugin, selected).open();
        });
        const remove = summary.createEl("button", { text: "Delete selected", cls: "mod-warning" });
        remove.addEventListener("click", () => this.confirmPendingDelete(selected));
      }
      for (const item of visible) this.renderPendingCard(list, item, visible.map((entry) => entry.id));
      if (list.childElementCount === 0) list.createDiv({ cls: "cp-empty", text: "Canvas scraps will wait here for review." });
    };
    search.addEventListener("input", () => {
      this.search = search.value;
      update();
    });
    body.addEventListener("wheel", (event) => {
      if (!event.ctrlKey && !event.metaKey) return;
      event.preventDefault();
      event.stopPropagation();
      const state = this.plugin.store.data.uiState.miniPalette;
      state.densityLevel = nextAssetDensity(state.densityLevel, event.deltaY);
      state.viewMode = state.densityLevel === 0 ? "list" : "grid";
      update();
      this.plugin.store.changed();
    }, { passive: false });
    update();
    const bottom = panel.createDiv({ cls: "cp-bottom cp-bottom--float" });
    const settings = iconButton(bottom, "settings-2", "Settings", () => this.plugin.openSettings());
    settings.addClass("cp-bottom__start");
    workspaceSelect(this.plugin, bottom, this.plugin.store.data.uiState.activeWorkspaceId, () => void 0);
    const importButton = bottom.createEl("button", { cls: "mod-cta", text: "Import to workspace" });
    importButton.disabled = this.collectSelectedIds().length === 0;
    importButton.addEventListener("click", () => {
      const select = bottom.querySelector("select");
      if (!select) return;
      this.plugin.confirmWorkspaceSave(select.value, () => {
        const result = this.plugin.store.importPending(select.value, this.collectSelectedIds(), this.plugin.isOtherCanvasRepresentativeWorkspace(select.value));
        if (result.rejected.length > 0) new import_obsidian10.Notice("Some items could not be imported because the selected Workspace is unavailable.");
        if (result.alreadySaved.length > 0) this.plugin.showAlreadySavedToWorkspace(select.value, result.imported.length, result.alreadySaved.length);
        else if (result.imported.length > 0) new import_obsidian10.Notice(`${result.imported.length} item${result.imported.length === 1 ? "" : "s"} imported.`);
        this.setCollectSelectedIds([...result.rejected, ...result.alreadySaved]);
        this.plugin.store.data.uiState.miniPalette.focusedItemId = null;
        this.inspectorItemId = null;
      });
    });
  }
  renderStorage(panel) {
    const state = this.plugin.store.data.uiState.miniPalette;
    const showLeftPane = this.layoutMode === "wide" && state.leftPaneOpen;
    const showRightPane = (this.layoutMode === "wide" || this.layoutMode === "medium") && state.rightPaneOpen;
    const shell = panel.createDiv({ cls: `cp-storage-shell${showLeftPane ? " has-left" : ""}${showRightPane ? " has-right" : ""}`, attr: { id: "cp-mini-content", role: "tabpanel", "aria-labelledby": "cp-mini-tab-storage" } });
    if (showLeftPane) {
      const left = shell.createDiv({ cls: "cp-storage-left" });
      this.renderLeftPane(left);
      const divider = shell.createDiv({ cls: "cp-divider cp-divider--vertical" });
      makeHorizontalDivider(divider, (x) => {
        const rect = panel.getBoundingClientRect();
        state.leftPaneWidth = Math.max(190, Math.min(390, x - rect.left));
        panel.style.setProperty("--cp-left-pane-width", `${state.leftPaneWidth}px`);
      }, () => this.plugin.store.changed());
    }
    const main = shell.createDiv({ cls: "cp-storage-main" });
    this.renderStorageMain(main);
    if (showRightPane) {
      const divider = shell.createDiv({ cls: "cp-divider cp-divider--vertical" });
      makeHorizontalDivider(divider, (x) => {
        const rect = panel.getBoundingClientRect();
        state.rightPaneWidth = Math.max(240, Math.min(460, rect.right - x));
        panel.style.setProperty("--cp-right-pane-width", `${state.rightPaneWidth}px`);
      }, () => this.plugin.store.changed());
      const right = shell.createDiv({ cls: "cp-storage-right" });
      this.rightPane = right;
      this.renderRightPane(right);
    }
    const visibleIds = new Set(this.storageItems().map((item) => item.id));
    const selected = this.storageSelectedIds();
    const hiddenCount = selected.filter((id) => !visibleIds.has(id)).length;
    const bottom = panel.createDiv({ cls: "cp-bottom cp-bottom--float" });
    bottom.createSpan({ text: `Total ${this.storageItems().length} \xB7 Selected ${selected.length}${hiddenCount > 0 ? ` (${hiddenCount} hidden)` : ""}` });
    const placeButton = bottom.createEl("button", { text: "Place on Canvas" });
    placeButton.disabled = selected.length === 0;
    placeButton.addEventListener("click", () => void this.placeSelectedOnCanvas());
    if (this.layoutMode === "minimum") {
      const more = iconButton(bottom, "ellipsis", "More Mini Palette actions", () => {
        const menu = new import_obsidian10.Menu();
        menu.addItem((entry) => entry.setTitle("Edit metadata").setIcon("tags").onClick(() => this.editSelectedMetadata()));
        menu.addItem((entry) => entry.setTitle("Remove from Mini").setIcon("unlink").setDisabled(selected.length === 0).onClick(() => this.confirmMiniStorageRemoval(selected)));
        const rect = more.getBoundingClientRect();
        menu.showAtPosition({ x: rect.right, y: rect.top });
      });
    } else {
      const tagEdit = bottom.createEl("button", { text: "Edit metadata" });
      tagEdit.addEventListener("click", () => this.editSelectedMetadata());
      const remove = bottom.createEl("button", { text: "Remove from Mini" });
      remove.disabled = selected.length === 0;
      remove.addEventListener("click", () => this.confirmMiniStorageRemoval(selected));
    }
    if (this.openFlyout) this.renderResponsiveFlyout(panel, this.openFlyout);
  }
  renderLeftPane(parent, close) {
    const head = parent.createDiv({ cls: "cp-pane-heading" });
    head.createEl("h4", { text: "Control panel" });
    iconButton(head, close ? "x" : "panel-left-close", close ? "Close control flyout" : "Close left pane", close != null ? close : (() => {
      this.plugin.store.data.uiState.miniPalette.leftPaneOpen = false;
      this.plugin.store.changed();
    }));
    parent.createEl("label", { text: "Search" });
    const search = parent.createEl("input", { cls: "cp-search", attr: { type: "search", placeholder: "Title, tag, caption", "data-cp-focus": "mini-control-search" }, value: this.search });
    search.addEventListener("input", () => {
      this.search = search.value;
      this.refreshStorageItems();
    });
    parent.createEl("label", { text: "Sort" });
    const sort = parent.createEl("select", { cls: "dropdown" });
    for (const [value, label2] of [["modified-desc", "Modified (newest)"], ["modified-asc", "Modified (oldest)"], ["title-asc", "Title (A-Z)"], ["title-desc", "Title (Z-A)"]]) sort.createEl("option", { value, text: label2 });
    sort.value = this.plugin.store.data.uiState.miniPalette.sort;
    sort.addEventListener("change", () => {
      this.plugin.store.data.uiState.miniPalette.sort = sort.value;
      this.plugin.store.changed();
    });
    this.renderDensityControl(parent, "Mini Palette item size");
    parent.createEl("label", { text: "Date" });
    const date = parent.createEl("select", { cls: "dropdown" });
    for (const [value, text] of [["all", "All dates"], ["today", "Today"], ["week", "Last 7 days"], ["month", "Last 30 days"]]) date.createEl("option", { value, text });
    date.value = this.dateFilter;
    date.addEventListener("change", () => {
      this.dateFilter = date.value;
      this.refreshStorageItems();
    });
    parent.createEl("label", { text: "Filter type" });
    const types = parent.createDiv({ cls: "cp-filter-chips" });
    for (const type of ["all", "card", "markdown", "image", "group"]) {
      const button = types.createEl("button", { text: type === "all" ? "All" : type === "markdown" ? "MD" : type, cls: this.typeFilter === type ? "is-active" : "" });
      button.addEventListener("click", () => {
        this.typeFilter = type;
        for (const chip of Array.from(types.querySelectorAll("button"))) chip.toggleClass("is-active", chip === button);
        this.refreshStorageItems();
      });
    }
    parent.createEl("label", { text: "Tag filter" });
    const tag = parent.createEl("input", { attr: { placeholder: "#tag" }, value: this.tagFilter });
    tag.addEventListener("input", () => {
      this.tagFilter = tag.value.replace(/^#/, "");
      this.refreshStorageItems();
    });
    parent.createEl("label", { text: "Label filter" });
    const label = parent.createEl("input", { attr: { placeholder: "Label" }, value: this.labelFilter });
    label.addEventListener("input", () => {
      this.labelFilter = label.value;
      this.refreshStorageItems();
    });
  }
  renderStorageMain(parent) {
    const state = this.plugin.store.data.uiState.miniPalette;
    const heading = parent.createDiv({ cls: "cp-storage-heading" });
    if (this.layoutMode !== "wide") this.flyoutTrigger(heading, "control", "panel-left-open", "Open control flyout");
    else if (!state.leftPaneOpen) iconButton(heading, "panel-left-open", "Open left pane", () => {
      state.leftPaneOpen = true;
      this.plugin.store.changed();
    });
    heading.createSpan({ text: "Assets" });
    for (const [mode, icon, label] of [["grid", "layout-grid", "Grid view"], ["list", "list", "List view"]]) {
      const button = iconButton(heading, icon, label, () => {
        state.viewMode = mode;
        state.densityLevel = mode === "list" ? 0 : Math.max(1, state.densityLevel || 4);
        this.plugin.store.changed();
      });
      if (state.viewMode === mode) button.addClass("is-active");
    }
    if (this.layoutMode === "narrow" || this.layoutMode === "minimum") this.flyoutTrigger(heading, "preview", "panel-right-open", "Open preview flyout");
    else if (!state.rightPaneOpen) iconButton(heading, "panel-right-open", "Open preview pane", () => {
      state.rightPaneOpen = true;
      this.plugin.store.changed();
    });
    if (this.layoutMode !== "wide" || !state.leftPaneOpen) {
      const quick = parent.createDiv({ cls: "cp-mini-quick-controls" });
      const search = quick.createEl("input", { cls: "cp-search", attr: { type: "search", placeholder: "Search assets", "data-cp-focus": "mini-quick-search" }, value: this.search });
      search.addEventListener("input", () => {
        this.search = search.value;
        this.refreshStorageItems();
      });
      const type = quick.createEl("select", { cls: "dropdown", attr: { "aria-label": "Type filter" } });
      for (const value of ["all", "card", "markdown", "image", "group"]) type.createEl("option", { value, text: value === "all" ? "All types" : value === "markdown" ? "MD" : value });
      type.value = this.typeFilter;
      type.addEventListener("change", () => {
        this.typeFilter = type.value;
        this.refreshStorageItems();
      });
      this.renderDensityControl(quick, "Item size", true);
    }
    const grid = parent.createDiv({ cls: "cp-asset-grid" });
    this.configureStorageGrid(parent, grid);
  }
  configureStorageGrid(parent, grid) {
    const state = this.plugin.store.data.uiState.miniPalette;
    state.densityLevel = applyAssetDensity(grid, state.densityLevel, "cp-asset-grid");
    state.viewMode = state.densityLevel === 0 ? "list" : "grid";
    grid.addEventListener("wheel", (event) => {
      if (!event.ctrlKey && !event.metaKey) return;
      event.preventDefault();
      event.stopPropagation();
      state.densityLevel = nextAssetDensity(state.densityLevel, event.deltaY);
      state.viewMode = state.densityLevel === 0 ? "list" : "grid";
      applyAssetDensity(grid, state.densityLevel, "cp-asset-grid");
      this.plugin.store.changed();
    }, { passive: false });
    this.populateStorageGrid(grid);
    this.mountStorageSelection(parent, grid);
  }
  populateStorageGrid(grid) {
    var _a;
    const state = this.plugin.store.data.uiState.miniPalette;
    applyAssetDensity(grid, state.densityLevel, "cp-asset-grid");
    const storageItems = this.storageItems();
    const orderedIds = storageItems.map((item) => item.id);
    for (const item of storageItems) {
      const facesEnabled = supportsFrontBack(item) && item.facesEnabled;
      const face = facesEnabled ? (_a = this.plugin.store.data.uiState.miniItemFaces[item.id]) != null ? _a : "front" : "front";
      const selected = this.storageSelectedIds();
      const card = renderItem(grid, item, { selected: selected.includes(item.id), showSelectionMarker: selected.length > 1, dragItemIds: selected, currentFace: face, markdownSourceStatus: this.plugin.markdownSourceStatus(item), onMarkdownSourceStatus: (event) => this.plugin.showMarkdownSourceMenu(item, event), onToggleFace: facesEnabled ? (next) => this.plugin.store.setPaletteFace("mini", item.id, next) : void 0, draggable: true, onSelect: (event) => this.selectStorage(item.id, event, orderedIds), onOpen: () => face === "back" ? void this.plugin.editorManager.openBack(item.id) : void this.plugin.openItemEditor(item.id), onLocate: () => void this.plugin.locateItemOnCanvas(item), onContextMenu: (event) => this.openMiniItemMenu(event, item, "storage") });
      const body = card.querySelector(".cp-item__body");
      if (body) void this.plugin.preview.render(body, item, true, 360, face);
      card.addEventListener("mousemove", (event) => {
        if (event.ctrlKey && this.hoverItemId !== item.id) {
          this.hoverItemId = item.id;
          if (this.rightPane) this.renderRightPane(this.rightPane);
        }
      });
      card.addEventListener("mouseleave", () => {
        if (this.hoverItemId === item.id) {
          this.hoverItemId = null;
          if (this.rightPane) this.renderRightPane(this.rightPane);
        }
      });
    }
    if (grid.childElementCount === 0) grid.createDiv({ cls: "cp-empty", text: "No items match these filters." });
  }
  renderRightPane(parent, close) {
    var _a, _b, _c, _d;
    parent.empty();
    const head = parent.createDiv({ cls: "cp-pane-heading" });
    head.createEl("h4", { text: this.hoverItemId ? "Temporary preview" : "Preview" });
    iconButton(head, close ? "x" : "panel-right-close", close ? "Close preview flyout" : "Close preview pane", close != null ? close : (() => {
      this.plugin.store.data.uiState.miniPalette.rightPaneOpen = false;
      this.plugin.store.changed();
    }));
    const item = this.plugin.store.data.items[(_b = (_a = this.hoverItemId) != null ? _a : this.plugin.store.data.uiState.selectedItemId) != null ? _b : ""];
    if (!item) {
      parent.createDiv({ cls: "cp-empty", text: "Select an item to preview it." });
      return;
    }
    parent.createEl("h3", { text: item.displayTitle });
    const preview = parent.createDiv({ cls: "cp-preview" });
    void this.plugin.preview.render(preview, item);
    parent.createEl("h4", { text: "Details" });
    const details = [["Original Workspace", this.workspaceName(item.origin.workspaceId)], ["Created", new Date(item.createdAt).toLocaleString()], ["Modified", new Date(item.modifiedAt).toLocaleString()], ["Type", item.type], ["Original Path", (_d = (_c = item.origin.filePath) != null ? _c : item.origin.canvasPath) != null ? _d : "-"]];
    for (const [label, value] of details) {
      const row = parent.createDiv({ cls: "cp-detail" });
      row.createSpan({ text: label });
      row.createEl("strong", { text: value });
    }
    const actions = parent.createDiv({ cls: "cp-preview-actions" });
    const copy = actions.createEl("button", { text: "Copy" });
    copy.addEventListener("click", () => {
      var _a2, _b2, _c2;
      return void ((_c2 = navigator.clipboard) == null ? void 0 : _c2.writeText((_b2 = (_a2 = item.content) != null ? _a2 : item.origin.filePath) != null ? _b2 : item.displayTitle));
    });
    if (item.origin.canvasPath && item.origin.canvasNodeId) actions.createEl("button", { text: "Locate on Canvas" }).addEventListener("click", () => void this.plugin.locateItemOnCanvas(item));
    else if (item.origin.filePath) actions.createEl("button", { text: "Open source file" }).addEventListener("click", () => void this.plugin.openOriginal(item));
  }
  flyoutTrigger(parent, kind, icon, label) {
    const button = iconButton(parent, icon, label, () => this.toggleResponsiveFlyout(kind));
    button.dataset.cpFlyoutTrigger = kind;
    button.setAttribute("aria-controls", `cp-mini-${kind}-flyout`);
    button.setAttribute("aria-expanded", String(this.openFlyout === kind));
    if (this.openFlyout === kind) button.addClass("is-active");
    return button;
  }
  toggleResponsiveFlyout(kind) {
    var _a, _b, _c;
    if (this.openFlyout === kind) {
      this.closeResponsiveFlyout(kind);
      return;
    }
    const state = this.plugin.store.data.uiState.miniPalette;
    const requestedWidth = kind === "control" ? Math.max(280, state.leftPaneWidth) : Math.max(300, state.rightPaneWidth);
    const measuredHostWidth = (_b = (_a = this.host) == null ? void 0 : _a.clientWidth) != null ? _b : 0;
    const hostWidth = measuredHostWidth >= 360 ? measuredHostWidth : window.innerWidth;
    const panelLeft = (_c = this.responsivePanelLeft) != null ? _c : state.position.x;
    const placement = attachedFlyoutPlacement(hostWidth, panelLeft, state.size.width, kind === "preview" ? "right" : "left", requestedWidth);
    this.openFlyout = kind;
    this.flyoutSide = placement.side;
    this.flyoutWidth = placement.width;
    this.responsivePanelLeft = placement.panelLeft;
    this.render();
    window.setTimeout(() => {
      var _a2, _b2;
      return (_b2 = (_a2 = this.panel) == null ? void 0 : _a2.querySelector(`#cp-mini-${kind}-flyout button, #cp-mini-${kind}-flyout input, #cp-mini-${kind}-flyout select`)) == null ? void 0 : _b2.focus();
    }, 0);
  }
  closeResponsiveFlyout(kind = this.openFlyout) {
    if (!kind) return;
    this.openFlyout = null;
    this.responsivePanelLeft = null;
    this.render();
    window.setTimeout(() => {
      var _a, _b;
      return (_b = (_a = this.panel) == null ? void 0 : _a.querySelector(`[data-cp-flyout-trigger="${kind}"]`)) == null ? void 0 : _b.focus();
    }, 0);
  }
  renderResponsiveFlyout(panel, kind) {
    panel.style.setProperty("--cp-mini-flyout-width", `${this.flyoutWidth}px`);
    const flyout = panel.createDiv({ cls: `cp-mini-flyout ${kind === "control" ? "cp-storage-left" : "cp-storage-right"} cp-mini-flyout--${kind} is-${this.flyoutSide}`, attr: { id: `cp-mini-${kind}-flyout`, role: "region", "aria-label": kind === "control" ? "Mini Palette controls" : "Mini Palette preview" } });
    if (kind === "control") this.renderLeftPane(flyout, () => this.closeResponsiveFlyout(kind));
    else {
      this.rightPane = flyout;
      this.renderRightPane(flyout, () => this.closeResponsiveFlyout(kind));
    }
    const dismissPointer = (event) => {
      var _a, _b;
      const target = event.target;
      if (!(target instanceof Node) || flyout.contains(target) || ((_b = (_a = this.panel) == null ? void 0 : _a.querySelector(`[data-cp-flyout-trigger="${kind}"]`)) == null ? void 0 : _b.contains(target))) return;
      this.closeResponsiveFlyout(kind);
    };
    const dismissKey = (event) => {
      if (event.key === "Escape") {
        event.preventDefault();
        this.closeResponsiveFlyout(kind);
      }
    };
    window.setTimeout(() => {
      window.addEventListener("pointerdown", dismissPointer, true);
      window.addEventListener("keydown", dismissKey, true);
    }, 0);
    this.flyoutCleanup = () => {
      window.removeEventListener("pointerdown", dismissPointer, true);
      window.removeEventListener("keydown", dismissKey, true);
    };
  }
  captureViewState() {
    var _a, _b, _c;
    if (!this.panel) return null;
    const scroll = {};
    for (const selector of [".cp-collect-screen", ".cp-storage-left", ".cp-storage-main", ".cp-storage-right", ".cp-mini-flyout"]) {
      const element = this.panel.querySelector(selector);
      if (!element) continue;
      if (element.scrollHeight > element.clientHeight || this.scrollMemory[selector] === void 0) this.scrollMemory[selector] = element.scrollTop;
      scroll[selector] = this.scrollMemory[selector];
    }
    const active = document.activeElement instanceof HTMLElement && this.panel.contains(document.activeElement) ? document.activeElement : null;
    const focus = (_a = active == null ? void 0 : active.dataset.cpFocus) != null ? _a : null;
    const input = active instanceof HTMLInputElement || active instanceof HTMLTextAreaElement ? active : null;
    return { scroll, focus, selection: [(_b = input == null ? void 0 : input.selectionStart) != null ? _b : null, (_c = input == null ? void 0 : input.selectionEnd) != null ? _c : null] };
  }
  restoreViewState(state) {
    if (!state) return;
    window.setTimeout(() => {
      if (!this.panel) return;
      for (const [selector, top] of Object.entries(state.scroll)) {
        const element = this.panel.querySelector(selector);
        if (element) element.scrollTop = top;
      }
      if (!state.focus) return;
      const active = this.panel.querySelector(`[data-cp-focus="${state.focus}"]`);
      if (!active) return;
      active.focus();
      if (state.selection[0] !== null && state.selection[1] !== null) active.setSelectionRange(state.selection[0], state.selection[1]);
    }, 0);
  }
  clampGeometry() {
    var _a, _b, _c, _d;
    const state = this.plugin.store.data.uiState.miniPalette;
    const measuredHostWidth = (_b = (_a = this.host) == null ? void 0 : _a.clientWidth) != null ? _b : 0;
    const measuredHostHeight = (_d = (_c = this.host) == null ? void 0 : _c.clientHeight) != null ? _d : 0;
    const hostWidth = measuredHostWidth >= 360 ? measuredHostWidth : window.innerWidth;
    const hostHeight = measuredHostHeight >= 300 ? measuredHostHeight : window.innerHeight;
    const width = Math.min(Math.max(360, state.size.width), Math.max(1, hostWidth));
    const height = Math.min(Math.max(300, state.size.height), Math.max(1, hostHeight));
    const x = Math.max(0, Math.min(state.position.x, Math.max(0, hostWidth - width)));
    const y = Math.max(0, Math.min(state.position.y, Math.max(0, hostHeight - height)));
    const changed = width !== state.size.width || height !== state.size.height || x !== state.position.x || y !== state.position.y;
    if (changed) {
      state.size = { width, height };
      state.position = { x, y };
      this.responsivePanelLeft = null;
    }
    return changed;
  }
  observePanel(panel) {
    this.resizeObserver = new ResizeObserver(([entry]) => {
      var _a;
      if (this.isResizing) return;
      const borderBox = Array.isArray(entry.borderBoxSize) ? entry.borderBoxSize[0] : entry.borderBoxSize;
      const next = miniLayoutMode((_a = borderBox == null ? void 0 : borderBox.inlineSize) != null ? _a : panel.getBoundingClientRect().width);
      if (next === this.layoutMode) return;
      this.layoutMode = next;
      this.openFlyout = null;
      this.responsivePanelLeft = null;
      this.render();
    });
    this.resizeObserver.observe(panel);
  }
  renderInspector() {
    var _a;
    const item = this.plugin.store.data.items[(_a = this.inspectorItemId) != null ? _a : ""];
    if (!item || !this.panel) return;
    const drawer = this.panel.createDiv({ cls: "cp-inspector-drawer" });
    const head = drawer.createDiv({ cls: "cp-pane-heading" });
    head.createEl("h3", { text: "Selected item settings" });
    iconButton(head, "x", "Close inspector", () => {
      this.inspectorItemId = null;
      this.render();
    });
    const title = this.input(drawer, "Title", item.displayTitle);
    const tags = this.input(drawer, "Tag", item.tags.join(", "), "tag1, tag2");
    const label = this.input(drawer, "Label", item.label, "e.g. Idea, In progress");
    drawer.createEl("label", { text: "Label color" });
    const labelColor = drawer.createEl("input", { attr: { type: "color", "aria-label": "Label color" } });
    labelColor.value = item.labelColor || "#8b5cf6";
    const caption = this.textarea(drawer, "Caption", item.caption);
    drawer.createEl("h4", { text: "Original preview" });
    const preview = drawer.createDiv({ cls: "cp-preview cp-preview--inspector" });
    void this.plugin.preview.render(preview, item, true);
    const actions = drawer.createDiv({ cls: "cp-inspector-actions" });
    const remove = actions.createEl("button", { text: "Delete", cls: "mod-warning" });
    remove.addEventListener("click", () => this.confirmPendingDelete([item.id]));
    const close = actions.createEl("button", { text: "Close" });
    close.addEventListener("click", () => {
      this.inspectorItemId = null;
      this.plugin.store.data.uiState.miniPalette.focusedItemId = null;
      this.render();
    });
    const save = actions.createEl("button", { text: "Save", cls: "mod-cta" });
    save.addEventListener("click", () => {
      const labelValue = label.value.trim();
      this.plugin.store.updateItem(item.id, { displayTitle: title.value, tags: tags.value.split(",").map((value) => value.trim().replace(/^#/, "")).filter(Boolean), label: labelValue, labelColor: labelValue ? labelColor.value : "", caption: caption.value });
      this.inspectorItemId = null;
      this.plugin.store.data.uiState.miniPalette.focusedItemId = null;
    });
  }
  input(parent, label, value, placeholder = "") {
    parent.createEl("label", { text: label });
    return parent.createEl("input", { attr: { placeholder }, value });
  }
  textarea(parent, label, value) {
    parent.createEl("label", { text: label });
    return parent.createEl("textarea", { text: value });
  }
  collectSelectedIds() {
    return this.plugin.store.data.uiState.miniPalette.collectSelectedItemIds;
  }
  storageSelectedIds() {
    return this.plugin.store.data.uiState.miniPalette.storageSelectedItemIds;
  }
  setCollectSelectedIds(ids) {
    this.plugin.store.data.uiState.miniPalette.collectSelectedItemIds = ids.filter((id) => Boolean(this.plugin.store.data.items[id]));
  }
  setStorageSelectedIds(ids) {
    this.plugin.store.data.uiState.miniPalette.storageSelectedItemIds = ids.filter((id) => Boolean(this.plugin.store.data.items[id]));
  }
  selectionFromEvent(current, id, event, orderedIds, anchorId) {
    const toggle = event.ctrlKey || event.metaKey;
    if (event.shiftKey && anchorId) {
      const anchor = orderedIds.indexOf(anchorId);
      const target = orderedIds.indexOf(id);
      const range = anchor >= 0 && target >= 0 ? orderedIds.slice(Math.min(anchor, target), Math.max(anchor, target) + 1) : [id];
      return toggle ? [.../* @__PURE__ */ new Set([...current, ...range])] : range;
    }
    return toggle ? current.includes(id) ? current.filter((value) => value !== id) : [...current, id] : [id];
  }
  selectPending(id, event, orderedIds) {
    const state = this.plugin.store.data.uiState.miniPalette;
    this.setCollectSelectedIds(this.selectionFromEvent(this.collectSelectedIds(), id, event, orderedIds, state.collectSelectionAnchorId));
    if (!event.shiftKey) state.collectSelectionAnchorId = id;
    state.focusedItemId = id;
    this.plugin.store.changed();
  }
  selectStorage(id, event, orderedIds) {
    var _a;
    const state = this.plugin.store.data.uiState.miniPalette;
    const next = this.selectionFromEvent(this.storageSelectedIds(), id, event, orderedIds, state.storageSelectionAnchorId);
    this.setStorageSelectedIds(next);
    if (!event.shiftKey) state.storageSelectionAnchorId = id;
    this.plugin.store.data.uiState.selectedItemId = next.includes(id) ? id : (_a = next.at(-1)) != null ? _a : null;
    this.plugin.store.changed();
  }
  collectItems() {
    return this.filtered(this.plugin.store.data.pendingItemIds.map((id) => this.plugin.store.data.items[id]).filter((item) => Boolean(item)));
  }
  storageCandidates() {
    return this.plugin.store.data.uiState.miniPalette.storageItemIds.map((id) => this.plugin.store.data.items[id]).filter((item) => Boolean(item));
  }
  storageItems() {
    const now = Date.now();
    const cutoff = this.dateFilter === "today" ? (/* @__PURE__ */ new Date()).setHours(0, 0, 0, 0) : this.dateFilter === "week" ? now - 7 * 864e5 : this.dateFilter === "month" ? now - 30 * 864e5 : 0;
    return this.sort(this.filtered(this.storageCandidates()).filter((item) => item.modifiedAt >= cutoff));
  }
  filtered(items) {
    return this.plugin.search.filter(items, this.search).filter((item) => (this.typeFilter === "all" || item.type === this.typeFilter) && (!this.tagFilter || item.tags.some((tag) => tag.toLocaleLowerCase().includes(this.tagFilter.toLocaleLowerCase()))) && (!this.labelFilter || item.label.toLocaleLowerCase().includes(this.labelFilter.toLocaleLowerCase())));
  }
  refreshStorageItems() {
    var _a, _b;
    const grid = (_a = this.panel) == null ? void 0 : _a.querySelector(".cp-storage-main .cp-asset-grid");
    if (!grid) return;
    grid.empty();
    this.populateStorageGrid(grid);
    const total = (_b = this.panel) == null ? void 0 : _b.querySelector(".cp-bottom--float > span");
    if (total) total.setText(`Total ${this.storageItems().length} \xB7 Selected ${this.storageSelectedIds().length}`);
  }
  sort(items) {
    const mode = this.plugin.store.data.uiState.miniPalette.sort;
    return [...items].sort((a, b) => mode === "modified-desc" ? b.modifiedAt - a.modifiedAt : mode === "modified-asc" ? a.modifiedAt - b.modifiedAt : mode === "title-desc" ? b.displayTitle.localeCompare(a.displayTitle) : a.displayTitle.localeCompare(b.displayTitle));
  }
  workspaceName(id) {
    var _a, _b;
    return id ? (_b = (_a = this.plugin.store.data.workspaces[id]) == null ? void 0 : _a.name) != null ? _b : "Unknown workspace" : "Pending";
  }
  editSelectedMetadata() {
    const ids = this.storageSelectedIds().filter((id) => this.plugin.store.data.items[id]);
    if (ids.length === 0) {
      new import_obsidian10.Notice("Select items first.");
      return;
    }
    new TagLabelModal(this.plugin.app, this.plugin, ids).open();
  }
  renderDensityControl(parent, label, compact = false) {
    const state = this.plugin.store.data.uiState.miniPalette;
    const control = parent.createDiv({ cls: `cp-density-control${compact ? " is-compact" : ""}` });
    const heading = control.createDiv({ cls: "cp-density-control__heading" });
    const name = heading.createEl("label", { text: label });
    const value = heading.createSpan({ text: assetDensityLabel(state.densityLevel) });
    const input = control.createEl("input", { attr: { type: "range", min: String(ASSET_DENSITY_MIN), max: String(ASSET_DENSITY_MAX), step: "1", value: String(state.densityLevel), "aria-label": label } });
    name.htmlFor = input.id = `cp-mini-density-${compact ? "quick" : "panel"}`;
    const update = () => {
      var _a;
      state.densityLevel = Number(input.value);
      state.viewMode = state.densityLevel === 0 ? "list" : "grid";
      value.setText(assetDensityLabel(state.densityLevel));
      const grid = (_a = this.panel) == null ? void 0 : _a.querySelector(".cp-asset-grid");
      if (grid) applyAssetDensity(grid, state.densityLevel, "cp-asset-grid");
    };
    input.addEventListener("input", update);
    input.addEventListener("change", () => this.plugin.store.changed());
  }
  openMiniItemMenu(event, item, tab) {
    event.preventDefault();
    const selected = tab === "collect" ? this.collectSelectedIds() : this.storageSelectedIds();
    const targetIds = selected.includes(item.id) ? selected : [item.id];
    if (!selected.includes(item.id)) {
      if (tab === "collect") this.setCollectSelectedIds([item.id]);
      else this.setStorageSelectedIds([item.id]);
      this.plugin.store.changed();
    }
    const menu = new import_obsidian10.Menu();
    if (tab === "collect" && targetIds.length === 1) {
      menu.addItem((entry) => entry.setTitle("Open selected item settings").setIcon("settings-2").onClick(() => this.openCollectInspector(item.id)));
    } else {
      menu.addItem((entry) => entry.setTitle("Multiple selection editing").setIcon("tags").onClick(() => new TagLabelModal(this.plugin.app, this.plugin, targetIds).open()));
    }
    if (targetIds.length === 1) {
      if (item.origin.canvasPath && item.origin.canvasNodeId) menu.addItem((entry) => entry.setTitle("Locate on Canvas").setIcon("locate-fixed").onClick(() => void this.plugin.locateItemOnCanvas(item)));
      else if (item.origin.filePath) menu.addItem((entry) => entry.setTitle("Open source file").setIcon("external-link").onClick(() => void this.plugin.openOriginal(item)));
    }
    menu.addSeparator();
    if (tab === "collect") menu.addItem((entry) => entry.setTitle(`Delete ${targetIds.length} pending item${targetIds.length === 1 ? "" : "s"}`).setIcon("trash").onClick(() => this.confirmPendingDelete(targetIds)));
    else {
      menu.addItem((entry) => entry.setTitle(`Export ${targetIds.length} item${targetIds.length === 1 ? "" : "s"} to Canvas`).setIcon("share-2").onClick(() => void this.plugin.exportItemsToActiveCanvas(targetIds)));
      menu.addItem((entry) => entry.setTitle(`Remove ${targetIds.length} link${targetIds.length === 1 ? "" : "s"} from Mini`).setIcon("unlink").onClick(() => this.confirmMiniStorageRemoval(targetIds)));
    }
    menu.showAtMouseEvent(event);
  }
  renderPendingCard(parent, item, orderedIds) {
    const selected = this.collectSelectedIds();
    const card = renderItem(parent, item, { selected: selected.includes(item.id), showSelectionMarker: selected.length > 1, dragItemIds: selected, miniCollect: true, draggable: true, onSelect: (event) => {
      this.selectPending(item.id, event, orderedIds);
      this.inspectorItemId = null;
      this.render();
    }, onOpen: () => void this.plugin.openItemEditor(item.id), onLocate: () => void this.plugin.locateItemOnCanvas(item), onContextMenu: (event) => this.openMiniItemMenu(event, item, "collect") });
    const preview = card.querySelector(".cp-item__body");
    if (preview) void this.plugin.preview.render(preview, item, true, 360);
  }
  openCollectInspector(itemId) {
    this.plugin.store.data.uiState.miniPalette.focusedItemId = itemId;
    this.inspectorItemId = itemId;
    this.plugin.store.changed();
  }
  confirmPendingDelete(ids) {
    const valid = ids.filter((id) => Boolean(this.plugin.store.data.items[id]) && this.plugin.store.data.pendingItemIds.includes(id));
    if (valid.length === 0) return;
    new ConfirmDeleteModal(this.plugin.app, valid.length, () => {
      this.plugin.store.removePendingItems(valid);
      this.setCollectSelectedIds([]);
      this.inspectorItemId = null;
      this.plugin.store.data.uiState.miniPalette.focusedItemId = null;
    }).open();
  }
  confirmMiniStorageRemoval(ids) {
    const valid = ids.filter((id) => Boolean(this.plugin.store.data.items[id]) && !this.plugin.store.data.pendingItemIds.includes(id));
    if (valid.length === 0) return;
    new ConfirmMiniStorageRemovalModal(this.plugin.app, valid.length, () => {
      this.plugin.store.removeMiniStorageItems(valid);
      this.setStorageSelectedIds([]);
      this.hoverItemId = null;
      this.plugin.store.data.uiState.miniPalette.storageSelectionAnchorId = null;
    }).open();
  }
  async placeSelectedOnCanvas() {
    await this.plugin.exportItemsToActiveCanvas(this.storageSelectedIds());
  }
  dragIds(dataTransfer) {
    if (!dataTransfer) return [];
    try {
      const ids = JSON.parse(dataTransfer.getData("application/x-canvas-palette-items"));
      if (Array.isArray(ids)) return ids.filter((id2) => typeof id2 === "string");
    } catch (e) {
    }
    const id = dataTransfer.getData("application/x-canvas-palette-item");
    return id ? [id] : [];
  }
  mountStorageSelection(viewport, grid) {
    viewport.addEventListener("click", (event) => {
      if (this.suppressBlankClick) {
        this.suppressBlankClick = false;
        return;
      }
      const target = event.target;
      if (!(target instanceof HTMLElement) || target.closest(".cp-item,button,input,select,textarea,label,a")) return;
      this.setStorageSelectedIds([]);
      this.plugin.store.data.uiState.miniPalette.storageSelectionAnchorId = null;
      this.plugin.store.data.uiState.selectedItemId = null;
      this.plugin.store.changed();
    });
    grid.addEventListener("pointerdown", (event) => {
      if (event.button !== 0 || event.target !== grid) return;
      event.preventDefault();
      const start = { x: event.clientX, y: event.clientY };
      const base = event.ctrlKey || event.metaKey ? new Set(this.storageSelectedIds()) : /* @__PURE__ */ new Set();
      const rectangle = document.createElement("div");
      rectangle.className = "cp-selection-rectangle";
      document.body.appendChild(rectangle);
      let dragged = false;
      let hits = [];
      const move = (pointer) => {
        var _a;
        if (!dragged && Math.hypot(pointer.clientX - start.x, pointer.clientY - start.y) < 4) return;
        dragged = true;
        const left = Math.min(start.x, pointer.clientX);
        const top = Math.min(start.y, pointer.clientY);
        const right = Math.max(start.x, pointer.clientX);
        const bottom = Math.max(start.y, pointer.clientY);
        Object.assign(rectangle.style, { display: "block", left: `${left}px`, top: `${top}px`, width: `${right - left}px`, height: `${bottom - top}px` });
        hits = [];
        for (const card of Array.from(grid.querySelectorAll(".cp-item"))) {
          const rect = card.getBoundingClientRect();
          const hit = rect.right >= left && rect.left <= right && rect.bottom >= top && rect.top <= bottom;
          card.toggleClass("is-selected", hit || base.has((_a = card.dataset.itemId) != null ? _a : ""));
          if (hit && card.dataset.itemId) hits.push(card.dataset.itemId);
        }
      };
      const cleanup = () => {
        window.removeEventListener("pointermove", move, true);
        window.removeEventListener("pointerup", finish, true);
        window.removeEventListener("pointercancel", finish, true);
        window.removeEventListener("keydown", key, true);
        rectangle.remove();
      };
      const finish = () => {
        var _a;
        cleanup();
        this.suppressBlankClick = true;
        window.setTimeout(() => {
          this.suppressBlankClick = false;
        }, 0);
        if (!dragged) this.setStorageSelectedIds([]);
        else this.setStorageSelectedIds([.../* @__PURE__ */ new Set([...base, ...hits])]);
        const state = this.plugin.store.data.uiState.miniPalette;
        state.storageSelectionAnchorId = (_a = this.storageSelectedIds().at(-1)) != null ? _a : null;
        this.plugin.store.data.uiState.selectedItemId = state.storageSelectionAnchorId;
        this.plugin.store.changed();
      };
      const key = (keyboard) => {
        var _a;
        if (keyboard.key === "Escape") {
          cleanup();
          for (const card of Array.from(grid.querySelectorAll(".cp-item"))) card.toggleClass("is-selected", base.has((_a = card.dataset.itemId) != null ? _a : ""));
        }
      };
      window.addEventListener("pointermove", move, true);
      window.addEventListener("pointerup", finish, true);
      window.addEventListener("pointercancel", finish, true);
      window.addEventListener("keydown", key, true);
    });
  }
  applyAccent(panel) {
    const settings = this.plugin.store.data.settings;
    if (settings.accentMode === "custom") panel.style.setProperty("--cp-accent", settings.accentColor);
  }
  makeDraggable(handle, panel) {
    handle.addEventListener("pointerdown", (event) => {
      if (event.target.closest("button,input,select")) return;
      event.preventDefault();
      this.commitResponsivePanelPosition(panel);
      handle.setPointerCapture(event.pointerId);
      const state = this.plugin.store.data.uiState.miniPalette;
      const start = { x: event.clientX, y: event.clientY, left: state.position.x, top: state.position.y };
      const move = (pointer) => {
        var _a, _b, _c;
        const host = (_a = this.host) == null ? void 0 : _a.getBoundingClientRect();
        const maxLeft = Math.max(0, ((_b = host == null ? void 0 : host.width) != null ? _b : window.innerWidth) - panel.offsetWidth);
        const maxTop = Math.max(0, ((_c = host == null ? void 0 : host.height) != null ? _c : window.innerHeight) - panel.offsetHeight);
        state.position = { x: Math.max(0, Math.min(maxLeft, start.left + pointer.clientX - start.x)), y: Math.max(0, Math.min(maxTop, start.top + pointer.clientY - start.y)) };
        panel.style.left = `${state.position.x}px`;
        panel.style.top = `${state.position.y}px`;
      };
      const end = () => {
        handle.removeEventListener("pointermove", move);
        handle.removeEventListener("pointerup", end);
        handle.removeEventListener("pointercancel", end);
        this.plugin.store.changed();
      };
      handle.addEventListener("pointermove", move);
      handle.addEventListener("pointerup", end);
      handle.addEventListener("pointercancel", end);
    });
  }
  makeResizable(handle, panel, direction) {
    handle.addEventListener("pointerdown", (event) => {
      event.preventDefault();
      event.stopPropagation();
      this.commitResponsivePanelPosition(panel);
      this.isResizing = true;
      handle.setPointerCapture(event.pointerId);
      const state = this.plugin.store.data.uiState.miniPalette;
      const start = { x: event.clientX, y: event.clientY, left: state.position.x, top: state.position.y, width: state.size.width, height: state.size.height };
      const move = (pointer) => {
        var _a, _b, _c;
        const dx = pointer.clientX - start.x;
        const dy = pointer.clientY - start.y;
        const host = (_a = this.host) == null ? void 0 : _a.getBoundingClientRect();
        const hostWidth = (_b = host == null ? void 0 : host.width) != null ? _b : window.innerWidth;
        const hostHeight = (_c = host == null ? void 0 : host.height) != null ? _c : window.innerHeight;
        const minWidth = 360;
        const minHeight = 300;
        let left = start.left;
        let top = start.top;
        let width = start.width;
        let height = start.height;
        if (direction.includes("e")) width = start.width + dx;
        if (direction.includes("s")) height = start.height + dy;
        if (direction.includes("w")) {
          width = start.width - dx;
          left = start.left + dx;
        }
        if (direction.includes("n")) {
          height = start.height - dy;
          top = start.top + dy;
        }
        if (width < minWidth) {
          if (direction.includes("w")) left -= minWidth - width;
          width = minWidth;
        }
        if (height < minHeight) {
          if (direction.includes("n")) top -= minHeight - height;
          height = minHeight;
        }
        left = Math.max(0, left);
        top = Math.max(0, top);
        width = Math.min(width, Math.max(minWidth, hostWidth - left));
        height = Math.min(height, Math.max(minHeight, hostHeight - top));
        state.position = { x: left, y: top };
        state.size = { width, height };
        panel.style.left = `${left}px`;
        panel.style.top = `${top}px`;
        panel.style.width = `${width}px`;
        panel.style.height = `${height}px`;
      };
      const end = () => {
        this.isResizing = false;
        handle.removeEventListener("pointermove", move);
        handle.removeEventListener("pointerup", end);
        handle.removeEventListener("pointercancel", end);
        this.plugin.store.changed();
      };
      handle.addEventListener("pointermove", move);
      handle.addEventListener("pointerup", end);
      handle.addEventListener("pointercancel", end);
    });
  }
  commitResponsivePanelPosition(panel) {
    var _a, _b;
    if (this.responsivePanelLeft === null) return;
    this.plugin.store.data.uiState.miniPalette.position.x = panel.offsetLeft;
    this.responsivePanelLeft = null;
    this.openFlyout = null;
    (_a = this.flyoutCleanup) == null ? void 0 : _a.call(this);
    this.flyoutCleanup = void 0;
    (_b = panel.querySelector(".cp-mini-flyout")) == null ? void 0 : _b.remove();
  }
};

// src/preview/preview-service.ts
var import_obsidian11 = require("obsidian");
var IMAGE_EXTENSIONS2 = /* @__PURE__ */ new Set(["png", "jpg", "jpeg", "gif", "webp", "svg", "bmp", "avif"]);
var PreviewService = class {
  constructor(app, component) {
    this.app = app;
    this.component = component;
    __publicField(this, "groupObservers", /* @__PURE__ */ new WeakMap());
  }
  async render(parent, item, compact = false, compactLimit = 360, face = "front") {
    var _a, _b, _c, _d, _e, _f;
    (_a = this.groupObservers.get(parent)) == null ? void 0 : _a.disconnect();
    this.groupObservers.delete(parent);
    parent.empty();
    parent.addClass("cp-preview-content", `cp-preview-content--${item.type}`);
    if (face === "back") {
      parent.addClass("cp-preview-content--back");
      await import_obsidian11.MarkdownRenderer.render(this.app, compact ? item.backContent.slice(0, compactLimit) : item.backContent, parent, (_b = item.origin.filePath) != null ? _b : "", this.component);
      if (!item.backContent) parent.createDiv({ cls: "cp-empty cp-back-empty", text: "Write on the back\u2026" });
      return;
    }
    if (item.type === "image" && item.origin.filePath) {
      const file = this.app.vault.getAbstractFileByPath(item.origin.filePath);
      if (file instanceof import_obsidian11.TFile) parent.createEl("img", { attr: { src: this.app.vault.getResourcePath(file), alt: item.displayTitle, draggable: "false" } });
      else parent.createDiv({ cls: "cp-empty", text: "Original image is unavailable." });
      return;
    }
    if (item.type === "group" && item.group) {
      await this.renderCanvasGroup(parent, item.group, (_c = item.origin.canvasPath) != null ? _c : "", compact);
      return;
    }
    const source = (_e = (_d = item.content) != null ? _d : item.origin.filePath) != null ? _e : "No preview available.";
    if (item.type === "markdown" || item.type === "card") {
      await import_obsidian11.MarkdownRenderer.render(this.app, compact ? source.slice(0, compactLimit) : source, parent, (_f = item.origin.filePath) != null ? _f : "", this.component);
      return;
    }
    parent.setText(compact ? source.slice(0, 180) : source);
  }
  async renderCanvasGroup(parent, snapshot, sourcePath, compact) {
    var _a, _b, _c, _d, _e;
    const width = Math.max(snapshot.bounds.width, 1);
    const height = Math.max(snapshot.bounds.height, 1);
    const viewport = parent.createDiv({ cls: `cp-canvas-snapshot${compact ? " is-compact" : " is-large"}` });
    viewport.style.setProperty("--cp-canvas-aspect", `${width} / ${height}`);
    const stage = viewport.createDiv({ cls: "cp-canvas-snapshot__stage" });
    const updateScale = () => {
      if (!viewport.isConnected) return;
      const scale = Math.min(stage.clientWidth / width, stage.clientHeight / height);
      viewport.style.setProperty("--cp-canvas-scale", String(Math.max(scale, 1e-3)));
    };
    const observer = new ResizeObserver(updateScale);
    this.groupObservers.set(parent, observer);
    observer.observe(viewport);
    window.requestAnimationFrame(updateScale);
    for (const node of snapshot.nodes.filter((candidate) => candidate.type === "group")) {
      const frame = stage.createDiv({ cls: "cp-canvas-snapshot__group" });
      this.positionSnapshotNode(frame, node, width, height);
      frame.style.setProperty("--cp-canvas-color", this.canvasColor(node.color));
      frame.createDiv({ cls: "cp-canvas-snapshot__group-label", text: (_a = node.label) != null ? _a : "Group" });
    }
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.classList.add("cp-canvas-snapshot__edges");
    svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
    svg.setAttribute("preserveAspectRatio", "none");
    stage.appendChild(svg);
    for (const edge of snapshot.edges) this.renderCanvasEdge(svg, edge, snapshot.nodes, width, height);
    for (const node of snapshot.nodes.filter((candidate) => candidate.type !== "group")) {
      const card = stage.createDiv({ cls: `cp-canvas-snapshot__node cp-canvas-snapshot__node--${node.type}` });
      this.positionSnapshotNode(card, node, width, height);
      card.style.setProperty("--cp-canvas-color", this.canvasColor(node.color));
      const content = card.createDiv({ cls: "cp-canvas-snapshot__node-content markdown-rendered" });
      const file = node.file ? this.app.vault.getAbstractFileByPath(node.file) : null;
      if (file instanceof import_obsidian11.TFile && IMAGE_EXTENSIONS2.has(file.extension.toLowerCase())) {
        card.addClass("cp-canvas-snapshot__node--image");
        content.createEl("img", { attr: { src: this.app.vault.getResourcePath(file), alt: file.basename, draggable: "false" } });
      } else if (node.type === "text") {
        await import_obsidian11.MarkdownRenderer.render(this.app, (_b = node.text) != null ? _b : "", content, sourcePath, this.component);
      } else if (file instanceof import_obsidian11.TFile && file.extension.toLowerCase() === "md") {
        await import_obsidian11.MarkdownRenderer.render(this.app, await this.app.vault.cachedRead(file), content, file.path, this.component);
      } else content.setText((_e = (_d = node.label) != null ? _d : (_c = node.file) == null ? void 0 : _c.split("/").pop()) != null ? _e : "File");
    }
  }
  positionSnapshotNode(element, node, width, height) {
    element.style.left = `${node.x / width * 100}%`;
    element.style.top = `${node.y / height * 100}%`;
    element.style.width = `${node.width / width * 100}%`;
    element.style.height = `${node.height / height * 100}%`;
  }
  renderCanvasEdge(svg, edge, nodes, width, height) {
    var _a, _b;
    const from = nodes.find((node) => node.id === edge.fromNode);
    const to = nodes.find((node) => node.id === edge.toNode);
    if (!from || !to) return;
    const start = this.edgePoint(from, (_a = edge.fromSide) != null ? _a : "right");
    const end = this.edgePoint(to, (_b = edge.toSide) != null ? _b : "left");
    const horizontal = edge.fromSide === "left" || edge.fromSide === "right" || !edge.fromSide;
    const bend = horizontal ? Math.max(40, Math.abs(end.x - start.x) * 0.45) : Math.max(40, Math.abs(end.y - start.y) * 0.45);
    const c1 = horizontal ? { x: start.x + (edge.fromSide === "left" ? -bend : bend), y: start.y } : { x: start.x, y: start.y + (edge.fromSide === "top" ? -bend : bend) };
    const c2 = horizontal ? { x: end.x + (edge.toSide === "right" ? bend : -bend), y: end.y } : { x: end.x, y: end.y + (edge.toSide === "bottom" ? bend : -bend) };
    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    path.setAttribute("d", `M ${start.x} ${start.y} C ${c1.x} ${c1.y}, ${c2.x} ${c2.y}, ${end.x} ${end.y}`);
    path.setAttribute("vector-effect", "non-scaling-stroke");
    path.style.setProperty("--cp-canvas-color", this.canvasColor(edge.color));
    svg.appendChild(path);
    const endpoint = document.createElementNS("http://www.w3.org/2000/svg", "circle");
    endpoint.setAttribute("cx", String(end.x));
    endpoint.setAttribute("cy", String(end.y));
    endpoint.setAttribute("r", String(Math.max(width, height) / 180));
    endpoint.style.setProperty("--cp-canvas-color", this.canvasColor(edge.color));
    svg.appendChild(endpoint);
  }
  edgePoint(node, side) {
    if (side === "left") return { x: node.x, y: node.y + node.height / 2 };
    if (side === "top") return { x: node.x + node.width / 2, y: node.y };
    if (side === "bottom") return { x: node.x + node.width / 2, y: node.y + node.height };
    return { x: node.x + node.width, y: node.y + node.height / 2 };
  }
  canvasColor(color) {
    var _a, _b;
    return (_b = (_a = { "1": "#e93147", "2": "#ec7500", "3": "#e0ac00", "4": "#08b94e", "5": "#00a3c4", "6": "#7852ee" }[color != null ? color : ""]) != null ? _a : color) != null ? _b : "var(--interactive-accent)";
  }
};

// src/search/search-service.ts
var SearchService = class {
  matches(item, query, context = {}) {
    const tokens = this.tokens(query);
    if (tokens.length === 0) return true;
    let index = 0;
    const expression = () => {
      var _a;
      let result = conjunction();
      while (((_a = tokens[index]) == null ? void 0 : _a.toLocaleUpperCase()) === "OR") {
        index += 1;
        const right = conjunction();
        result = result || right;
      }
      return result;
    };
    const conjunction = () => {
      let result = true;
      let found = false;
      while (index < tokens.length && tokens[index] !== ")" && tokens[index].toLocaleUpperCase() !== "OR") {
        const right = primary();
        result = result && right;
        found = true;
      }
      return found ? result : true;
    };
    const primary = () => {
      const token = tokens[index++];
      if (token === "(") {
        const result = expression();
        if (tokens[index] === ")") index += 1;
        return result;
      }
      return this.matchesToken(item, token, context);
    };
    return expression();
  }
  filter(items, query, contextForItem) {
    return items.filter((item) => this.matches(item, query, contextForItem == null ? void 0 : contextForItem(item)));
  }
  hasToken(query, token) {
    const normalized = token.toLocaleLowerCase();
    return this.tokens(query).some((candidate) => candidate.toLocaleLowerCase() === normalized);
  }
  toggleToken(query, token) {
    var _a, _b;
    const tokens = this.tokens(query);
    const index = tokens.findIndex((candidate) => candidate.toLocaleLowerCase() === token.toLocaleLowerCase());
    if (index < 0) return [...tokens, token].join(" ").trim();
    tokens.splice(index, 1);
    if (((_a = tokens[index]) == null ? void 0 : _a.toLocaleUpperCase()) === "OR") tokens.splice(index, 1);
    else if (((_b = tokens[index - 1]) == null ? void 0 : _b.toLocaleUpperCase()) === "OR") tokens.splice(index - 1, 1);
    return tokens.join(" ").replace(/\(\s+/g, "(").replace(/\s+\)/g, ")").trim();
  }
  setFacet(query, facet, token) {
    const prefix = `${facet}:`;
    const tokens = this.tokens(query).filter((candidate) => !candidate.toLocaleLowerCase().startsWith(prefix));
    if (token) tokens.push(token);
    return tokens.join(" ").replace(/\(\s+/g, "(").replace(/\s+\)/g, ")").trim();
  }
  tokens(query) {
    var _a;
    return (_a = query.match(/(?:label|space|tag|type|group|file|path):"(?:\\.|[^"])*"|tag:#[^\s()]+|"(?:\\.|[^"])*"|\(|\)|\bOR\b|[^\s()]+/gi)) != null ? _a : [];
  }
  matchesToken(item, token, context) {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    const lower = token.toLocaleLowerCase();
    if (lower === "unlinked") return (_a = context.unlinked) != null ? _a : !(item.origin.canvasPath && item.origin.canvasNodeId) && !item.canvasPlacements.some((placement) => placement.nodeIds.length > 0);
    if (lower.startsWith("label:")) return item.label.toLocaleLowerCase() === this.unquote(token.slice(6)).toLocaleLowerCase();
    if (lower.startsWith("type:")) return item.type === lower.slice(5);
    if (lower.startsWith("group:")) {
      const value = this.unquote(token.slice(6)).toLocaleLowerCase();
      return ((_b = context.groupNames) != null ? _b : []).some((name) => name.toLocaleLowerCase().includes(value));
    }
    if (lower.startsWith("file:")) {
      const value = this.unquote(token.slice(5)).toLocaleLowerCase();
      return [item.displayTitle, (_d = (_c = item.origin.filePath) == null ? void 0 : _c.split("/").pop()) != null ? _d : ""].some((name) => name.toLocaleLowerCase().includes(value));
    }
    if (lower.startsWith("path:")) return ((_e = item.origin.filePath) != null ? _e : "").toLocaleLowerCase().includes(this.unquote(token.slice(5)).toLocaleLowerCase());
    if (lower.startsWith("space:")) {
      const space = this.unquote(token.slice(6)).toLocaleLowerCase();
      return [item.origin.canvasPath, ...item.canvasPlacements.map((placement) => placement.canvasPath)].some((path) => (path == null ? void 0 : path.toLocaleLowerCase()) === space);
    }
    const tag = lower.startsWith("tag:") ? this.unquote(token.slice(4)).replace(/^#/, "") : token.startsWith("#") ? token.slice(1) : null;
    if (tag !== null) return item.tags.some((value) => value.replace(/^#/, "").toLocaleLowerCase() === tag.toLocaleLowerCase());
    const needle = this.unquote(token).toLocaleLowerCase();
    return [item.displayTitle, (_f = item.content) != null ? _f : "", item.backContent, item.caption, item.label, (_g = item.origin.filePath) != null ? _g : "", ...item.tags, ...(_h = context.groupNames) != null ? _h : []].join("\n").toLocaleLowerCase().includes(needle);
  }
  unquote(value) {
    return value.startsWith('"') && value.endsWith('"') ? value.slice(1, -1).replace(/\\"/g, '"').replace(/\\\\/g, "\\") : value;
  }
};

// src/settings/settings-tab.ts
var import_obsidian12 = require("obsidian");
var CanvasPaletteSettingTab = class extends import_obsidian12.PluginSettingTab {
  constructor(plugin) {
    super(plugin.app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    containerEl.createEl("h2", { text: "Canvas Palette" });
    new import_obsidian12.Setting(containerEl).setName("Theme").setDesc("Follow Obsidian by default; theme changes never alter layout.").addDropdown((dropdown) => dropdown.addOption("obsidian", "Follow Obsidian").addOption("light", "Light").addOption("dark", "Dark").setValue(this.plugin.store.data.settings.theme).onChange(async (value) => {
      this.plugin.store.data.settings.theme = value;
      this.plugin.store.changed();
    }));
    new import_obsidian12.Setting(containerEl).setName("Accent color").setDesc("Use Obsidian's accent or select a custom Canvas Palette accent.").addDropdown((dropdown) => dropdown.addOption("obsidian", "Use Obsidian accent").addOption("custom", "Custom color").setValue(this.plugin.store.data.settings.accentMode).onChange((value) => {
      this.plugin.store.data.settings.accentMode = value;
      this.plugin.store.changed();
      this.display();
    }));
    if (this.plugin.store.data.settings.accentMode === "custom") new import_obsidian12.Setting(containerEl).setName("Custom accent").addColorPicker((picker) => picker.setValue(this.plugin.store.data.settings.accentColor).onChange((value) => {
      this.plugin.store.data.settings.accentColor = value;
      this.plugin.store.changed();
    }));
    new import_obsidian12.Setting(containerEl).setName("Asset size").setDesc("Side Palette and Mini Palette each keep their own Explorer-style item-size level. Change it from the palette's View settings or Control panel.");
    new import_obsidian12.Setting(containerEl).setName("Font size").setDesc("Reduce preview text from the default size.").addSlider((slider) => slider.setLimits(8, 14, 1).setDynamicTooltip().setValue(this.plugin.store.data.settings.fontSize).onChange((value) => {
      this.plugin.store.data.settings.fontSize = value;
      this.plugin.store.changed();
    }));
  }
};

// src/side-palette/side-palette-view.ts
var import_obsidian14 = require("obsidian");

// src/ui/linked-spaces-modal.ts
var import_obsidian13 = require("obsidian");
var LinkedSpacesModal = class extends import_obsidian13.Modal {
  constructor(app, items, activeQuery, hasToken, onFilter, onUnlink) {
    super(app);
    this.items = items;
    this.activeQuery = activeQuery;
    this.hasToken = hasToken;
    this.onFilter = onFilter;
    this.onUnlink = onUnlink;
  }
  onOpen() {
    var _a, _b, _c;
    this.contentEl.addClass("canvas-palette", "cp-linked-spaces-modal");
    const heading = this.contentEl.createDiv({ cls: "cp-linked-spaces__heading" });
    heading.createEl("h2", { text: "Linked spaces" });
    const clear = heading.createEl("button", { text: "Show all" });
    clear.disabled = !/\bspace:/i.test(this.activeQuery);
    clear.addEventListener("click", () => {
      this.onFilter(null);
      this.close();
    });
    const linkedItems = /* @__PURE__ */ new Map();
    for (const item of this.items) {
      const paths = new Set([item.origin.canvasPath, ...item.canvasPlacements.map((placement) => placement.canvasPath)].filter((path) => Boolean(path)));
      for (const path of paths) {
        const ids = (_a = linkedItems.get(path)) != null ? _a : /* @__PURE__ */ new Set();
        ids.add(item.id);
        linkedItems.set(path, ids);
      }
    }
    const list = this.contentEl.createDiv({ cls: "cp-linked-spaces__list" });
    for (const [path, itemIds] of [...linkedItems].sort((a, b) => b[1].size - a[1].size || a[0].localeCompare(b[0]))) {
      const count = itemIds.size;
      const token = `space:"${path.replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`;
      const row = list.createDiv({ cls: `cp-linked-space${this.hasToken(token) ? " is-active" : ""}` });
      const info = row.createDiv({ cls: "cp-linked-space__info" });
      info.createEl("strong", { text: (_c = (_b = path.split("/").pop()) == null ? void 0 : _b.replace(/\.canvas$/i, "")) != null ? _c : path });
      info.createSpan({ text: `${path} \xB7 ${count} item${count === 1 ? "" : "s"}` });
      const actions = row.createDiv({ cls: "cp-linked-space__actions" });
      const filter = actions.createEl("button", { text: this.hasToken(token) ? "Clear" : "Filter" });
      filter.addEventListener("click", () => {
        this.onFilter(this.hasToken(token) ? null : token);
        this.close();
      });
      const open = actions.createEl("button", { text: "Open" });
      open.addEventListener("click", () => {
        void this.app.workspace.openLinkText(path, "", false);
        this.close();
      });
      const unlink = actions.createEl("button", { text: "Unlink", cls: "mod-warning" });
      unlink.addEventListener("click", () => new ConfirmUnlinkModal(this.app, path, count, () => {
        this.onUnlink([...itemIds], path);
        this.close();
      }).open());
    }
    if (linkedItems.size === 0) list.createDiv({ cls: "cp-empty", text: "No linked Canvas spaces." });
  }
  onClose() {
    this.contentEl.empty();
  }
};
var ConfirmUnlinkModal = class extends import_obsidian13.Modal {
  constructor(app, path, count, onConfirm) {
    super(app);
    this.path = path;
    this.count = count;
    this.onConfirm = onConfirm;
  }
  onOpen() {
    this.contentEl.addClass("canvas-palette", "cp-confirm-modal");
    this.contentEl.createEl("h2", { text: "Unlink Canvas space?" });
    this.contentEl.createEl("p", { text: `${this.count} Palette item${this.count === 1 ? "" : "s"} will stop linking to ${this.path}. Canvas nodes, Vault files, and the Palette items will not be deleted.` });
    const actions = this.contentEl.createDiv({ cls: "cp-modal-actions" });
    actions.createEl("button", { text: "Cancel" }).addEventListener("click", () => this.close());
    actions.createEl("button", { text: "Unlink", cls: "mod-warning" }).addEventListener("click", () => {
      this.onConfirm();
      this.close();
    });
  }
  onClose() {
    this.contentEl.empty();
  }
};

// src/side-palette/side-palette-view.ts
var SIDE_PALETTE_VIEW = "canvas-palette-side";
var SidePaletteView = class extends import_obsidian14.ItemView {
  constructor(leaf, plugin) {
    super(leaf);
    this.plugin = plugin;
    __publicField(this, "unsubscribe");
    __publicField(this, "query", "");
    __publicField(this, "selectionAnchorId", null);
    /** Unified, visible-row Outliner selection. Collection selection deliberately stays out of persisted item state. */
    __publicField(this, "outlineSelection", []);
    __publicField(this, "outlineSelectionAnchorKey", null);
    __publicField(this, "lastCollectionClick", null);
    __publicField(this, "visibleItemIds", []);
    __publicField(this, "outlineRows", []);
    __publicField(this, "suppressBlankClick", false);
    __publicField(this, "viewSettingsOpen", false);
    __publicField(this, "outlinerSettingsOpen", false);
    __publicField(this, "searchComposing", false);
    __publicField(this, "searchAssistantOpen", false);
    __publicField(this, "pendingReveal", null);
    __publicField(this, "activeBackEditor", null);
    __publicField(this, "scrollSelectors", [".cp-viewport", ".cp-outliner", ".cp-tag-index", ".cp-label-index"]);
    __publicField(this, "scrollMemory", {});
    __publicField(this, "layoutMode", "wide");
    __publicField(this, "resizeObserver");
    __publicField(this, "indexesFlyoutOpen", false);
    __publicField(this, "activeIndexTab", "tag");
    __publicField(this, "indexesFlyoutCleanup");
  }
  getViewType() {
    return SIDE_PALETTE_VIEW;
  }
  getDisplayText() {
    return "Canvas Palette";
  }
  getIcon() {
    return "library-big";
  }
  async onOpen() {
    this.unsubscribe = this.plugin.store.subscribe(() => this.render());
    this.render();
  }
  async onClose() {
    var _a, _b, _c, _d;
    (_a = this.resizeObserver) == null ? void 0 : _a.disconnect();
    (_b = this.indexesFlyoutCleanup) == null ? void 0 : _b.call(this);
    (_c = this.unsubscribe) == null ? void 0 : _c.call(this);
    await ((_d = this.activeBackEditor) == null ? void 0 : _d.close(true));
  }
  revealItem(itemId) {
    var _a;
    this.query = "";
    this.selectionAnchorId = itemId;
    this.outlineSelection = [{ kind: "item", id: itemId }];
    this.outlineSelectionAnchorKey = "item:" + itemId;
    const workspace = this.plugin.activeWorkspace();
    if (workspace) {
      const collection = Object.values(this.plugin.store.data.collections).find((entry) => entry.workspaceId === workspace.id && entry.itemIds.includes(itemId));
      workspace.sideLayout.selectedCollectionId = (_a = collection == null ? void 0 : collection.id) != null ? _a : null;
      const expanded = [];
      let cursor = collection;
      while (cursor) {
        expanded.push(cursor.id);
        cursor = cursor.parentId ? this.plugin.store.data.collections[cursor.parentId] : void 0;
      }
      workspace.sideLayout.collapsedCollectionIds = workspace.sideLayout.collapsedCollectionIds.filter((id) => !expanded.includes(id));
    }
    this.plugin.store.data.uiState.sideSelectedItemIds = [itemId];
    this.plugin.store.data.uiState.selectedItemId = itemId;
    this.plugin.store.changed();
    window.requestAnimationFrame(() => window.requestAnimationFrame(() => {
      const card = this.contentEl.querySelector(`.cp-item[data-item-id="${CSS.escape(itemId)}"]`);
      if (!card) return;
      card.scrollIntoView({ block: "center", inline: "nearest" });
      card.addClass("is-link-revealed");
      window.setTimeout(() => card.removeClass("is-link-revealed"), 1600);
    }));
  }
  render() {
    var _a, _b, _c;
    if (this.activeBackEditor || this.searchComposing) return;
    const root = this.contentEl;
    const previousWorkspaceId = root.dataset.cpWorkspaceId;
    this.captureScrollMemory(root);
    (_a = this.resizeObserver) == null ? void 0 : _a.disconnect();
    this.resizeObserver = void 0;
    (_b = this.indexesFlyoutCleanup) == null ? void 0 : _b.call(this);
    this.indexesFlyoutCleanup = void 0;
    root.empty();
    root.addClass("canvas-palette", "cp-side", `cp-theme-${this.plugin.store.data.settings.theme}`);
    if (this.plugin.store.data.settings.accentMode === "custom") root.style.setProperty("--cp-accent", this.plugin.store.data.settings.accentColor);
    const workspace = this.plugin.activeWorkspace();
    if (!workspace) return;
    root.dataset.cpWorkspaceId = workspace.id;
    this.layoutMode = sideLayoutMode(root.clientWidth || ((_c = root.parentElement) == null ? void 0 : _c.clientWidth) || window.innerWidth);
    root.dataset.layoutMode = this.layoutMode;
    if (this.layoutMode === "wide") this.indexesFlyoutOpen = false;
    this.applyLayoutVariables(root, workspace.sideLayout);
    this.renderHeader(root, workspace.id);
    this.renderSearch(root, workspace.id);
    if (this.layoutMode === "wide") this.renderWideLayout(root, workspace.id);
    else this.renderCompactLayout(root, workspace.id);
    if (previousWorkspaceId === workspace.id) {
      this.restoreScrollMemory(root);
    }
    this.observeResponsiveLayout(root);
    if (this.indexesFlyoutOpen && this.layoutMode !== "wide") this.renderIndexesFlyout(root, workspace.id);
    if (this.pendingReveal) {
      const target = this.pendingReveal;
      this.pendingReveal = null;
      window.requestAnimationFrame(() => window.requestAnimationFrame(() => {
        var _a2;
        const id = this.plugin.store.data.uiState.selectedItemId;
        if (!id) return;
        const selector = target === "viewport" ? `.cp-item[data-item-id="${CSS.escape(id)}"]` : `.cp-outline-item[data-item-id="${CSS.escape(id)}"]`;
        (_a2 = this.contentEl.querySelector(selector)) == null ? void 0 : _a2.scrollIntoView({ block: "center", inline: "nearest" });
      }));
    }
  }
  renderHeader(root, workspaceId) {
    const header = root.createDiv({ cls: "cp-side__header" });
    header.createDiv({ cls: "cp-brand", text: "Canvas Palette" });
    const send = this.layoutMode === "wide" ? header.createEl("button", { text: "Export to Mini Palette" }) : iconButton(header, "send", "Export selected items to Mini Palette", () => this.plugin.sendItemsToMini(this.sideSelectedIds()));
    if (this.layoutMode === "wide") send.addEventListener("click", () => this.plugin.sendItemsToMini(this.sideSelectedIds()));
    if (this.layoutMode === "wide") {
      const exportButton = header.createEl("button", { text: "Export Workspace to Canvas" });
      exportButton.addEventListener("click", () => void this.plugin.exportActiveWorkspace());
    } else {
      const more = iconButton(header, "ellipsis", "More Canvas Palette actions", () => this.openHeaderMenu(more, workspaceId));
    }
    const selectorRow = root.createDiv({ cls: "cp-workspace-row" });
    selectorRow.createSpan({ cls: "cp-workspace-label", text: "Current workspace" });
    workspaceSelect(this.plugin, selectorRow, workspaceId, (id) => {
      this.query = "";
      this.plugin.store.data.uiState.activeWorkspaceId = id;
      this.plugin.store.changed();
    });
    const currentCanvas = selectorRow.createEl("button", { cls: "cp-current-canvas-workspace", attr: { title: "Open current Canvas Workspace", "aria-label": "Open current Canvas Workspace" } });
    (0, import_obsidian14.setIcon)(currentCanvas.createSpan(), "locate-fixed");
    currentCanvas.createSpan({ text: "Current Canvas" });
    currentCanvas.addEventListener("click", () => this.plugin.openCurrentCanvasWorkspace());
    currentCanvas.disabled = !this.plugin.currentCanvasPath();
    if (this.layoutMode === "wide") {
      const manageWorkspace = iconButton(selectorRow, "folder-cog", "Open Workspace Explorer", () => this.plugin.openWorkspaceExplorer());
      manageWorkspace.addClass("cp-workspace-manage");
    }
  }
  openHeaderMenu(trigger, workspaceId) {
    const menu = new import_obsidian14.Menu();
    menu.addItem((entry) => entry.setTitle("Export Workspace to Canvas").setIcon("download").onClick(() => void this.plugin.exportActiveWorkspace()));
    menu.addItem((entry) => entry.setTitle("Open Workspace Explorer").setIcon("folder-cog").onClick(() => this.plugin.openWorkspaceExplorer()));
    menu.addItem((entry) => entry.setTitle("Open linked spaces").setIcon("network").onClick(() => this.openLinkedSpaces(workspaceId)));
    const rect = trigger.getBoundingClientRect();
    menu.showAtPosition({ x: rect.right, y: rect.bottom });
  }
  renderSearch(root, workspaceId) {
    const searchWrap = root.createDiv({ cls: "cp-search-wrap" });
    const search = searchWrap.createEl("input", { cls: "cp-search", attr: { type: "search", placeholder: "Search files, groups, tags, labels\u2026", autocomplete: "off" }, value: this.query });
    const refreshSearch = () => this.refreshSearchSurface(searchWrap, workspaceId);
    search.addEventListener("compositionstart", () => {
      this.searchComposing = true;
    });
    search.addEventListener("compositionend", () => {
      this.searchComposing = false;
      this.query = search.value.normalize("NFC");
      search.value = this.query;
      queueMicrotask(refreshSearch);
    });
    search.addEventListener("input", (event) => {
      this.query = search.value;
      if (this.searchComposing || event.isComposing) return;
      refreshSearch();
    });
    search.addEventListener("keydown", (event) => {
      var _a;
      if (event.key === "ArrowDown") {
        event.preventDefault();
        (_a = searchWrap.querySelector(".cp-search-suggestion")) == null ? void 0 : _a.focus();
      } else if (event.key === "Escape") {
        event.preventDefault();
        event.stopPropagation();
        this.searchAssistantOpen = false;
        this.renderSearchAssistant(searchWrap, workspaceId);
      }
    });
    search.addEventListener("focus", () => {
      this.searchAssistantOpen = true;
      this.renderSearchAssistant(searchWrap, workspaceId);
    });
    search.addEventListener("pointerdown", () => {
      if (!this.searchAssistantOpen) {
        this.searchAssistantOpen = true;
        this.renderSearchAssistant(searchWrap, workspaceId);
      }
    });
    root.onpointerdown = (event) => {
      if (this.searchAssistantOpen && !searchWrap.contains(event.target)) {
        this.searchAssistantOpen = false;
        this.renderSearchAssistant(searchWrap, workspaceId);
        search.blur();
      }
    };
    this.renderSearchAssistant(searchWrap, workspaceId);
    return searchWrap;
  }
  renderWideLayout(root, workspaceId) {
    const workspace = this.plugin.store.data.workspaces[workspaceId];
    if (!workspace) return;
    const top = root.createDiv({ cls: "cp-side__top" });
    const viewport = top.createDiv({ cls: "cp-panel cp-viewport" });
    this.renderViewport(viewport, workspaceId);
    const vDivider = top.createDiv({ cls: "cp-divider cp-divider--vertical" });
    makeHorizontalDivider(vDivider, (x) => {
      workspace.sideLayout.viewportRatio = this.horizontalRatio(top, vDivider, x, 160, 180);
      this.applyLayoutVariables(root, workspace.sideLayout);
    }, () => this.plugin.store.changed());
    const outliner = top.createDiv({ cls: "cp-panel cp-outliner" });
    this.renderOutliner(outliner, workspaceId);
    const hDivider = root.createDiv({ cls: "cp-divider cp-divider--horizontal" });
    const indexes = root.createDiv({ cls: "cp-side__indexes" });
    makeVerticalDivider(hDivider, (y) => {
      workspace.sideLayout.topRatio = this.verticalRatio(top, indexes, hDivider, y);
      this.applyLayoutVariables(root, workspace.sideLayout);
    }, () => this.plugin.store.changed());
    const tags = indexes.createDiv({ cls: "cp-panel cp-tag-index" });
    this.renderIndex(tags, "Tag index", this.items(workspaceId).flatMap((item) => item.tags), "tag");
    const iDivider = indexes.createDiv({ cls: "cp-divider cp-divider--vertical" });
    makeHorizontalDivider(iDivider, (x) => {
      workspace.sideLayout.indexRatio = this.horizontalRatio(indexes, iDivider, x, 130, 130);
      this.applyLayoutVariables(root, workspace.sideLayout);
    }, () => this.plugin.store.changed());
    const labels = indexes.createDiv({ cls: "cp-panel cp-label-index" });
    this.renderIndex(labels, "Label index", this.items(workspaceId).map((item) => item.label).filter(Boolean), "label");
  }
  renderCompactLayout(root, workspaceId) {
    const workspace = this.plugin.store.data.workspaces[workspaceId];
    if (!workspace) return;
    const tabList = root.createDiv({ cls: "cp-side-tabs", attr: { role: "tablist", "aria-label": "Canvas Palette content" } });
    for (const [id, label, icon] of [["viewport", "Viewport", "layout-grid"], ["outliner", "Outliner", "list-tree"]]) {
      const selected = workspace.sideLayout.responsiveTab === id;
      const tab = tabList.createEl("button", { cls: `cp-side-tab${selected ? " is-active" : ""}`, text: label, attr: { role: "tab", id: `cp-side-${id}-${workspaceId}`, "aria-selected": String(selected), "aria-controls": `cp-side-panel-${workspaceId}`, tabindex: selected ? "0" : "-1" } });
      (0, import_obsidian14.setIcon)(tab.createSpan({ cls: "cp-side-tab__icon" }), icon);
      tab.addEventListener("click", () => this.selectResponsiveTab(workspaceId, id));
      tab.addEventListener("keydown", (event) => this.handleResponsiveTabKeydown(event, workspaceId, id));
    }
    const indexes = tabList.createEl("button", { cls: "cp-side-indexes-trigger", text: "Indexes", attr: { type: "button", "aria-label": "Open Indexes flyout", "aria-controls": `cp-side-indexes-${workspaceId}`, "aria-expanded": String(this.indexesFlyoutOpen), "data-cp-indexes-trigger": "true" } });
    (0, import_obsidian14.setIcon)(indexes.createSpan({ cls: "cp-side-tab__icon" }), "tags");
    indexes.addEventListener("click", () => this.setIndexesFlyoutOpen(!this.indexesFlyoutOpen));
    const single = root.createDiv({ cls: "cp-side__single", attr: { id: `cp-side-panel-${workspaceId}`, role: "tabpanel", "aria-labelledby": `cp-side-${workspace.sideLayout.responsiveTab}-${workspaceId}` } });
    const panel = single.createDiv({ cls: `cp-panel ${workspace.sideLayout.responsiveTab === "viewport" ? "cp-viewport" : "cp-outliner"}` });
    if (workspace.sideLayout.responsiveTab === "viewport") this.renderViewport(panel, workspaceId);
    else this.renderOutliner(panel, workspaceId);
  }
  selectResponsiveTab(workspaceId, tab) {
    const workspace = this.plugin.store.data.workspaces[workspaceId];
    if (!workspace || workspace.sideLayout.responsiveTab === tab) return;
    workspace.sideLayout.responsiveTab = tab;
    this.plugin.store.changed();
    queueMicrotask(() => {
      var _a;
      return (_a = this.contentEl.querySelector(`#cp-side-${tab}-${CSS.escape(workspaceId)}`)) == null ? void 0 : _a.focus();
    });
  }
  handleResponsiveTabKeydown(event, workspaceId, tab) {
    const tabs = ["viewport", "outliner"];
    const index = tabs.indexOf(tab);
    let next = null;
    if (event.key === "ArrowLeft") next = tabs[(index + tabs.length - 1) % tabs.length];
    else if (event.key === "ArrowRight") next = tabs[(index + 1) % tabs.length];
    else if (event.key === "Home") next = tabs[0];
    else if (event.key === "End") next = tabs[tabs.length - 1];
    else if (event.key === "Enter" || event.key === " ") next = tab;
    if (!next) return;
    event.preventDefault();
    this.selectResponsiveTab(workspaceId, next);
  }
  setIndexesFlyoutOpen(open) {
    if (this.layoutMode === "wide") return;
    this.indexesFlyoutOpen = open;
    this.render();
    queueMicrotask(() => {
      var _a, _b;
      if (open) (_a = this.contentEl.ownerDocument.querySelector(".cp-side-indexes-flyout [role=tab]")) == null ? void 0 : _a.focus();
      else (_b = this.contentEl.querySelector("[data-cp-indexes-trigger]")) == null ? void 0 : _b.focus();
    });
  }
  renderIndexesFlyout(root, workspaceId) {
    const doc = root.ownerDocument;
    const rootRect = root.getBoundingClientRect();
    const placement = attachedFlyoutPlacement(window.innerWidth, rootRect.left, rootRect.width, "left", 320);
    const flyout = doc.body.createDiv({ cls: `canvas-palette cp-side-indexes-flyout cp-theme-${this.plugin.store.data.settings.theme} is-${placement.side}`, attr: { id: `cp-side-indexes-${workspaceId}`, role: "dialog", "aria-label": "Indexes" } });
    flyout.style.width = `${placement.width}px`;
    flyout.style.top = `${Math.max(8, rootRect.top)}px`;
    flyout.style.height = `${Math.max(180, Math.min(rootRect.height, window.innerHeight - Math.max(8, rootRect.top) - 8))}px`;
    flyout.style.left = `${placement.side === "left" ? Math.max(8, rootRect.left - placement.width - 8) : Math.min(window.innerWidth - placement.width - 8, rootRect.right + 8)}px`;
    if (this.plugin.store.data.settings.accentMode === "custom") flyout.style.setProperty("--cp-accent", this.plugin.store.data.settings.accentColor);
    const heading = flyout.createDiv({ cls: "cp-side-indexes-flyout__header" });
    heading.createEl("h4", { text: "Indexes" });
    iconButton(heading, "x", "Close Indexes flyout", () => this.setIndexesFlyoutOpen(false));
    const tabs = flyout.createDiv({ cls: "cp-index-tabs", attr: { role: "tablist", "aria-label": "Index type" } });
    for (const [kind, label] of [["tag", "Tags"], ["label", "Labels"]]) {
      const selected = this.activeIndexTab === kind;
      const tab = tabs.createEl("button", { cls: selected ? "is-active" : "", text: label, attr: { role: "tab", "aria-selected": String(selected), tabindex: selected ? "0" : "-1" } });
      tab.addEventListener("click", () => this.selectIndexTab(kind));
      tab.addEventListener("keydown", (event) => {
        if (!["ArrowLeft", "ArrowRight", "Home", "End", "Enter", " "].includes(event.key)) return;
        event.preventDefault();
        this.selectIndexTab(event.key === "ArrowLeft" || event.key === "End" ? "label" : "tag");
      });
    }
    const panel = flyout.createDiv({ cls: `cp-panel cp-${this.activeIndexTab}-index` });
    if (this.activeIndexTab === "tag") this.renderIndex(panel, "Tag index", this.items(workspaceId).flatMap((item) => item.tags), "tag", false);
    else this.renderIndex(panel, "Label index", this.items(workspaceId).map((item) => item.label).filter(Boolean), "label", false);
    const onPointerDown = (event) => {
      if (flyout.contains(event.target) || root.contains(event.target)) return;
      window.setTimeout(() => this.setIndexesFlyoutOpen(false), 0);
    };
    const onKeydown = (event) => {
      if (event.key === "Escape") {
        event.preventDefault();
        this.setIndexesFlyoutOpen(false);
      }
    };
    doc.addEventListener("pointerdown", onPointerDown, true);
    doc.addEventListener("keydown", onKeydown, true);
    this.indexesFlyoutCleanup = () => {
      doc.removeEventListener("pointerdown", onPointerDown, true);
      doc.removeEventListener("keydown", onKeydown, true);
      flyout.remove();
    };
  }
  selectIndexTab(tab) {
    if (this.activeIndexTab === tab) return;
    this.activeIndexTab = tab;
    this.render();
    queueMicrotask(() => {
      var _a;
      return (_a = this.contentEl.ownerDocument.querySelector(`.cp-side-indexes-flyout [role=tab][aria-selected="true"]`)) == null ? void 0 : _a.focus();
    });
  }
  captureScrollMemory(root) {
    for (const selector of this.scrollSelectors) {
      const panel = root.querySelector(selector);
      if (panel) this.scrollMemory[selector] = panel.scrollTop;
    }
  }
  restoreScrollMemory(root) {
    for (const selector of this.scrollSelectors) {
      const panel = root.querySelector(selector);
      if (panel && this.scrollMemory[selector] !== void 0) panel.scrollTop = this.scrollMemory[selector];
    }
  }
  observeResponsiveLayout(root) {
    var _a;
    (_a = this.resizeObserver) == null ? void 0 : _a.disconnect();
    this.resizeObserver = new ResizeObserver((entries) => {
      var _a2, _b;
      const width = (_b = (_a2 = entries[0]) == null ? void 0 : _a2.contentRect.width) != null ? _b : root.clientWidth;
      const next = sideLayoutMode(width);
      if (next === this.layoutMode) return;
      this.layoutMode = next;
      if (next === "wide") this.indexesFlyoutOpen = false;
      this.render();
    });
    this.resizeObserver.observe(root);
  }
  renderSearchAssistant(parent, workspaceId) {
    var _a, _b;
    parent.querySelectorAll(":scope > .cp-search-chips, :scope > .cp-search-assistant").forEach((element) => element.remove());
    const facetTokens = this.plugin.search.tokens(this.query).filter((token) => /^(tag|label|type|group|file|path|space):/i.test(token));
    if (facetTokens.length > 0) {
      const chips = parent.createDiv({ cls: "cp-search-chips" });
      for (const token of facetTokens) {
        const chip = chips.createEl("button", { cls: "cp-search-chip", text: token });
        chip.createSpan({ text: " \xD7" });
        chip.addEventListener("click", () => {
          this.query = this.plugin.search.toggleToken(this.query, token);
          const search = parent.querySelector(".cp-search");
          if (search) search.value = this.query;
          this.refreshSearchSurface(parent, workspaceId);
        });
      }
    }
    if (!this.searchAssistantOpen) return;
    const facetMatch = this.query.match(/(?:^|\s)(tag|label|type|group|file|path|space):([^\s]*)$/i);
    const assistant = parent.createDiv({ cls: "cp-search-assistant is-visible" });
    if (!facetMatch) {
      assistant.createDiv({ cls: "cp-search-assistant__title", text: "Search options" });
      const options = [
        ["tag:", "Search tags"],
        ["label:", "Search labels"],
        ["type:", "Search item types"],
        ["group:", "Search group names"],
        ["file:", "Search file names"],
        ["path:", "Search original file paths"],
        ["space:", "Search linked Canvases"]
      ];
      for (const [token, description] of options) this.searchSuggestion(assistant, token, description, () => this.appendSearchFacet(token));
      return;
    }
    const facet = facetMatch[1].toLocaleLowerCase();
    const rawFragment = facetMatch[2].replace(/^"|"$/g, "").toLocaleLowerCase();
    const fragment = facet === "tag" ? rawFragment.replace(/^#/, "") : rawFragment;
    const facetStart = facetMatch.index + (facetMatch[0].startsWith(" ") ? 1 : 0);
    const precedingQuery = this.query.slice(0, facetStart).trim();
    const items = this.plugin.search.filter(this.items(workspaceId), precedingQuery, (item) => this.searchContextForItem(workspaceId, item));
    const counts = /* @__PURE__ */ new Map();
    const addValues = (values2) => {
      var _a2;
      for (const clean of new Set(values2.map((value) => value.trim()).filter((value) => value && value.toLocaleLowerCase().includes(fragment)))) counts.set(clean, ((_a2 = counts.get(clean)) != null ? _a2 : 0) + 1);
    };
    for (const item of items) {
      if (facet === "tag") addValues(item.tags);
      else if (facet === "label") addValues([item.label]);
      else if (facet === "type") addValues([item.type]);
      else if (facet === "file") addValues([item.displayTitle]);
      else if (facet === "path") addValues([(_a = item.origin.filePath) != null ? _a : ""]);
      else if (facet === "space") addValues([item.origin.canvasPath && item.origin.canvasNodeId ? item.origin.canvasPath : "", ...item.canvasPlacements.filter((placement) => placement.nodeIds.length > 0).map((placement) => placement.canvasPath)]);
      else if (facet === "group") addValues((_b = this.searchContextForItem(workspaceId, item).groupNames) != null ? _b : []);
    }
    assistant.createDiv({ cls: "cp-search-assistant__title", text: `Matching ${facet}` });
    const values = [...counts.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0])).slice(0, 12);
    if (values.length === 0) assistant.createDiv({ cls: "cp-search-assistant__empty", text: "No matching suggestions." });
    for (const [value, count] of values) this.searchSuggestion(assistant, facet === "tag" ? `#${value.replace(/^#/, "")}` : value, String(count), () => {
      const normalizedValue = facet === "tag" ? value.replace(/^#/, "") : value;
      const encoded = /\s/.test(normalizedValue) ? `"${normalizedValue.replace(/"/g, '\\"')}"` : normalizedValue;
      this.query = `${this.query.slice(0, facetMatch.index + (facetMatch[0].startsWith(" ") ? 1 : 0))}${facet}:${encoded}`.trim();
      const search = parent.querySelector(".cp-search");
      if (search) search.value = this.query;
      this.searchAssistantOpen = false;
      this.refreshSearchSurface(parent, workspaceId);
    });
  }
  searchSuggestion(parent, label, description, action) {
    const button = parent.createEl("button", { cls: "cp-search-suggestion" });
    button.createSpan({ cls: "cp-search-suggestion__label", text: label });
    button.createSpan({ cls: "cp-search-suggestion__description", text: description });
    button.addEventListener("click", action);
    button.addEventListener("keydown", (event) => {
      var _a, _b;
      if (event.key === "ArrowDown") {
        event.preventDefault();
        (_a = button.nextElementSibling) == null ? void 0 : _a.focus();
      } else if (event.key === "ArrowUp") {
        event.preventDefault();
        const previous = button.previousElementSibling;
        if (previous == null ? void 0 : previous.matches("button")) previous.focus();
        else (_b = this.contentEl.querySelector(".cp-search")) == null ? void 0 : _b.focus();
      }
    });
  }
  appendSearchFacet(token) {
    var _a, _b;
    this.query = `${this.query.trim()}${this.query.trim() ? " " : ""}${token}`;
    const parent = this.contentEl.querySelector(".cp-search-wrap");
    const search = parent == null ? void 0 : parent.querySelector(".cp-search");
    if (!parent || !search) return;
    search.value = this.query;
    this.searchAssistantOpen = true;
    this.refreshSearchSurface(parent, (_b = (_a = this.plugin.activeWorkspace()) == null ? void 0 : _a.id) != null ? _b : "");
    search.focus();
    search.setSelectionRange(search.value.length, search.value.length);
  }
  refreshSearchSurface(searchWrap, workspaceId) {
    this.renderSearchAssistant(searchWrap, workspaceId);
    const viewport = this.contentEl.querySelector(".cp-viewport");
    if (!viewport) return;
    const scrollTop = viewport.scrollTop;
    viewport.empty();
    this.renderViewport(viewport, workspaceId);
    viewport.scrollTop = scrollTop;
  }
  searchContextForItem(workspaceId, item) {
    const names = [];
    let cursor = item.parentItemId ? this.plugin.store.data.items[item.parentItemId] : void 0;
    while (cursor) {
      names.push(cursor.displayTitle);
      cursor = cursor.parentItemId ? this.plugin.store.data.items[cursor.parentItemId] : void 0;
    }
    let rootId = item.id;
    let root = item;
    while (root.parentItemId && this.plugin.store.data.items[root.parentItemId]) {
      rootId = root.parentItemId;
      root = this.plugin.store.data.items[root.parentItemId];
    }
    let collection = Object.values(this.plugin.store.data.collections).find((entry) => entry.workspaceId === workspaceId && entry.itemIds.includes(rootId));
    while (collection) {
      names.push(collection.name);
      collection = collection.parentId ? this.plugin.store.data.collections[collection.parentId] : void 0;
    }
    return { groupNames: [...new Set(names)], unlinked: !this.plugin.store.itemLinkedToWorkspace(item, workspaceId) };
  }
  renderViewport(parent, workspaceId) {
    var _a, _b, _c, _d;
    const header = parent.createDiv({ cls: "cp-panel__header" });
    header.createEl("h4", { text: "Viewport" });
    const selectedIds = this.sideSelectedIds().filter((id) => this.plugin.store.data.items[id]);
    if (selectedIds.length > 0) {
      header.createSpan({ cls: "cp-selection-count", text: `Selected ${selectedIds.length}` });
      const remove = iconButton(header, "trash-2", `Delete ${selectedIds.length} selected item${selectedIds.length === 1 ? "" : "s"}`, () => this.confirmDelete(selectedIds));
      remove.addClass("mod-warning", "cp-selection-delete");
    }
    const filters = parent.createDiv({ cls: "cp-viewport-filters" });
    const typeFilters = [["All", null], ["Image", "image"], ["MD", "markdown"], ["Card", "card"], ["Group", "group"]];
    for (const [label, type] of typeFilters) {
      const token = type ? `type:${type}` : null;
      const active = token ? this.plugin.search.hasToken(this.query, token) : !/\btype:/i.test(this.query);
      const button = filters.createEl("button", { text: label, cls: active ? "is-active" : "", attr: { "aria-pressed": String(active) } });
      button.addEventListener("click", () => {
        this.query = this.plugin.search.setFacet(this.query, "type", active ? null : token);
        this.render();
      });
    }
    const unlinkedActive = this.plugin.search.hasToken(this.query, "unlinked");
    const unlinked = filters.createEl("button", { text: "Unlinked", cls: unlinkedActive ? "is-active cp-unlinked-filter" : "cp-unlinked-filter", attr: { "aria-pressed": String(unlinkedActive), title: "Show items with no Canvas link" } });
    unlinked.addEventListener("click", () => {
      this.query = this.plugin.search.toggleToken(this.query, "unlinked");
      this.render();
    });
    const spaces = filters.createEl("button", { text: "Linked spaces", cls: /\bspace:/i.test(this.query) ? "is-active cp-linked-spaces-button" : "cp-linked-spaces-button" });
    spaces.addEventListener("click", () => this.openLinkedSpaces(workspaceId));
    const tools = parent.createDiv({ cls: "cp-viewport-tools" });
    const options = tools.createEl("details", { cls: "cp-view-options" });
    options.open = this.viewSettingsOpen;
    options.addEventListener("toggle", () => {
      this.viewSettingsOpen = options.open;
    });
    options.createEl("summary", { text: "View settings" });
    const controls = options.createDiv({ cls: "cp-view-options__controls" });
    const viewSwitch = controls.createDiv({ cls: "cp-view-switch" });
    const grid = viewSwitch.createEl("button", { text: "Grid", cls: ((_a = this.plugin.activeWorkspace()) == null ? void 0 : _a.sideLayout.viewMode) === "grid" ? "is-active" : "" });
    const list = viewSwitch.createEl("button", { text: "List", cls: ((_b = this.plugin.activeWorkspace()) == null ? void 0 : _b.sideLayout.viewMode) === "list" ? "is-active" : "" });
    grid.addEventListener("click", () => this.setSideView("grid"));
    list.addEventListener("click", () => this.setSideView("list"));
    const memo = tools.createEl("button", { text: "+ Memo", cls: "cp-viewport-memo" });
    memo.addEventListener("click", () => void this.plugin.createMemo());
    const workspaceLayout = (_c = this.plugin.activeWorkspace()) == null ? void 0 : _c.sideLayout;
    const listEl = parent.createDiv({ cls: "cp-grid" });
    const applyViewSettings = () => {
      if (workspaceLayout) {
        workspaceLayout.densityLevel = applyAssetDensity(listEl, workspaceLayout.densityLevel, "cp-grid");
        workspaceLayout.viewMode = workspaceLayout.densityLevel === 0 ? "list" : "grid";
      }
      listEl.style.setProperty("--cp-font-size", `${this.plugin.store.data.settings.fontSize}px`);
      listEl.style.setProperty("--font-text-size", `${this.plugin.store.data.settings.fontSize}px`);
    };
    const rangeControl = (label, key, minimum, maximum, defaultValue) => {
      const row = controls.createDiv({ cls: "cp-view-option" });
      const heading = row.createDiv({ cls: "cp-view-option__heading" });
      const name = heading.createEl("label", { text: label });
      const value = heading.createSpan({ cls: "cp-view-option__value" });
      const reset = heading.createEl("button", { text: "Reset", cls: "cp-view-option__reset" });
      const input = row.createEl("input", { attr: { type: "range", min: String(minimum), max: String(maximum), value: String(this.plugin.store.data.settings[key]), "aria-label": label } });
      name.htmlFor = input.id = `cp-side-${key}`;
      const update = () => {
        this.plugin.store.data.settings[key] = Number(input.value);
        value.setText(`${input.value}px`);
        applyViewSettings();
      };
      update();
      input.addEventListener("input", update);
      input.addEventListener("change", () => this.plugin.store.changed());
      reset.addEventListener("click", () => {
        input.value = String(defaultValue);
        update();
        this.plugin.store.changed();
      });
    };
    if (workspaceLayout) {
      const row = controls.createDiv({ cls: "cp-view-option" });
      const heading = row.createDiv({ cls: "cp-view-option__heading" });
      const name = heading.createEl("label", { text: "Item size" });
      const value = heading.createSpan({ cls: "cp-view-option__value" });
      const reset = heading.createEl("button", { text: "Reset", cls: "cp-view-option__reset" });
      const input = row.createEl("input", { attr: { type: "range", min: String(ASSET_DENSITY_MIN), max: String(ASSET_DENSITY_MAX), step: "1", value: String(workspaceLayout.densityLevel), "aria-label": "Item size" } });
      name.htmlFor = input.id = "cp-side-density";
      const updateDensity = () => {
        workspaceLayout.densityLevel = Number(input.value);
        value.setText(assetDensityLabel(workspaceLayout.densityLevel));
        applyViewSettings();
      };
      updateDensity();
      input.addEventListener("input", updateDensity);
      input.addEventListener("change", () => this.plugin.store.changed());
      reset.addEventListener("click", () => {
        input.value = String(ASSET_DENSITY_DEFAULT);
        updateDensity();
        this.plugin.store.changed();
      });
    }
    rangeControl("Preview font size", "fontSize", 8, 14, 14);
    applyViewSettings();
    listEl.addEventListener("wheel", (event) => {
      if (!event.ctrlKey && !event.metaKey || !workspaceLayout) return;
      event.preventDefault();
      event.stopPropagation();
      workspaceLayout.densityLevel = nextAssetDensity(workspaceLayout.densityLevel, event.deltaY);
      applyViewSettings();
      this.plugin.store.changed();
    }, { passive: false });
    this.mountViewportReorder(parent, listEl, workspaceId);
    const visibleItems = this.plugin.search.filter(this.itemsForViewportScope(workspaceId), this.query, (item) => this.searchContextForItem(workspaceId, item));
    const workspace = this.plugin.store.data.workspaces[workspaceId];
    const collection = workspace.sideLayout.focusedCollectionId ? this.plugin.store.data.collections[workspace.sideLayout.focusedCollectionId] : null;
    parent.createDiv({ cls: "cp-viewport-scope", text: `${(_d = collection == null ? void 0 : collection.name) != null ? _d : workspace.name} \xB7 ${visibleItems.length} items` });
    this.visibleItemIds = visibleItems.map((item) => item.id);
    const visibleSet = new Set(visibleItems.map((item) => item.id));
    const renderCard = (host, item) => {
      var _a2;
      const facesEnabled = supportsFrontBack(item) && item.facesEnabled;
      const face = facesEnabled ? (_a2 = this.plugin.store.data.uiState.sideItemFaces[item.id]) != null ? _a2 : "front" : "front";
      const card = renderItem(host, item, { selected: selectedIds.includes(item.id), showSelectionMarker: selectedIds.length > 1, dragItemIds: selectedIds, currentFace: face, unlinked: !this.plugin.store.itemLinkedToWorkspace(item, workspaceId), markdownSourceStatus: this.plugin.markdownSourceStatus(item), onMarkdownSourceStatus: (event) => this.plugin.showMarkdownSourceMenu(item, event), onToggleFace: facesEnabled ? (next) => this.plugin.store.setPaletteFace("side", item.id, next) : void 0, onSelect: (event) => {
        this.pendingReveal = "outliner";
        this.selectSideItem(item.id, event);
      }, onOpen: () => face === "back" ? void this.openInlineBackEditor(item.id) : void this.plugin.openSideItemPreview(item.id), onLocate: () => this.plugin.findLinkedCanvas(item), draggable: true, onContextMenu: (event) => this.itemMenu(event, item) });
      const body = card.querySelector(".cp-item__body");
      if (body) {
        const compactLimit = Math.round(360 * 14 / this.plugin.store.data.settings.fontSize);
        const canBrowseFullBody = selectedIds.includes(item.id) && (face === "back" || item.type === "card" || item.type === "markdown");
        void this.plugin.preview.render(body, item, true, canBrowseFullBody ? Number.MAX_SAFE_INTEGER : compactLimit, face);
        if (canBrowseFullBody) this.mountBodyDragScroll(card, body);
      }
      card.addEventListener("wheel", (event) => {
        if (!selectedIds.includes(item.id) || item.type !== "card" && item.type !== "markdown" || !(body == null ? void 0 : body.contains(event.target))) return;
        event.preventDefault();
        event.stopPropagation();
        body.scrollTop += event.deltaY;
      }, { passive: false });
    };
    const renderItemTree = (host, itemId) => {
      var _a2;
      const item = this.plugin.store.data.items[itemId];
      if (!item) return;
      const descendantIds = [];
      const collect = (id) => {
        var _a3;
        const current = this.plugin.store.data.items[id];
        if (!current) return;
        if (visibleSet.has(id)) descendantIds.push(id);
        for (const child of (_a3 = current.childItemIds) != null ? _a3 : []) collect(child);
      };
      collect(itemId);
      if (descendantIds.length === 0) return;
      if (((_a2 = item.childItemIds) != null ? _a2 : []).length === 0) {
        if (visibleSet.has(item.id)) renderCard(host, item);
        return;
      }
      const group = host.createDiv({ cls: "cp-viewport-group cp-viewport-file-group" });
      const head = group.createDiv({ cls: "cp-viewport-group__header" });
      const collapsed = workspace.sideLayout.collapsedItemIds.includes(item.id);
      const arrow = head.createEl("button", { cls: "cp-outline-arrow", attr: { "aria-label": collapsed ? "Expand Viewport group" : "Collapse Viewport group" } });
      (0, import_obsidian14.setIcon)(arrow, collapsed ? "chevron-right" : "chevron-down");
      arrow.addEventListener("click", () => {
        workspace.sideLayout.collapsedItemIds = collapsed ? workspace.sideLayout.collapsedItemIds.filter((id) => id !== item.id) : [...workspace.sideLayout.collapsedItemIds, item.id];
        this.plugin.store.changed();
      });
      head.createSpan({ cls: "cp-viewport-group__title", text: item.displayTitle });
      head.createSpan({ cls: "cp-viewport-group__count", text: `${descendantIds.length} items` });
      head.addEventListener("dblclick", () => {
        this.pendingReveal = "outliner";
        this.selectSideItem(item.id);
      });
      if (!collapsed) {
        const body = group.createDiv({ cls: "cp-viewport-group__body" });
        for (const id of descendantIds) {
          const child = this.plugin.store.data.items[id];
          if (child) renderCard(body, child);
        }
      }
    };
    const collectionItems = (collectionId) => {
      const ids = [];
      const walk = (id) => {
        const current = this.plugin.store.data.collections[id];
        if (!current) return;
        ids.push(...current.itemIds);
        if (workspace.sideLayout.outlinerIncludeDescendants) for (const child of current.childCollectionIds) walk(child);
      };
      walk(collectionId);
      return ids;
    };
    if (!collection) {
      const groupedIds = /* @__PURE__ */ new Set();
      for (const collectionId of workspace.rootCollectionIds) {
        const current = this.plugin.store.data.collections[collectionId];
        if (!current) continue;
        const roots = collectionItems(collectionId);
        const matches = roots.flatMap((id) => {
          const result = [];
          const walk = (itemId) => {
            var _a2, _b2;
            if (visibleSet.has(itemId)) result.push(itemId);
            for (const child of (_b2 = (_a2 = this.plugin.store.data.items[itemId]) == null ? void 0 : _a2.childItemIds) != null ? _b2 : []) walk(child);
          };
          walk(id);
          return result;
        });
        if (matches.length === 0) continue;
        matches.forEach((id) => groupedIds.add(id));
        const group = listEl.createDiv({ cls: "cp-viewport-group" });
        const head = group.createDiv({ cls: "cp-viewport-group__header" });
        const collapsed = workspace.sideLayout.collapsedCollectionIds.includes(collectionId);
        const arrow = head.createEl("button", { cls: "cp-outline-arrow" });
        (0, import_obsidian14.setIcon)(arrow, collapsed ? "chevron-right" : "chevron-down");
        arrow.addEventListener("click", () => {
          workspace.sideLayout.collapsedCollectionIds = collapsed ? workspace.sideLayout.collapsedCollectionIds.filter((id) => id !== collectionId) : [...workspace.sideLayout.collapsedCollectionIds, collectionId];
          this.plugin.store.changed();
        });
        head.createSpan({ cls: "cp-viewport-group__title", text: current.name });
        head.createSpan({ cls: "cp-viewport-group__count", text: `${matches.length} items` });
        head.addEventListener("dblclick", () => {
          workspace.sideLayout.focusedCollectionId = collectionId;
          workspace.sideLayout.selectedCollectionId = collectionId;
          this.plugin.store.changed();
        });
        if (!collapsed) {
          const body = group.createDiv({ cls: "cp-viewport-group__body" });
          for (const rootId of roots) renderItemTree(body, rootId);
        }
      }
      for (const rootId of workspace.looseItemIds) renderItemTree(listEl, rootId);
    } else {
      for (const rootId of collection.itemIds) renderItemTree(listEl, rootId);
      if (workspace.sideLayout.outlinerIncludeDescendants) for (const childCollectionId of collection.childCollectionIds) for (const rootId of collectionItems(childCollectionId)) renderItemTree(listEl, rootId);
    }
    if (listEl.childElementCount === 0) {
      const empty = listEl.createDiv({ cls: "cp-empty cp-search-empty" });
      empty.createDiv({ text: "No matching items." });
      if (this.query.trim()) {
        empty.createDiv({ cls: "cp-search-empty__query", text: `Current search: ${this.query}` });
        const reset = empty.createEl("button", { text: "Clear search" });
        reset.addEventListener("click", () => {
          this.query = "";
          this.render();
        });
      }
    }
    this.mountViewportSelection(parent, listEl);
  }
  mountBodyDragScroll(card, body) {
    body.addClass("is-pan-enabled");
    body.addEventListener("pointerdown", (event) => {
      if (event.button !== 0) return;
      const startY = event.clientY;
      const startScrollTop = body.scrollTop;
      let moved = false;
      card.draggable = false;
      body.setPointerCapture(event.pointerId);
      const move = (pointer) => {
        const delta = pointer.clientY - startY;
        if (!moved && Math.abs(delta) < 3) return;
        moved = true;
        pointer.preventDefault();
        pointer.stopPropagation();
        body.addClass("is-panning");
        body.scrollTop = startScrollTop - delta;
      };
      const finish = (pointer) => {
        if (body.hasPointerCapture(pointer.pointerId)) body.releasePointerCapture(pointer.pointerId);
        body.removeClass("is-panning");
        card.draggable = true;
        body.removeEventListener("pointermove", move);
        body.removeEventListener("pointerup", finish);
        body.removeEventListener("pointercancel", finish);
        if (moved) {
          pointer.preventDefault();
          pointer.stopPropagation();
          body.addEventListener("click", (click) => {
            click.preventDefault();
            click.stopImmediatePropagation();
          }, { capture: true, once: true });
        }
      };
      body.addEventListener("pointermove", move);
      body.addEventListener("pointerup", finish);
      body.addEventListener("pointercancel", finish);
    });
  }
  async openInlineBackEditor(itemId) {
    var _a, _b;
    if (((_a = this.activeBackEditor) == null ? void 0 : _a.itemId) === itemId) return;
    await ((_b = this.activeBackEditor) == null ? void 0 : _b.close(true));
    const item = this.plugin.store.data.items[itemId];
    const card = this.contentEl.querySelector(`.cp-item[data-item-id="${CSS.escape(itemId)}"]`);
    const body = card == null ? void 0 : card.querySelector(".cp-item__body");
    if (!item || !card || !body || body.dataset.face !== "back") return;
    body.empty();
    body.removeClass("is-pan-enabled", "is-panning");
    body.addClass("is-back-editing");
    card.addClass("is-back-editing");
    card.draggable = false;
    const host = body.createDiv({ cls: "cp-side-back-editor cp-native-editor-host", attr: { "aria-label": `Edit ${item.displayTitle} back inside the Palette card` } });
    const editor = new NativeMarkdownEditor(this.app, { itemId, kind: "card", file: null, title: `${item.displayTitle} \u2014 Back`, initialText: item.backContent });
    const doc = body.ownerDocument;
    let finishing = false;
    const close = async (save) => {
      var _a2;
      if (finishing) return;
      finishing = true;
      doc.removeEventListener("pointerdown", onOutsidePointer, true);
      host.removeEventListener("keydown", onKeyDown, true);
      const text = editor.getText();
      editor.detach();
      if (((_a2 = this.activeBackEditor) == null ? void 0 : _a2.itemId) === itemId) this.activeBackEditor = null;
      if (save && text !== item.backContent) this.plugin.store.setItemBack(itemId, text);
      else this.render();
    };
    const onOutsidePointer = (event) => {
      if (!card.contains(event.target)) window.setTimeout(() => void close(true), 0);
    };
    const onKeyDown = (event) => {
      event.stopPropagation();
      if (event.key === "Escape") {
        event.preventDefault();
        void close(true);
      } else if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s") {
        event.preventDefault();
        this.plugin.store.setItemBack(itemId, editor.getText());
      }
    };
    this.activeBackEditor = { itemId, close };
    host.addEventListener("pointerdown", (event) => event.stopPropagation());
    host.addEventListener("click", (event) => event.stopPropagation());
    host.addEventListener("dblclick", (event) => event.stopPropagation());
    host.addEventListener("keydown", onKeyDown, true);
    try {
      await editor.mount(host, false);
      window.requestAnimationFrame(() => editor.remeasure());
      window.setTimeout(() => doc.addEventListener("pointerdown", onOutsidePointer, true), 0);
    } catch (error) {
      editor.detach();
      this.activeBackEditor = null;
      this.render();
      console.error("Canvas Palette could not mount the Side Palette Back editor", error);
    }
  }
  renderOutliner(parent, workspaceId) {
    var _a, _b, _c;
    const header = parent.createDiv({ cls: "cp-panel__header" });
    header.createEl("h4", { text: "Outliner" });
    const collection = header.createEl("button", { text: "+ Collection" });
    collection.addEventListener("click", () => this.promptCollection(workspaceId, null));
    const memo = header.createEl("button", { text: "+ Memo" });
    memo.addEventListener("click", () => void this.plugin.createMemo());
    const workspace = this.plugin.store.data.workspaces[workspaceId];
    if (!workspace) return;
    parent.style.setProperty("--cp-outline-height", `${workspace.sideLayout.outlinerItemHeight}px`);
    parent.style.setProperty("--cp-outline-font", `${workspace.sideLayout.outlinerFontSize}px`);
    parent.toggleClass("is-wrap-titles", workspace.sideLayout.outlinerWrapTitles);
    const options = parent.createEl("details", { cls: "cp-outline-options" });
    options.open = this.outlinerSettingsOpen;
    options.addEventListener("toggle", () => {
      this.outlinerSettingsOpen = options.open;
    });
    options.createEl("summary", { text: "Outliner settings" });
    const addRange = (label, key, min, max) => {
      const row = options.createDiv({ cls: "cp-outline-option" });
      row.createSpan({ text: label });
      const value = row.createSpan({ text: `${workspace.sideLayout[key]}px` });
      const input = row.createEl("input", { attr: { type: "range", min: String(min), max: String(max), value: String(workspace.sideLayout[key]) } });
      input.addEventListener("input", () => {
        workspace.sideLayout[key] = Number(input.value);
        value.setText(`${input.value}px`);
        parent.style.setProperty(key === "outlinerItemHeight" ? "--cp-outline-height" : "--cp-outline-font", `${input.value}px`);
      });
      input.addEventListener("change", () => this.plugin.store.changed());
    };
    addRange("Row height", "outlinerItemHeight", 24, 44);
    addRange("Font size", "outlinerFontSize", 11, 16);
    for (const [label, key] of [["Include nested collections", "outlinerIncludeDescendants"], ["Wrap long titles", "outlinerWrapTitles"]]) {
      const row = options.createEl("label", { cls: "cp-outline-toggle" });
      const input = row.createEl("input", { attr: { type: "checkbox" } });
      input.checked = workspace.sideLayout[key];
      row.createSpan({ text: label });
      input.addEventListener("change", () => {
        workspace.sideLayout[key] = input.checked;
        this.plugin.store.changed();
      });
    }
    const breadcrumb = parent.createDiv({ cls: "cp-outline-breadcrumb" });
    const path = [];
    let cursor = workspace.sideLayout.focusedCollectionId ? this.plugin.store.data.collections[workspace.sideLayout.focusedCollectionId] : void 0;
    while (cursor) {
      path.unshift(cursor);
      cursor = cursor.parentId ? this.plugin.store.data.collections[cursor.parentId] : void 0;
    }
    const crumb = (name, id) => {
      const button = breadcrumb.createEl("button", { text: name });
      button.addEventListener("click", () => {
        workspace.sideLayout.focusedCollectionId = id;
        workspace.sideLayout.selectedCollectionId = id;
        this.plugin.store.changed();
      });
    };
    crumb(workspace.name, null);
    for (const entry of path) {
      breadcrumb.createSpan({ text: "\u203A" });
      crumb(entry.name, entry.id);
    }
    this.outlineRows = [];
    const rootRow = parent.createDiv({ cls: `cp-outline-root${workspace.sideLayout.selectedCollectionId === null ? " is-selected" : ""}`, text: workspace.sideLayout.focusedCollectionId ? "Current collection" : workspace.name });
    rootRow.addEventListener("click", () => {
      workspace.sideLayout.selectedCollectionId = workspace.sideLayout.focusedCollectionId;
      this.plugin.store.changed();
    });
    this.mountOutlineDropTarget(rootRow, workspaceId, null);
    const focused = workspace.sideLayout.focusedCollectionId ? this.plugin.store.data.collections[workspace.sideLayout.focusedCollectionId] : null;
    const collectionIds = (_a = focused == null ? void 0 : focused.childCollectionIds) != null ? _a : workspace.rootCollectionIds;
    const itemIds = (_b = focused == null ? void 0 : focused.itemIds) != null ? _b : workspace.looseItemIds;
    for (const id of collectionIds) this.renderCollection(parent, this.plugin.store.data.collections[id], 0);
    for (const item of itemIds.map((id) => this.plugin.store.data.items[id]).filter((item2) => Boolean(item2))) this.renderOutlineItem(parent, item, 0, (_c = focused == null ? void 0 : focused.id) != null ? _c : null);
  }
  openLinkedSpaces(workspaceId) {
    new LinkedSpacesModal(this.app, this.items(workspaceId), this.query, (token) => this.plugin.search.hasToken(this.query, token), (token) => {
      this.query = this.plugin.search.setFacet(this.query, "space", token);
      this.render();
    }, (itemIds, path) => this.plugin.store.unlinkItemsFromCanvas(itemIds, path)).open();
  }
  renderCollection(parent, collection, depth) {
    if (!collection) return;
    const target = { kind: "collection", id: collection.id };
    this.outlineRows.push(target);
    const layout = this.plugin.store.data.workspaces[collection.workspaceId].sideLayout;
    const collapsed = layout.collapsedCollectionIds.includes(collection.id);
    const row = parent.createDiv({ cls: `cp-outline-row${this.outlineTargetSelected(target) ? " is-selected" : ""}${layout.focusedCollectionId === collection.id ? " is-current" : ""}`, attr: { style: `--cp-depth:${depth}`, title: "\uD55C \uBC88 \uD074\uB9AD: \uC120\uD0DD \xB7 Ctrl: \uCD94\uAC00/\uD574\uC81C \xB7 Shift: \uBCF4\uC774\uB294 \uD589 \uBC94\uC704 \xB7 \uBE60\uB978 \uB354\uBE14\uD074\uB9AD: \uB0B4\uBD80 \uC9C4\uC785" } });
    row.dataset.collectionId = collection.id;
    row.draggable = true;
    const arrow = row.createEl("button", { cls: "cp-outline-arrow", attr: { "aria-label": collapsed ? "Expand" : "Collapse" } });
    (0, import_obsidian14.setIcon)(arrow, collapsed ? "chevron-right" : "chevron-down");
    arrow.addEventListener("click", (event) => {
      event.stopPropagation();
      layout.collapsedCollectionIds = collapsed ? layout.collapsedCollectionIds.filter((id) => id !== collection.id) : [...layout.collapsedCollectionIds, collection.id];
      this.plugin.store.changed();
    });
    row.createSpan({ cls: "cp-outline-row__title", text: collection.name });
    row.addEventListener("click", (event) => {
      var _a;
      if (event.target.closest("button")) return;
      const now = performance.now();
      const entersCollection = ((_a = this.lastCollectionClick) == null ? void 0 : _a.id) === collection.id && now - this.lastCollectionClick.at <= 220;
      this.selectOutlineTarget(target, event);
      if (entersCollection) {
        layout.focusedCollectionId = collection.id;
        layout.selectedCollectionId = collection.id;
        this.lastCollectionClick = null;
      } else this.lastCollectionClick = { id: collection.id, at: now };
      this.plugin.store.changed();
    });
    row.addEventListener("dragstart", (event) => {
      var _a;
      (_a = event.dataTransfer) == null ? void 0 : _a.setData("application/x-canvas-palette-collection", collection.id);
      if (event.dataTransfer) event.dataTransfer.effectAllowed = "move";
      row.addClass("is-dragging");
    });
    row.addEventListener("dragend", () => row.removeClass("is-dragging"));
    row.addEventListener("contextmenu", (event) => {
      event.preventDefault();
      if (!this.outlineTargetSelected(target)) this.selectOutlineTarget(target);
      const menu = new import_obsidian14.Menu();
      menu.addItem((entry) => entry.setTitle("Export selection as MindMap to Canvas").setIcon("git-branch").onClick(() => void this.plugin.exportOutlineSelectionAsMindMap(this.outlineSelection)));
      menu.addItem((entry) => entry.setTitle("Export collection to Canvas").setIcon("file-output").onClick(() => void this.plugin.exportCollectionSubtree(collection.id)));
      menu.showAtMouseEvent(event);
    });
    this.mountOutlineDropTarget(row, collection.workspaceId, collection.id);
    iconButton(row, "plus", "Add nested collection", () => this.promptCollection(collection.workspaceId, collection.id));
    iconButton(row, "pencil", "Rename collection", () => new TextPromptModal(this.app, "Rename collection", collection.name, (value) => this.plugin.store.renameCollection(collection.id, value)).open());
    iconButton(row, "trash-2", "Delete collection", () => {
      var _a, _b, _c;
      const parentCollection = collection.parentId ? this.plugin.store.data.collections[collection.parentId] : null;
      const destination = (_c = (_b = parentCollection == null ? void 0 : parentCollection.name) != null ? _b : (_a = this.plugin.store.data.workspaces[collection.workspaceId]) == null ? void 0 : _a.name) != null ? _c : "the Workspace";
      new ConfirmDeleteCollectionModal(this.app, collection.name, destination, collection.itemIds.length, collection.childCollectionIds.length, () => {
        this.outlineSelection = this.outlineSelection.filter((entry) => entry.kind !== "collection" || entry.id !== collection.id);
        this.plugin.store.removeCollection(collection.id);
      }).open();
    });
    if (!collapsed) {
      for (const itemId of collection.itemIds) {
        const item = this.plugin.store.data.items[itemId];
        if (item) this.renderOutlineItem(parent, item, depth + 1, collection.id);
      }
      for (const child of collection.childCollectionIds) this.renderCollection(parent, this.plugin.store.data.collections[child], depth + 1);
    }
  }
  renderOutlineItem(parent, item, depth, collectionId) {
    var _a, _b, _c, _d;
    const target = { kind: "item", id: item.id };
    this.outlineRows.push(target);
    const selected = this.outlineTargetSelected(target);
    const showMarker = selected && this.outlineSelection.length > 1;
    const row = parent.createDiv({ cls: `cp-outline-item cp-outline-item--${item.type}${selected ? " is-selected" : ""}${this.query && this.plugin.search.matches(item, this.query) ? " is-match" : ""}`, attr: { style: `--cp-depth:${depth}` } });
    row.dataset.itemId = item.id;
    row.draggable = true;
    const children = (_a = item.childItemIds) != null ? _a : [];
    const layout = (_b = this.plugin.activeWorkspace()) == null ? void 0 : _b.sideLayout;
    const collapsed = (_c = layout == null ? void 0 : layout.collapsedItemIds.includes(item.id)) != null ? _c : false;
    if (children.length > 0) {
      const arrow = row.createEl("button", { cls: "cp-outline-arrow", attr: { "aria-label": collapsed ? "Expand file children" : "Collapse file children" } });
      (0, import_obsidian14.setIcon)(arrow, collapsed ? "chevron-right" : "chevron-down");
      arrow.addEventListener("click", (event) => {
        event.stopPropagation();
        if (!layout) return;
        layout.collapsedItemIds = collapsed ? layout.collapsedItemIds.filter((id) => id !== item.id) : [...layout.collapsedItemIds, item.id];
        this.plugin.store.changed();
      });
    } else row.createSpan({ cls: "cp-outline-arrow cp-outline-arrow--empty" });
    const icon = row.createSpan({ cls: "cp-outline-item__icon" });
    (0, import_obsidian14.setIcon)(icon, item.type === "image" ? "image" : item.type === "markdown" ? "file-text" : item.type === "group" ? "group" : "sticky-note");
    if (showMarker) row.createSpan({ cls: "cp-outline-item__check", text: "\u2713" });
    row.createSpan({ cls: "cp-outline-item__title", text: item.displayTitle });
    const metadata = row.createSpan({ cls: "cp-outline-item__metadata" });
    for (const tag of item.tags) metadata.createSpan({ cls: "cp-outline-item__tag", text: `#${tag}` });
    if (item.label) {
      const label = metadata.createSpan({ cls: "cp-outline-item__label", text: item.label });
      if (item.labelColor) label.style.setProperty("--cp-label-color", item.labelColor);
    }
    let clickTimer = null;
    row.addEventListener("click", (event) => {
      if (clickTimer !== null) window.clearTimeout(clickTimer);
      clickTimer = window.setTimeout(() => {
        clickTimer = null;
        this.pendingReveal = "viewport";
        this.selectOutlineTarget(target, event);
      }, 220);
    });
    row.addEventListener("dblclick", () => {
      if (clickTimer !== null) window.clearTimeout(clickTimer);
      clickTimer = null;
      void this.plugin.openSideItemPreview(item.id);
    });
    row.addEventListener("contextmenu", (event) => {
      if (!this.outlineTargetSelected(target)) this.selectOutlineTarget(target);
      this.itemMenu(event, item, true);
    });
    row.addEventListener("dragstart", (event) => {
      var _a2, _b2;
      const selectedIds = this.sideSelectedIds();
      (_a2 = event.dataTransfer) == null ? void 0 : _a2.setData("application/x-canvas-palette-item", item.id);
      (_b2 = event.dataTransfer) == null ? void 0 : _b2.setData("application/x-canvas-palette-items", JSON.stringify(selectedIds.includes(item.id) ? selectedIds : [item.id]));
      if (event.dataTransfer) event.dataTransfer.effectAllowed = "copyMove";
      row.addClass("is-dragging");
    });
    row.addEventListener("dragend", () => row.removeClass("is-dragging"));
    this.mountOutlineItemDropTarget(row, item.id, collectionId, (_d = item.parentItemId) != null ? _d : null);
    if (!collapsed) for (const childId of children) {
      const child = this.plugin.store.data.items[childId];
      if (child) this.renderOutlineItem(parent, child, depth + 1, collectionId);
    }
  }
  mountOutlineItemDropTarget(row, targetId, collectionId, parentItemId) {
    let zone = "inside";
    const clear = () => row.removeClass("is-drop-before", "is-drop-inside", "is-drop-after");
    row.addEventListener("dragover", (event) => {
      var _a;
      if (!((_a = event.dataTransfer) == null ? void 0 : _a.types.includes("application/x-canvas-palette-item"))) return;
      event.preventDefault();
      event.stopPropagation();
      const ratio = (event.clientY - row.getBoundingClientRect().top) / row.getBoundingClientRect().height;
      zone = ratio < 0.25 ? "before" : ratio > 0.75 ? "after" : "inside";
      clear();
      row.addClass(`is-drop-${zone}`);
    });
    row.addEventListener("dragleave", clear);
    row.addEventListener("drop", (event) => {
      var _a;
      const source = (_a = event.dataTransfer) == null ? void 0 : _a.getData("application/x-canvas-palette-item");
      const workspace = this.plugin.activeWorkspace();
      if (!source || !workspace) return;
      event.preventDefault();
      event.stopPropagation();
      clear();
      const selected = this.sideSelectedIds();
      const moving = selected.includes(source) ? selected : [source];
      if (zone === "inside") this.plugin.store.moveItems(workspace.id, moving, collectionId, null, false, targetId);
      else this.plugin.store.moveItems(workspace.id, moving, collectionId, targetId, zone === "after", parentItemId);
    });
  }
  mountOutlineDropTarget(row, workspaceId, collectionId) {
    const accepts = (event) => {
      var _a, _b;
      return Boolean(((_a = event.dataTransfer) == null ? void 0 : _a.types.includes("application/x-canvas-palette-item")) || ((_b = event.dataTransfer) == null ? void 0 : _b.types.includes("application/x-canvas-palette-collection")));
    };
    row.addEventListener("dragover", (event) => {
      if (!accepts(event)) return;
      event.preventDefault();
      event.stopPropagation();
      row.addClass("is-drop-target");
      if (event.dataTransfer) event.dataTransfer.dropEffect = "move";
    });
    row.addEventListener("dragleave", (event) => {
      if (!(event.relatedTarget instanceof Node) || !row.contains(event.relatedTarget)) row.removeClass("is-drop-target");
    });
    row.addEventListener("drop", (event) => {
      var _a, _b;
      if (!accepts(event)) return;
      event.preventDefault();
      event.stopPropagation();
      row.removeClass("is-drop-target");
      const itemId = (_a = event.dataTransfer) == null ? void 0 : _a.getData("application/x-canvas-palette-item");
      if (itemId) {
        const selected = this.sideSelectedIds();
        this.plugin.store.moveItems(workspaceId, selected.includes(itemId) ? selected : [itemId], collectionId);
        return;
      }
      const draggedCollectionId = (_b = event.dataTransfer) == null ? void 0 : _b.getData("application/x-canvas-palette-collection");
      if (draggedCollectionId) this.plugin.store.moveCollection(draggedCollectionId, collectionId);
    });
  }
  renderIndex(parent, title, values, kind, showTitle = true) {
    var _a;
    if (showTitle) parent.createEl("h4", { text: title });
    const counts = /* @__PURE__ */ new Map();
    for (const value of values) counts.set(value, ((_a = counts.get(value)) != null ? _a : 0) + 1);
    for (const [value, count] of [...counts].sort((a, b) => b[1] - a[1])) {
      const token = kind === "tag" ? `#${value}` : `label:"${value.replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`;
      const row = parent.createDiv({ cls: "cp-index-row" });
      const chip = row.createEl("button", { cls: `cp-chip cp-index-filter${this.plugin.search.hasToken(this.query, token) ? " is-active" : ""}`, text: kind === "tag" ? `#${value}` : value, attr: { "aria-pressed": String(this.plugin.search.hasToken(this.query, token)) } });
      chip.addEventListener("click", () => {
        this.query = this.plugin.search.toggleToken(this.query, token);
        this.render();
        requestAnimationFrame(() => {
          var _a2;
          return (_a2 = this.contentEl.querySelector(".cp-search")) == null ? void 0 : _a2.focus();
        });
      });
      row.createSpan({ text: String(count) });
    }
  }
  items(workspaceId) {
    return this.plugin.store.itemsForWorkspace(workspaceId);
  }
  itemsForViewportScope(workspaceId) {
    const workspace = this.plugin.store.data.workspaces[workspaceId];
    if (!workspace) return [];
    const focusedId = workspace.sideLayout.focusedCollectionId;
    if (!focusedId) return this.items(workspaceId);
    const ids = [];
    const collect = (id) => {
      const collection = this.plugin.store.data.collections[id];
      if (!collection) return;
      ids.push(...collection.itemIds);
      if (workspace.sideLayout.outlinerIncludeDescendants) for (const child of collection.childCollectionIds) collect(child);
    };
    collect(focusedId);
    return ids.map((id) => this.plugin.store.data.items[id]).filter((item) => Boolean(item));
  }
  applyLayoutVariables(root, layout) {
    root.style.setProperty("--cp-side-upper-left", `${layout.viewportRatio}fr`);
    root.style.setProperty("--cp-side-upper-right", `${1 - layout.viewportRatio}fr`);
    root.style.setProperty("--cp-side-upper", `${layout.topRatio}fr`);
    root.style.setProperty("--cp-side-lower", `${1 - layout.topRatio}fr`);
    root.style.setProperty("--cp-side-lower-left", `${layout.indexRatio}fr`);
    root.style.setProperty("--cp-side-lower-right", `${1 - layout.indexRatio}fr`);
  }
  horizontalRatio(container, divider, clientX, leftMinimum, rightMinimum) {
    const rect = container.getBoundingClientRect();
    const dividerWidth = divider.getBoundingClientRect().width;
    const available = Math.max(1, rect.width - dividerWidth);
    const minLeft = Math.min(leftMinimum, available * 0.4);
    const minRight = Math.min(rightMinimum, available * 0.4);
    const left = this.clamp(clientX - rect.left - dividerWidth / 2, minLeft, available - minRight);
    return left / available;
  }
  verticalRatio(upper, lower, divider, clientY) {
    const upperRect = upper.getBoundingClientRect();
    const available = Math.max(1, upperRect.height + lower.getBoundingClientRect().height);
    const dividerHeight = divider.getBoundingClientRect().height;
    const minUpper = Math.min(230, available * 0.65);
    const minLower = Math.min(110, available * 0.3);
    const upperHeight = this.clamp(clientY - upperRect.top - dividerHeight / 2, minUpper, available - minLower);
    return upperHeight / available;
  }
  clamp(value, minimum, maximum) {
    return Math.max(minimum, Math.min(maximum, value));
  }
  setSideView(viewMode) {
    const workspace = this.plugin.activeWorkspace();
    if (!workspace) return;
    workspace.sideLayout.viewMode = viewMode;
    workspace.sideLayout.densityLevel = viewMode === "list" ? 0 : Math.max(1, workspace.sideLayout.densityLevel || ASSET_DENSITY_DEFAULT);
    this.plugin.store.changed();
  }
  promptCollection(workspaceId, parentId) {
    new TextPromptModal(this.app, "New collection", "", (value) => this.plugin.store.createCollection(workspaceId, value, parentId), "Collection name").open();
  }
  itemMenu(event, item, fromOutliner = false) {
    event.preventDefault();
    const menu = new import_obsidian14.Menu();
    const workspace = this.plugin.activeWorkspace();
    const selected = this.sideSelectedIds();
    const targetIds = selected.includes(item.id) ? selected : [item.id];
    if (!selected.includes(item.id)) this.selectSideItem(item.id);
    if (workspace && targetIds.length > 1) menu.addItem((entry) => entry.setTitle("Group selected items\u2026").setIcon("folder-plus").onClick(() => {
      const owningCollection = Object.values(this.plugin.store.data.collections).find((candidate) => candidate.workspaceId === workspace.id && candidate.itemIds.includes(item.id));
      new TextPromptModal(this.app, "New group", "", (value) => {
        var _a;
        const group = this.plugin.store.createCollection(workspace.id, value, (_a = owningCollection == null ? void 0 : owningCollection.id) != null ? _a : null);
        this.plugin.store.moveItems(workspace.id, targetIds, group.id);
      }, "Group name").open();
    }));
    menu.addItem((entry) => entry.setTitle("Edit tags, label & caption").setIcon("tags").onClick(() => new TagLabelModal(this.app, this.plugin, targetIds).open()));
    if (item.type === "image" || item.type === "markdown" || item.type === "group") menu.addItem((entry) => entry.setTitle("Rename linked item").setIcon("pencil").onClick(() => new TextPromptModal(this.app, "Rename linked item", item.displayTitle, (value) => this.plugin.renameLinkedItem(item.id, value), "Linked item name").open()));
    if (item.type === "card") menu.addItem((entry) => entry.setTitle("Convert to shared Markdown\u2026").setIcon("file-output").onClick(() => {
      var _a, _b, _c;
      const fileName = `${item.displayTitle.replace(/[\\/:*?"<>|]/g, " ").trim() || "Card"}.md`;
      const folder = (_c = (_b = (_a = this.app.workspace.getActiveFile()) == null ? void 0 : _a.parent) == null ? void 0 : _b.path) != null ? _c : "";
      new CardToMarkdownModal(this.app, fileName, folder, (name, targetFolder) => this.plugin.convertCardToMarkdown(item.id, name, targetFolder)).open();
    }));
    if (supportsFrontBack(item)) {
      menu.addItem((entry) => entry.setTitle(item.facesEnabled ? "Remove Front / Back" : "Enable Front / Back").setIcon(item.facesEnabled ? "circle-off" : "refresh-cw").onClick(() => item.facesEnabled ? this.plugin.store.disableItemFaces(item.id) : this.plugin.store.enableItemFaces(item.id)));
    }
    const allInMini = targetIds.every((id) => this.plugin.store.miniStorageHas(id));
    menu.addItem((entry) => entry.setTitle(allInMini ? "Remove from Mini Palette" : "Export to Mini Palette").setIcon(allInMini ? "unlink" : "send").setChecked(allInMini).onClick(() => allInMini ? this.plugin.store.removeMiniStorageItems(targetIds) : this.plugin.sendItemsToMini(targetIds)));
    menu.addItem((entry) => entry.setTitle(`Export ${targetIds.length} item${targetIds.length === 1 ? "" : "s"} to Canvas`).setIcon("share-2").onClick(() => void this.plugin.exportItemsToActiveCanvas(targetIds)));
    menu.addItem((entry) => entry.setTitle(fromOutliner ? "Export selection as MindMap to Canvas" : "Export from MindMap to Canvas").setIcon("git-branch").onClick(() => fromOutliner ? void this.plugin.exportOutlineSelectionAsMindMap(this.outlineSelection) : void this.plugin.exportItemsAsMindMap(targetIds)));
    if (workspace) menu.addItem((entry) => entry.setTitle("Move to\u2026").setIcon("folder-input").onClick(() => new MoveItemsModal(this.app, workspace.name, Object.values(this.plugin.store.data.collections).filter((candidate) => candidate.workspaceId === workspace.id), targetIds.length, (collectionId) => this.plugin.store.assignItemsToCollection(workspace.id, targetIds, collectionId)).open()));
    const linkedLocations = this.plugin.store.linkedCanvasLocations(item);
    if (linkedLocations.length > 0) menu.addItem((entry) => entry.setTitle("Locate on Canvas").setIcon("locate-fixed").onClick(() => this.plugin.findLinkedCanvas(item)));
    else if (item.origin.filePath) menu.addItem((entry) => entry.setTitle("Open source file").setIcon("external-link").onClick(() => void this.plugin.openOriginal(item)));
    menu.addSeparator();
    menu.addItem((entry) => entry.setTitle(`Delete${targetIds.length > 1 ? ` ${targetIds.length} items` : ""}`).setIcon("trash").onClick(() => this.confirmDelete(targetIds)));
    menu.showAtMouseEvent(event);
  }
  sideSelectedIds() {
    return this.plugin.store.data.uiState.sideSelectedItemIds;
  }
  outlineKey(target) {
    return `${target.kind}:${target.id}`;
  }
  outlineTargetSelected(target) {
    return this.outlineSelection.some((entry) => this.outlineKey(entry) === this.outlineKey(target));
  }
  selectOutlineTarget(target, event) {
    var _a;
    const targetKey = this.outlineKey(target);
    const toggle = Boolean((event == null ? void 0 : event.ctrlKey) || (event == null ? void 0 : event.metaKey));
    if ((event == null ? void 0 : event.shiftKey) && this.outlineSelectionAnchorKey) {
      const start = this.outlineRows.findIndex((entry) => this.outlineKey(entry) === this.outlineSelectionAnchorKey);
      const end = this.outlineRows.findIndex((entry) => this.outlineKey(entry) === targetKey);
      this.outlineSelection = start >= 0 && end >= 0 ? this.outlineRows.slice(Math.min(start, end), Math.max(start, end) + 1) : [target];
    } else if (toggle) {
      this.outlineSelection = this.outlineTargetSelected(target) ? this.outlineSelection.filter((entry) => this.outlineKey(entry) !== targetKey) : [...this.outlineSelection, target];
      this.outlineSelectionAnchorKey = targetKey;
    } else {
      this.outlineSelection = [target];
      this.outlineSelectionAnchorKey = targetKey;
    }
    const itemIds = this.outlineSelection.filter((entry) => entry.kind === "item").map((entry) => entry.id);
    this.plugin.store.data.uiState.sideSelectedItemIds = itemIds;
    this.plugin.store.data.uiState.selectedItemId = (_a = itemIds.at(-1)) != null ? _a : null;
    this.plugin.store.changed();
  }
  selectSideItem(id, event, orderedItemIds = this.visibleItemIds) {
    var _a;
    const selected = this.sideSelectedIds();
    const toggle = Boolean((event == null ? void 0 : event.ctrlKey) || (event == null ? void 0 : event.metaKey));
    let next;
    if ((event == null ? void 0 : event.shiftKey) && this.selectionAnchorId) {
      const anchorIndex = orderedItemIds.indexOf(this.selectionAnchorId);
      const targetIndex = orderedItemIds.indexOf(id);
      const range = anchorIndex >= 0 && targetIndex >= 0 ? orderedItemIds.slice(Math.min(anchorIndex, targetIndex), Math.max(anchorIndex, targetIndex) + 1) : [id];
      next = toggle ? [.../* @__PURE__ */ new Set([...selected, ...range])] : range;
    } else if (toggle) {
      next = selected.includes(id) ? selected.filter((value) => value !== id) : [...selected, id];
      this.selectionAnchorId = id;
    } else {
      next = [id];
      this.selectionAnchorId = id;
    }
    this.plugin.store.data.uiState.sideSelectedItemIds = next;
    this.plugin.store.data.uiState.selectedItemId = next.includes(id) ? id : (_a = next.at(-1)) != null ? _a : null;
    this.outlineSelection = next.map((itemId) => ({ kind: "item", id: itemId }));
    this.outlineSelectionAnchorKey = this.selectionAnchorId ? `item:${this.selectionAnchorId}` : null;
    this.plugin.store.changed();
  }
  clearSideSelection() {
    if (this.sideSelectedIds().length === 0) return;
    this.selectionAnchorId = null;
    this.outlineSelection = [];
    this.outlineSelectionAnchorKey = null;
    this.plugin.store.data.uiState.sideSelectedItemIds = [];
    this.plugin.store.data.uiState.selectedItemId = null;
    this.plugin.store.changed();
  }
  mountViewportReorder(viewport, listEl, workspaceId) {
    const overlay = document.createElement("div");
    overlay.className = "cp-drop-overlay";
    let cards = [];
    let point = null;
    let frame = 0;
    let targetId = null;
    let insertAfter = false;
    const hide = () => {
      overlay.remove();
      targetId = null;
    };
    const measure = () => {
      cards = Array.from(listEl.querySelectorAll(".cp-item:not(.is-dragging)")).flatMap((card) => card.dataset.itemId ? [{ id: card.dataset.itemId, rect: card.getBoundingClientRect() }] : []);
    };
    const draw = () => {
      frame = 0;
      if (!point) return;
      if (cards.length === 0) measure();
      const visible = cards.filter(({ rect }) => rect.bottom >= viewport.getBoundingClientRect().top && rect.top <= viewport.getBoundingClientRect().bottom);
      const nearest = visible.reduce((best, card) => {
        const dx = point.x - (card.rect.left + card.rect.width / 2);
        const dy = point.y - (card.rect.top + card.rect.height / 2);
        const distance = dx * dx + dy * dy;
        return !best || distance < best.distance ? { ...card, distance } : best;
      }, null);
      if (!nearest) {
        hide();
        return;
      }
      const multiColumn = cards.some((card, index) => index > 0 && Math.abs(card.rect.top - cards[index - 1].rect.top) < 6);
      insertAfter = multiColumn ? point.x > nearest.rect.left + nearest.rect.width / 2 : point.y > nearest.rect.top + nearest.rect.height / 2;
      targetId = nearest.id;
      const style = multiColumn ? { left: `${insertAfter ? nearest.rect.right + 2 : nearest.rect.left - 6}px`, top: `${nearest.rect.top}px`, width: "4px", height: `${nearest.rect.height}px` } : { left: `${nearest.rect.left}px`, top: `${insertAfter ? nearest.rect.bottom + 2 : nearest.rect.top - 6}px`, width: `${nearest.rect.width}px`, height: "4px" };
      Object.assign(overlay.style, style);
      if (!overlay.isConnected) document.body.appendChild(overlay);
    };
    const schedule = () => {
      if (!frame) frame = requestAnimationFrame(draw);
    };
    const clear = () => {
      if (frame) cancelAnimationFrame(frame);
      frame = 0;
      point = null;
      cards = [];
      hide();
      window.removeEventListener("keydown", onKeyDown, true);
    };
    const onKeyDown = (event) => {
      if (event.key === "Escape") clear();
    };
    listEl.addEventListener("dragstart", () => {
      cards = [];
      window.addEventListener("keydown", onKeyDown, true);
    });
    listEl.addEventListener("dragover", (event) => {
      var _a;
      if (!((_a = event.dataTransfer) == null ? void 0 : _a.types.includes("application/x-canvas-palette-item"))) return;
      event.preventDefault();
      point = { x: event.clientX, y: event.clientY };
      schedule();
    });
    listEl.addEventListener("dragleave", (event) => {
      if (!(event.relatedTarget instanceof Node) || !listEl.contains(event.relatedTarget)) hide();
    });
    listEl.addEventListener("dragend", clear);
    listEl.addEventListener("drop", (event) => {
      var _a;
      const sourceId = (_a = event.dataTransfer) == null ? void 0 : _a.getData("application/x-canvas-palette-item");
      if (sourceId && targetId) {
        event.preventDefault();
        const id = targetId;
        const after = insertAfter;
        clear();
        this.plugin.store.reorderItems(workspaceId, sourceId, id, after);
      } else clear();
    });
    viewport.addEventListener("scroll", () => {
      cards = [];
      if (point) schedule();
    }, { passive: true });
  }
  mountViewportSelection(viewport, listEl) {
    viewport.addEventListener("click", (event) => {
      if (this.suppressBlankClick) {
        this.suppressBlankClick = false;
        return;
      }
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;
      if (target.closest(".cp-item,button,input,select,textarea,summary,a,.cp-view-options")) return;
      if (target === viewport) {
        const rect = viewport.getBoundingClientRect();
        if (event.clientX >= rect.left + viewport.clientWidth) return;
      }
      this.clearSideSelection();
    });
    listEl.addEventListener("pointerdown", (event) => {
      if (event.button !== 0 || event.target !== listEl) return;
      event.preventDefault();
      const start = { x: event.clientX, y: event.clientY };
      const baseSelection = event.ctrlKey || event.metaKey ? new Set(this.sideSelectedIds()) : /* @__PURE__ */ new Set();
      const rectangle = document.createElement("div");
      rectangle.className = "cp-selection-rectangle";
      document.body.appendChild(rectangle);
      let dragged = false;
      let lastHits = [];
      const move = (pointer) => {
        var _a;
        if (Math.hypot(pointer.clientX - start.x, pointer.clientY - start.y) < 4 && !dragged) return;
        dragged = true;
        const left = Math.min(start.x, pointer.clientX);
        const top = Math.min(start.y, pointer.clientY);
        const right = Math.max(start.x, pointer.clientX);
        const bottom = Math.max(start.y, pointer.clientY);
        Object.assign(rectangle.style, { display: "block", left: `${left}px`, top: `${top}px`, width: `${right - left}px`, height: `${bottom - top}px` });
        lastHits = [];
        for (const card of Array.from(listEl.querySelectorAll(".cp-item"))) {
          const rect = card.getBoundingClientRect();
          const hit = rect.right >= left && rect.left <= right && rect.bottom >= top && rect.top <= bottom;
          card.toggleClass("is-selected", hit || baseSelection.has((_a = card.dataset.itemId) != null ? _a : ""));
          if (hit && card.dataset.itemId) lastHits.push(card.dataset.itemId);
        }
      };
      const finish = () => {
        var _a, _b;
        window.removeEventListener("pointermove", move, true);
        window.removeEventListener("pointerup", finish, true);
        window.removeEventListener("pointercancel", finish, true);
        rectangle.remove();
        this.suppressBlankClick = true;
        window.setTimeout(() => {
          this.suppressBlankClick = false;
        }, 0);
        if (!dragged) {
          this.clearSideSelection();
          return;
        }
        const next = [.../* @__PURE__ */ new Set([...baseSelection, ...lastHits])];
        this.plugin.store.data.uiState.sideSelectedItemIds = next;
        this.plugin.store.data.uiState.selectedItemId = (_a = next.at(-1)) != null ? _a : null;
        this.selectionAnchorId = (_b = next.at(-1)) != null ? _b : null;
        this.plugin.store.changed();
      };
      window.addEventListener("pointermove", move, true);
      window.addEventListener("pointerup", finish, true);
      window.addEventListener("pointercancel", finish, true);
    });
  }
  confirmDelete(ids) {
    if (ids.length > 0) new ConfirmDeleteModal(this.app, ids.length, () => this.plugin.store.removeItems(ids)).open();
  }
};

// src/ui/item-preview-modal.ts
var import_obsidian15 = require("obsidian");
var ItemPreviewModal = class extends import_obsidian15.Modal {
  constructor(app, plugin, itemId) {
    super(app);
    this.plugin = plugin;
    this.itemId = itemId;
    __publicField(this, "previewClosed", false);
    __publicField(this, "imageResizeObserver");
  }
  onOpen() {
    const item = this.plugin.store.data.items[this.itemId];
    if (!item) {
      this.close();
      return;
    }
    this.modalEl.addClass("canvas-palette", "cp-preview-modal", `cp-preview-modal--${item.type}`);
    this.contentEl.addClass("cp-large-preview");
    const header = this.contentEl.createDiv({ cls: "cp-large-preview__header" });
    header.createEl("h2", { text: item.displayTitle || "Untitled" });
    header.createSpan({ cls: "cp-chip", text: item.type.toUpperCase() });
    const body = this.contentEl.createDiv({ cls: "cp-large-preview__body" });
    if (item.type === "image") void this.renderZoomableImage(body, item, header);
    else if (item.type === "markdown") void this.renderCurrentMarkdown(body, item);
    else void this.plugin.preview.render(body, item, false);
  }
  onClose() {
    var _a;
    this.previewClosed = true;
    (_a = this.imageResizeObserver) == null ? void 0 : _a.disconnect();
    this.contentEl.empty();
  }
  async renderZoomableImage(body, item, header) {
    await this.plugin.preview.render(body, item, false);
    if (this.previewClosed) return;
    const image = body.querySelector("img");
    if (!(image instanceof HTMLImageElement)) return;
    const zoomLabel = header.createSpan({ cls: "cp-image-zoom", text: "100%" });
    const stage = document.createElement("div");
    stage.className = "cp-image-zoom-stage";
    image.replaceWith(stage);
    stage.appendChild(image);
    let zoom = 1;
    const update = () => {
      const naturalWidth = Math.max(image.naturalWidth, 1);
      const naturalHeight = Math.max(image.naturalHeight, 1);
      const availableWidth = Math.max(body.clientWidth - 36, 1);
      const availableHeight = Math.max(body.clientHeight - 36, 1);
      const fit = Math.min(availableWidth / naturalWidth, availableHeight / naturalHeight);
      const width = naturalWidth * fit * zoom;
      const height = naturalHeight * fit * zoom;
      image.style.width = `${width}px`;
      image.style.height = `${height}px`;
      stage.style.width = `${Math.max(availableWidth, width)}px`;
      stage.style.height = `${Math.max(availableHeight, height)}px`;
      zoomLabel.setText(`${Math.round(zoom * 100)}%`);
    };
    const ready = () => update();
    if (image.complete) ready();
    else image.addEventListener("load", ready, { once: true });
    body.addEventListener("wheel", (event) => {
      event.preventDefault();
      zoom = Math.min(5, Math.max(0.2, zoom * (event.deltaY < 0 ? 1.12 : 1 / 1.12)));
      update();
    }, { passive: false });
    this.imageResizeObserver = new ResizeObserver(update);
    this.imageResizeObserver.observe(body);
  }
  async renderCurrentMarkdown(body, item) {
    const file = item.origin.filePath ? this.app.vault.getAbstractFileByPath(item.origin.filePath) : null;
    if (!(file instanceof import_obsidian15.TFile) || file.extension.toLowerCase() !== "md") {
      body.createDiv({ cls: "cp-empty", text: "The original Markdown file is unavailable." });
      return;
    }
    const content = await this.app.vault.cachedRead(file);
    if (this.previewClosed) return;
    await this.plugin.preview.render(body, { ...item, content }, false);
  }
};

// src/ui/find-link-modal.ts
var import_obsidian16 = require("obsidian");
var FindLinkModal = class extends import_obsidian16.Modal {
  constructor(app, itemTitle, locations, onChoose) {
    super(app);
    this.itemTitle = itemTitle;
    this.locations = locations;
    this.onChoose = onChoose;
  }
  onOpen() {
    this.modalEl.addClass("cp-find-link-shell");
    this.contentEl.addClass("canvas-palette", "cp-find-link-modal");
    this.contentEl.createEl("h2", { text: "Find link" });
    this.contentEl.createEl("p", { cls: "cp-find-link-description", text: `Choose a linked Canvas location for ${this.itemTitle}.` });
    const list = this.contentEl.createDiv({ cls: "cp-find-link-list" });
    for (const location of this.locations) {
      const name = canvasName2(location.canvasPath);
      const row = list.createEl("button", {
        cls: "cp-find-link-row",
        attr: { type: "button", "aria-label": `Open ${name}`, title: location.canvasPath }
      });
      const icon = row.createSpan({ cls: "cp-find-link-row__icon" });
      (0, import_obsidian16.setIcon)(icon, "layout-dashboard");
      const info = row.createSpan({ cls: "cp-find-link-row__info" });
      info.createEl("strong", { text: name });
      info.createSpan({ cls: "cp-find-link-row__path", text: location.canvasPath });
      info.createSpan({ cls: "cp-find-link-row__node", text: `Node ${location.nodeId}` });
      row.addEventListener("click", () => {
        this.onChoose(location);
        this.close();
      });
    }
  }
  onClose() {
    this.contentEl.empty();
  }
};
function canvasName2(path) {
  var _a, _b;
  return (_b = (_a = path.split("/").pop()) == null ? void 0 : _a.replace(/\.canvas$/i, "")) != null ? _b : path;
}

// src/ui/workspace-explorer-modal.ts
var import_obsidian17 = require("obsidian");
var WorkspaceExplorerModal = class extends import_obsidian17.Modal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin;
    __publicField(this, "query", "");
    __publicField(this, "filter", "all");
    __publicField(this, "date", "");
    __publicField(this, "unsubscribe");
  }
  onOpen() {
    this.modalEl.addClass("cp-workspace-explorer-shell");
    this.unsubscribe = this.plugin.store.subscribe(() => this.render());
    this.render();
  }
  onClose() {
    var _a;
    (_a = this.unsubscribe) == null ? void 0 : _a.call(this);
    this.contentEl.empty();
  }
  render() {
    const activeElement = document.activeElement;
    const restoreSearch = activeElement instanceof HTMLInputElement && activeElement.hasClass("cp-workspace-explorer__search");
    const cursor = restoreSearch ? activeElement.selectionStart : null;
    this.contentEl.empty();
    this.contentEl.addClass("canvas-palette", "cp-workspace-explorer");
    const title = this.contentEl.createDiv({ cls: "cp-workspace-explorer__title" });
    title.createEl("h2", { text: "Workspace Explorer" });
    title.createSpan({ text: "Find and manage Workspaces like files." });
    const toolbar = this.contentEl.createDiv({ cls: "cp-workspace-explorer__toolbar" });
    const search = toolbar.createEl("input", { cls: "cp-workspace-explorer__search", value: this.query, attr: { type: "search", placeholder: "Search Canvas or Workspace\u2026", autocomplete: "off" } });
    search.addEventListener("input", () => {
      this.query = search.value.normalize("NFC");
      this.render();
    });
    if (restoreSearch) window.requestAnimationFrame(() => {
      search.focus();
      search.setSelectionRange(cursor, cursor);
    });
    const controls = toolbar.createDiv({ cls: "cp-workspace-explorer__controls" });
    for (const [value, label] of [["all", "All"], ["canvas", "Canvas"], ["general", "General"]]) {
      const button = controls.createEl("button", { text: label, cls: this.filter === value ? "is-active" : "" });
      button.addEventListener("click", () => {
        this.filter = value;
        this.render();
      });
    }
    const sort = controls.createEl("select", { attr: { "aria-label": "Sort Workspaces" } });
    for (const [value, label] of [["modified-desc", "Modified: newest"], ["modified-asc", "Modified: oldest"], ["created-desc", "Created: newest"], ["created-asc", "Created: oldest"], ["name-asc", "Name: A\u2013Z"], ["name-desc", "Name: Z\u2013A"]]) {
      const option = sort.createEl("option", { value, text: label });
      option.selected = this.viewState().sort === value;
    }
    sort.addEventListener("change", () => {
      this.viewState().sort = sort.value;
      this.plugin.store.changed();
    });
    const date = controls.createEl("input", { cls: "cp-workspace-explorer__date", value: this.date, attr: { type: "date", title: "Filter by modified date", "aria-label": "Filter by modified date" } });
    date.addEventListener("change", () => {
      this.date = date.value;
      this.render();
    });
    if (this.date) {
      const clearDate = controls.createEl("button", { cls: "cp-icon-button", attr: { title: "Clear date", "aria-label": "Clear date" } });
      (0, import_obsidian17.setIcon)(clearDate, "x");
      clearDate.addEventListener("click", () => {
        this.date = "";
        this.render();
      });
    }
    const views = controls.createDiv({ cls: "cp-workspace-explorer__views" });
    for (const [value, icon, label] of [["icons", "grid-2x2", "Icons"], ["list", "list", "List"], ["details", "list-tree", "Details"]]) {
      const button = views.createEl("button", { cls: `cp-icon-button${this.viewState().viewMode === value ? " is-active" : ""}`, attr: { title: `${label} view`, "aria-label": `${label} view` } });
      (0, import_obsidian17.setIcon)(button, icon);
      button.addEventListener("click", () => {
        this.viewState().viewMode = value;
        this.plugin.store.changed();
      });
    }
    const results = this.filteredWorkspaces();
    const currentCanvas = this.plugin.currentCanvasPath();
    const current = currentCanvas ? results.filter((workspace) => workspace.kind === "canvas" && workspace.ownerCanvasPath === currentCanvas) : [];
    const other = results.filter((workspace) => !current.includes(workspace));
    const body = this.contentEl.createDiv({ cls: `cp-workspace-explorer__body is-${this.viewState().viewMode}` });
    if (currentCanvas) this.renderSection(body, `Current Canvas \xB7 ${this.baseName(currentCanvas)}`, current, true);
    this.renderSection(body, currentCanvas ? "Other Workspaces" : "Workspaces", other, false);
    if (results.length === 0) body.createDiv({ cls: "cp-empty", text: "No matching Workspaces." });
    const footer = this.contentEl.createDiv({ cls: "cp-workspace-explorer__footer" });
    const general = footer.createEl("button", { text: "+ New Workspace" });
    general.addEventListener("click", () => new TextPromptModal(this.app, "New general Workspace", "", (name) => {
      const workspace = this.plugin.store.createWorkspace(name, "general");
      this.plugin.store.data.uiState.activeWorkspaceId = workspace.id;
      this.plugin.store.changed();
    }, "Workspace name").open());
    const canvas = footer.createEl("button", { text: "+ Current Canvas Workspace" });
    canvas.disabled = !currentCanvas;
    canvas.addEventListener("click", () => {
      if (!currentCanvas) return;
      const count = this.plugin.store.canvasWorkspaces(currentCanvas).length;
      new TextPromptModal(this.app, "New Canvas Workspace", `${this.baseName(currentCanvas)} ${count + 1}`, (name) => {
        const workspace = this.plugin.store.createWorkspace(name, "canvas", currentCanvas, count === 0);
        this.plugin.store.data.uiState.activeWorkspaceId = workspace.id;
        this.plugin.store.changed();
      }, "Workspace name").open();
    });
  }
  renderSection(parent, title, workspaces, pinned) {
    if (workspaces.length === 0) return;
    const section = parent.createDiv({ cls: "cp-workspace-explorer__section" });
    const heading = section.createDiv({ cls: "cp-workspace-explorer__section-title" });
    if (pinned) (0, import_obsidian17.setIcon)(heading.createSpan(), "pin");
    heading.createSpan({ text: title });
    if (this.viewState().viewMode === "details") {
      const columns = section.createDiv({ cls: "cp-workspace-explorer__columns" });
      columns.createSpan({ text: "Name" });
      columns.createSpan({ text: "Type / Canvas" });
      columns.createSpan({ text: "Modified" });
      columns.createSpan();
    }
    const list = section.createDiv({ cls: "cp-workspace-explorer__list" });
    for (const workspace of workspaces) this.renderWorkspace(list, workspace);
  }
  renderWorkspace(parent, workspace) {
    var _a;
    const active = this.plugin.store.data.uiState.activeWorkspaceId === workspace.id;
    const representative = workspace.kind === "canvas" && workspace.ownerCanvasPath === workspace.representativeCanvasPath;
    const row = parent.createDiv({ cls: `cp-workspace-file${active ? " is-selected" : ""}`, attr: { tabindex: "0", role: "button" } });
    const icon = row.createSpan({ cls: "cp-workspace-file__icon" });
    (0, import_obsidian17.setIcon)(icon, workspace.kind === "canvas" ? "folder-kanban" : "folder");
    const name = row.createDiv({ cls: "cp-workspace-file__name" });
    const label = name.createDiv();
    if (representative) {
      const star = label.createSpan({ cls: "cp-workspace-file__star" });
      (0, import_obsidian17.setIcon)(star, "star");
    }
    label.createSpan({ text: workspace.name });
    if (this.viewState().viewMode === "icons") name.createSpan({ cls: "cp-workspace-file__date", text: this.formatDate(workspace.modifiedAt) });
    const meta = row.createDiv({ cls: "cp-workspace-file__meta" });
    meta.createSpan({ cls: "cp-workspace-file__badge", text: workspace.kind === "canvas" ? representative ? "Representative" : "Canvas" : "General" });
    meta.createSpan({ text: workspace.kind === "canvas" ? this.baseName((_a = workspace.ownerCanvasPath) != null ? _a : "") : "All Canvases" });
    row.createSpan({ cls: "cp-workspace-file__modified", text: this.formatDate(workspace.modifiedAt) });
    const more = row.createEl("button", { cls: "cp-icon-button cp-workspace-file__more", attr: { title: "Workspace actions", "aria-label": "Workspace actions" } });
    (0, import_obsidian17.setIcon)(more, "more-vertical");
    const open = () => {
      this.plugin.store.data.uiState.activeWorkspaceId = workspace.id;
      this.plugin.store.changed();
    };
    row.addEventListener("dblclick", open);
    row.addEventListener("keydown", (event) => {
      if (event.key === "Enter") open();
    });
    more.addEventListener("click", (event) => {
      event.stopPropagation();
      this.showActions(workspace, more);
    });
  }
  showActions(workspace, anchor) {
    const menu = new import_obsidian17.Menu();
    menu.addItem((item) => item.setTitle("Open").setIcon("folder-open").onClick(() => {
      this.plugin.store.data.uiState.activeWorkspaceId = workspace.id;
      this.plugin.store.changed();
    }));
    const canvasPath = this.plugin.currentCanvasPath();
    const canRepresent = Boolean(canvasPath && workspace.kind === "canvas" && workspace.ownerCanvasPath === canvasPath);
    menu.addItem((item) => item.setTitle("Set as representative").setIcon("star").setDisabled(!canRepresent).setChecked(Boolean(canRepresent && workspace.representativeCanvasPath === canvasPath)).onClick(() => {
      if (canvasPath) this.plugin.store.setRepresentativeWorkspace(workspace.id, canvasPath);
    }));
    menu.addItem((item) => item.setTitle("Rename").setIcon("pencil").onClick(() => new TextPromptModal(this.app, "Rename Workspace", workspace.name, (name) => this.plugin.store.renameWorkspace(workspace.id, name), "Workspace name").open()));
    menu.addSeparator();
    menu.addItem((item) => item.setTitle("Delete").setIcon("trash-2").setDisabled(Object.keys(this.plugin.store.data.workspaces).length <= 1).onClick(() => new ConfirmDeleteWorkspaceModal(this.app, workspace.name, this.plugin.store.itemsForWorkspace(workspace.id).length, () => {
      if (this.plugin.store.removeWorkspace(workspace.id)) new import_obsidian17.Notice(`${workspace.name} deleted. Its Palette items remain in Mini Palette storage.`);
    }).open()));
    const rect = anchor.getBoundingClientRect();
    menu.showAtPosition({ x: rect.right, y: rect.bottom + 2 });
  }
  filteredWorkspaces() {
    const query = this.query.trim().toLocaleLowerCase();
    const workspaces = Object.values(this.plugin.store.data.workspaces).filter((workspace) => {
      var _a;
      if (this.filter !== "all" && workspace.kind !== this.filter) return false;
      const owner = (_a = workspace.ownerCanvasPath) != null ? _a : "";
      if (query && !`${workspace.name} ${owner} ${this.baseName(owner)}`.toLocaleLowerCase().includes(query)) return false;
      if (this.date && this.localDate(workspace.modifiedAt) !== this.date) return false;
      return true;
    });
    const sort = this.viewState().sort;
    return workspaces.sort((a, b) => {
      if (sort === "name-asc" || sort === "name-desc") return a.name.localeCompare(b.name, void 0, { numeric: true }) * (sort === "name-asc" ? 1 : -1);
      const key = sort.startsWith("created") ? "createdAt" : "modifiedAt";
      return (a[key] - b[key]) * (sort.endsWith("asc") ? 1 : -1);
    });
  }
  viewState() {
    return this.plugin.store.data.uiState.workspaceExplorer;
  }
  baseName(path) {
    var _a, _b;
    return (_b = (_a = path.split("/").pop()) == null ? void 0 : _a.replace(/\.canvas$/i, "")) != null ? _b : path;
  }
  formatDate(value) {
    return new Intl.DateTimeFormat(void 0, { year: "numeric", month: "short", day: "numeric" }).format(value);
  }
  localDate(value) {
    const date = new Date(value);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  }
};
var ConfirmDeleteWorkspaceModal = class extends import_obsidian17.Modal {
  constructor(app, name, count, onConfirm) {
    super(app);
    this.name = name;
    this.count = count;
    this.onConfirm = onConfirm;
  }
  onOpen() {
    this.contentEl.addClass("canvas-palette", "cp-confirm-modal");
    this.contentEl.createEl("h2", { text: "Delete Workspace?" });
    this.contentEl.createEl("p", { text: `\u201C${this.name}\u201D will be removed. Its ${this.count} Palette item${this.count === 1 ? "" : "s"} will remain in Mini Palette storage. Original Vault files and Canvas nodes will not be deleted.` });
    const actions = this.contentEl.createDiv({ cls: "cp-modal-actions" });
    actions.createEl("button", { text: "Cancel" }).addEventListener("click", () => this.close());
    actions.createEl("button", { text: "Delete Workspace", cls: "mod-warning" }).addEventListener("click", () => {
      this.onConfirm();
      this.close();
    });
  }
  onClose() {
    this.contentEl.empty();
  }
};

// src/main.ts
var CanvasPalettePlugin = class extends import_obsidian18.Plugin {
  constructor() {
    super(...arguments);
    __publicField(this, "canvasSyncTimers", /* @__PURE__ */ new Map());
    __publicField(this, "lastCanvasPath", null);
    __publicField(this, "store", new PaletteStore(this));
    __publicField(this, "search", new SearchService());
    __publicField(this, "canvas", new CanvasAdapter(
      this.app,
      (itemId, canvasPath, nodeIds) => this.store.recordCanvasPlacement(itemId, canvasPath, nodeIds),
      (canvasPath, nodeId) => this.store.getCanvasNodeMetadata(canvasPath, nodeId),
      (canvasPath, records) => this.store.restoreCanvasNodeMetadata(canvasPath, records),
      (item, canvasPath) => this.store.linkedCanvasNodes(item).filter((location) => location.canvasPath === canvasPath).map((location) => location.nodeId),
      (itemId, canvasPath, removedNodeIds, newNodeIds, existingNodeIds) => this.store.replaceCanvasPlacement(itemId, canvasPath, removedNodeIds, newNodeIds, existingNodeIds)
    ));
    __publicField(this, "exportPlacement", new ExportPlacementController(this.canvas));
    __publicField(this, "canvasMetadata", new CanvasMetadataController(this, this.canvas));
    __publicField(this, "canvasToolbar", new CanvasNodeToolbarController(this.canvas, {
      editMetadata: (nodes) => this.editCanvasNodesMetadata(nodes),
      collectToMini: () => void this.collectCanvasSelection(),
      saveToSide: (anchor) => this.saveCanvasSelectionFromToolbar(anchor),
      supportsFaces: (node) => this.canvas.supportsFrontBack(node),
      facesEnabled: (canvasPath, nodeId) => {
        var _a, _b;
        return (_b = (_a = this.store.getCanvasNodeMetadata(canvasPath, nodeId)) == null ? void 0 : _a.facesEnabled) != null ? _b : false;
      },
      enableFaces: (canvasPath, nodeId) => {
        this.store.enableCanvasNodeFaces(canvasPath, nodeId);
        new import_obsidian18.Notice("Front / Back enabled for this Canvas node.");
      },
      disableFaces: (canvasPath, nodeId) => {
        this.store.disableCanvasNodeFaces(canvasPath, nodeId);
        new import_obsidian18.Notice("Front / Back removed from this material.");
      },
      isLinked: (canvasPath, nodeId) => Boolean(this.store.linkedItemForNode(canvasPath, nodeId)),
      unlink: (canvasPath, nodeId) => {
        if (this.store.unlinkCanvasNode(canvasPath, nodeId)) new import_obsidian18.Notice("Canvas node unlinked from Palette. Its Front, Back, and Metadata were preserved.");
      }
    }));
    __publicField(this, "dropController", new PaletteDropController(this.store, this.canvas));
    __publicField(this, "textScrapHighlights", new TextScrapHighlights(this));
    __publicField(this, "preview", new PreviewService(this.app, this));
    __publicField(this, "miniPalette", new FloatingMiniPalette(this));
    __publicField(this, "editorManager", new PaletteEditorManager(this.app, this));
  }
  async onload() {
    await this.store.load();
    this.lastCanvasPath = this.store.data.uiState.lastCanvasPath;
    this.reconcileLoadedMarkdownSources();
    this.register(this.dropController.mount(this.app.workspace.containerEl.ownerDocument));
    this.register(this.canvasToolbar.mount(this.app.workspace.containerEl.ownerDocument));
    this.registerEditorExtension(this.textScrapHighlights.extension());
    this.register(this.store.subscribe(() => {
      this.textScrapHighlights.refreshVisibleEditors();
      this.canvasMetadata.refreshSoon();
      this.canvasToolbar.refreshSoon();
    }));
    this.registerView(SIDE_PALETTE_VIEW, (leaf) => new SidePaletteView(leaf, this));
    this.addRibbonIcon("library-big", "Open Canvas Palette", () => void this.activateSidePalette());
    this.addRibbonIcon("panels-top-left", "Toggle Canvas Mini Palette", () => this.miniPalette.toggle());
    this.addCommand({ id: "open-side-palette", name: "Open Side Palette", callback: () => void this.activateSidePalette() });
    this.addCommand({ id: "open-mini-palette", name: "Toggle Mini Palette on Canvas", callback: () => this.miniPalette.toggle() });
    this.addCommand({ id: "collect-canvas-selection", name: "Collect selected Canvas items", callback: () => void this.collectCanvasSelection() });
    this.addCommand({ id: "collect-selected-text", name: "Collect selected text as card", editorCheckCallback: (checking, editor, view) => {
      var _a;
      const selection = editor.getSelection();
      if (!selection) return false;
      if (!checking) this.collectText(selection, (_a = view.file) == null ? void 0 : _a.path, { from: editor.getCursor("from"), to: editor.getCursor("to") });
      return true;
    } });
    this.addCommand({ id: "new-workspace", name: "Create workspace", callback: () => {
      const workspace = this.store.createWorkspace(`Workspace ${Object.keys(this.store.data.workspaces).length + 1}`);
      this.store.data.uiState.activeWorkspaceId = workspace.id;
      this.store.changed();
      new import_obsidian18.Notice(`Created ${workspace.name}`);
    } });
    const workspaceEvents = this.app.workspace;
    this.registerEvent(this.app.workspace.on("editor-menu", (menu, editor) => this.addCanvasTextCollectionMenu(menu, editor)));
    this.registerEvent(this.app.vault.on("modify", (file) => {
      if (!(file instanceof import_obsidian18.TFile)) return;
      if (file.extension.toLowerCase() === "canvas") this.scheduleCanvasSync(file);
      else if (file.extension.toLowerCase() === "md") void this.refreshMarkdownSource(file);
    }));
    this.registerEvent(this.app.vault.on("delete", (file) => this.store.reconcileDeletedFile(file.path, file instanceof import_obsidian18.TFolder)));
    this.registerEvent(this.app.vault.on("rename", (file, oldPath) => void this.handleVaultRename(file, oldPath)));
    this.registerEvent(this.app.vault.on("create", (file) => {
      if (file instanceof import_obsidian18.TFile && file.extension.toLowerCase() === "md") void this.reconnectMovedMarkdown(file);
    }));
    this.registerEvent(this.app.workspace.on("active-leaf-change", () => {
      const context = this.canvas.activeContext();
      if (!this.exportPlacement.isFor(context)) this.exportPlacement.cancel();
      if (context) {
        const changedCanvas = context.file.path !== this.lastCanvasPath;
        this.lastCanvasPath = context.file.path;
        if (this.store.data.uiState.lastCanvasPath !== context.file.path) {
          this.store.data.uiState.lastCanvasPath = context.file.path;
          this.store.changed();
        }
        this.miniPalette.mount();
        this.scheduleCanvasSync(context.file);
        if (changedCanvas) this.selectRepresentativeWorkspace(context.file.path);
      } else this.miniPalette.destroy();
      this.canvasMetadata.refreshSoon();
      this.canvasToolbar.refreshSoon();
    }));
    this.registerEvent(workspaceEvents.on("layout-change", () => {
      this.canvasMetadata.refreshSoon();
      this.canvasToolbar.refreshSoon();
    }));
    this.addSettingTab(new CanvasPaletteSettingTab(this));
    const initialCanvas = this.canvas.activeContext();
    if (initialCanvas) {
      this.lastCanvasPath = initialCanvas.file.path;
      this.store.data.uiState.lastCanvasPath = initialCanvas.file.path;
      this.miniPalette.mount();
      this.scheduleCanvasSync(initialCanvas.file);
      this.selectRepresentativeWorkspace(initialCanvas.file.path);
    }
    this.canvasMetadata.refreshSoon();
  }
  async onunload() {
    for (const timer of this.canvasSyncTimers.values()) window.clearTimeout(timer);
    this.canvasSyncTimers.clear();
    this.exportPlacement.cancel();
    this.canvasToolbar.destroy();
    this.canvasMetadata.destroy();
    this.miniPalette.destroy();
    await this.editorManager.close();
    await this.store.flush();
  }
  activeWorkspace() {
    const id = this.store.data.uiState.activeWorkspaceId;
    return id ? this.store.data.workspaces[id] : void 0;
  }
  currentCanvasPath() {
    var _a, _b;
    return (_b = (_a = this.canvas.activeContext()) == null ? void 0 : _a.file.path) != null ? _b : this.lastCanvasPath;
  }
  workspaceDisplayName(workspace) {
    const currentPath = this.currentCanvasPath();
    const representativePath = workspace.kind === "canvas" ? workspace.representativeCanvasPath : null;
    const representativeMark = representativePath ? representativePath === currentPath ? "\u2605 " : "\u2606 " : "";
    return `${representativeMark}${workspace.name}${workspace.kind === "canvas" ? " \xB7 Canvas" : ""}`;
  }
  workspaceAcceptsCanvas(workspace, canvasPath) {
    return workspace.kind === "general" || workspace.ownerCanvasPath === canvasPath;
  }
  isOtherCanvasRepresentativeWorkspace(workspaceId, canvasPath = this.currentCanvasPath()) {
    const workspace = this.store.data.workspaces[workspaceId];
    return Boolean(canvasPath && (workspace == null ? void 0 : workspace.kind) === "canvas" && workspace.representativeCanvasPath && workspace.representativeCanvasPath !== canvasPath);
  }
  canSaveCanvasToWorkspace(workspace, canvasPath) {
    return this.workspaceAcceptsCanvas(workspace, canvasPath) || this.isOtherCanvasRepresentativeWorkspace(workspace.id, canvasPath);
  }
  confirmWorkspaceSave(workspaceId, onConfirm) {
    const workspace = this.store.data.workspaces[workspaceId];
    if (!workspace) return;
    if (!this.isOtherCanvasRepresentativeWorkspace(workspaceId)) {
      onConfirm();
      return;
    }
    new ConfirmForeignCanvasWorkspaceModal(this.app, workspace.name, onConfirm).open();
  }
  showAlreadySavedToWorkspace(workspaceId, savedCount, alreadySavedCount) {
    var _a, _b;
    new AlreadySavedToWorkspaceModal(this.app, (_b = (_a = this.store.data.workspaces[workspaceId]) == null ? void 0 : _a.name) != null ? _b : "Side Palette", savedCount, alreadySavedCount).open();
  }
  openCurrentCanvasWorkspace() {
    const workspace = this.ensureCurrentCanvasWorkspace();
    if (!workspace) {
      new import_obsidian18.Notice("Open a Canvas first.");
      return;
    }
    this.store.data.uiState.activeWorkspaceId = workspace.id;
    this.store.changed();
  }
  showWorkspaceMenu(anchor) {
    const menu = new import_obsidian18.Menu();
    const canvasPath = this.currentCanvasPath();
    menu.addItem((entry) => entry.setTitle("Create general Workspace\u2026").setIcon("folder-plus").onClick(() => new TextPromptModal(this.app, "New general Workspace", "", (name) => {
      const workspace = this.store.createWorkspace(name, "general");
      this.store.data.uiState.activeWorkspaceId = workspace.id;
      this.store.changed();
    }, "Workspace name").open()));
    menu.addItem((entry) => entry.setTitle("Create Workspace for current Canvas\u2026").setIcon("layout-dashboard").setDisabled(!canvasPath).onClick(() => {
      if (!canvasPath) return;
      const count = this.store.canvasWorkspaces(canvasPath).length;
      new TextPromptModal(this.app, "New Canvas Workspace", `${this.canvasBaseName(canvasPath)} ${count + 1}`, (name) => {
        const workspace = this.store.createWorkspace(name, "canvas", canvasPath, count === 0);
        this.store.data.uiState.activeWorkspaceId = workspace.id;
        this.store.changed();
      }, "Workspace name").open();
    }));
    const active = this.activeWorkspace();
    if (active) {
      menu.addSeparator();
      menu.addItem((entry) => entry.setTitle("Rename current Workspace\u2026").setIcon("pencil").onClick(() => new TextPromptModal(this.app, "Rename Workspace", active.name, (name) => this.store.renameWorkspace(active.id, name), "Workspace name").open()));
      const canRepresent = Boolean(canvasPath && active.kind === "canvas" && active.ownerCanvasPath === canvasPath);
      const isRepresentative = Boolean(canRepresent && active.representativeCanvasPath === canvasPath);
      menu.addItem((entry) => entry.setTitle(isRepresentative ? "Representative Workspace" : "Set as representative").setIcon("star").setChecked(isRepresentative).setDisabled(!canRepresent).onClick(() => {
        if (canvasPath && this.store.setRepresentativeWorkspace(active.id, canvasPath)) new import_obsidian18.Notice(`${active.name} is now the representative Workspace.`);
      }));
    }
    const rect = anchor.getBoundingClientRect();
    menu.showAtPosition({ x: rect.left, y: rect.bottom + 4 });
  }
  openWorkspaceExplorer() {
    new WorkspaceExplorerModal(this.app, this).open();
  }
  selectedItem() {
    const id = this.store.data.uiState.selectedItemId;
    return id ? this.store.data.items[id] : void 0;
  }
  selectItem(id) {
    this.store.data.uiState.selectedItemId = id;
    this.store.changed();
  }
  async revealPaletteItemForCanvasNode(canvasPath, nodeId) {
    const item = this.store.linkedItemForNode(canvasPath, nodeId);
    if (!item) {
      new import_obsidian18.Notice("This Canvas node is no longer linked to a Palette item.");
      return;
    }
    const workspace = this.store.workspaceForItem(item.id);
    if (!workspace) {
      new import_obsidian18.Notice("The linked Palette item is not stored in a Workspace.");
      return;
    }
    if (this.store.data.uiState.activeWorkspaceId !== workspace.id) {
      this.store.data.uiState.activeWorkspaceId = workspace.id;
      this.store.changed();
    }
    const view = await this.activateSidePalette();
    if (!view) {
      new import_obsidian18.Notice("Unable to open Side Palette.");
      return;
    }
    view.revealItem(item.id);
  }
  async openItemEditor(itemId) {
    if (await this.editorManager.openItem(itemId)) return;
    new ItemEditorModal(this.app, this, itemId).open();
  }
  async openSideItemPreview(itemId) {
    const item = this.store.data.items[itemId];
    if (!item) return;
    if (item.type === "card" || item.type === "markdown") {
      await this.openItemEditor(itemId);
      return;
    }
    new ItemPreviewModal(this.app, this, itemId).open();
  }
  openSettings() {
    const appWithSettings = this.app;
    if (appWithSettings.setting) {
      void appWithSettings.setting.open();
      appWithSettings.setting.openTabById(this.manifest.id);
    }
  }
  async createMemo() {
    var _a;
    const now = Date.now();
    const workspace = this.activeWorkspace();
    const item = { id: createId("card"), type: "card", displayTitle: "New memo", tags: [], label: "", caption: "", backContent: "", facesEnabled: false, createdAt: now, modifiedAt: now, origin: { canvasPath: (workspace == null ? void 0 : workspace.kind) === "canvas" ? (_a = workspace.ownerCanvasPath) != null ? _a : void 0 : void 0 }, canvasPlacements: [], content: "" };
    this.store.addPending(item);
    if (workspace) this.store.importPending(workspace.id, [item.id]);
    this.selectItem(item.id);
  }
  createCollection() {
    const workspace = this.activeWorkspace();
    if (!workspace) return;
    this.store.createCollection(workspace.id, `Collection ${workspace.rootCollectionIds.length + 1}`);
  }
  collectText(text, sourcePath, textRange) {
    const now = Date.now();
    this.store.addPending({ id: createId("card"), type: "card", displayTitle: text.split(/\r?\n/, 1)[0].slice(0, 60) || "Text scrap", tags: [], label: "", caption: "Text scrap", backContent: "", facesEnabled: false, createdAt: now, modifiedAt: now, origin: { filePath: sourcePath, textRange }, canvasPlacements: [], content: text });
    new import_obsidian18.Notice("Text collected in Mini Palette");
  }
  async collectCanvasSelection() {
    const items = await this.canvas.collectSelection();
    if (items.length === 0) return;
    const collected = this.store.collectCanvasItems(items);
    this.store.data.uiState.miniPalette.tab = "collect";
    this.miniPalette.open();
    new import_obsidian18.Notice(`${collected.length} Canvas item${collected.length === 1 ? "" : "s"} collected in Mini Palette.`);
  }
  sendItemsToMini(itemIds) {
    const validIds = [...new Set(itemIds)].filter((id) => Boolean(this.store.data.items[id]));
    if (validIds.length === 0) {
      new import_obsidian18.Notice("Select one or more Side Palette items first.");
      return;
    }
    const added = this.store.addMiniStorageItems(validIds);
    this.store.data.uiState.miniPalette.tab = "storage";
    this.miniPalette.open();
    new import_obsidian18.Notice(added.length > 0 ? `${added.length} item${added.length === 1 ? "" : "s"} exported to Mini Palette.` : "The selected items are already in Mini Palette.");
  }
  async exportItemsToActiveCanvas(itemIds) {
    const items = [...new Set(itemIds)].map((id) => this.store.data.items[id]).filter((item) => Boolean(item));
    if (items.length === 0) {
      new import_obsidian18.Notice("Select one or more Palette items first.");
      return false;
    }
    return this.beginExport((context) => this.canvas.createItemBundle(items, context));
  }
  async exportItemsAsMindMap(itemIds) {
    const tree = this.exportSelectedItemTree(itemIds);
    if (tree.length === 0) {
      new import_obsidian18.Notice("Select one or more Palette items first.");
      return false;
    }
    return this.beginExport((context) => this.canvas.createTreeBundle(tree, context));
  }
  async exportOutlineSelectionAsMindMap(targets) {
    const tree = this.exportOutlineSelectionTree(targets);
    if (tree.length === 0) {
      new import_obsidian18.Notice("Select one or more Outliner rows first.");
      return false;
    }
    return this.beginExport((context) => this.canvas.createTreeBundle(tree, context));
  }
  editCanvasNodesMetadata(nodes) {
    var _a;
    const targets = nodes.map((node) => this.canvas.nodeContext(node)).filter((target) => Boolean(target));
    if (targets.length === 0) {
      new import_obsidian18.Notice("Unable to identify the selected Canvas items.");
      return;
    }
    const first = targets[0];
    const current = (_a = this.store.getCanvasNodeMetadata(first.canvasPath, first.nodeId)) != null ? _a : { tags: [], label: "", caption: "", modifiedAt: Date.now() };
    new MetadataEditorModal(this.app, this, current, (metadata) => {
      for (const target of targets) this.store.setCanvasNodeMetadata(target.canvasPath, target.nodeId, metadata);
      new import_obsidian18.Notice(`Palette metadata applied to ${targets.length} Canvas item${targets.length === 1 ? "" : "s"}.`);
    }).open();
  }
  saveCanvasSelectionFromToolbar(anchor) {
    const workspaces = Object.values(this.store.data.workspaces);
    if (workspaces.length === 0) {
      new import_obsidian18.Notice("Create a Workspace before saving Canvas items.");
      return;
    }
    const canvasPath = this.currentCanvasPath();
    if (workspaces.length === 1 && canvasPath && this.canSaveCanvasToWorkspace(workspaces[0], canvasPath)) {
      this.confirmWorkspaceSave(workspaces[0].id, () => void this.collectCanvasSelectionToWorkspace(workspaces[0].id));
      return;
    }
    const currentId = this.store.data.uiState.activeWorkspaceId;
    const ordered = [...workspaces].sort((a, b) => Number(b.id === currentId) - Number(a.id === currentId));
    const menu = new import_obsidian18.Menu();
    for (const workspace of ordered) menu.addItem((item) => item.setTitle(this.workspaceDisplayName(workspace)).setIcon(workspace.id === currentId ? "check" : "panel-right").setDisabled(!canvasPath || !this.canSaveCanvasToWorkspace(workspace, canvasPath)).onClick(() => this.confirmWorkspaceSave(workspace.id, () => void this.collectCanvasSelectionToWorkspace(workspace.id))));
    const rect = anchor.getBoundingClientRect();
    menu.showAtPosition({ x: rect.left, y: rect.bottom + 4 });
  }
  addCanvasTextCollectionMenu(menu, editor) {
    const text = editor.getSelection();
    const context = this.canvas.activeContext();
    if (!text || !context) return;
    const range = { from: editor.getCursor("from"), to: editor.getCursor("to") };
    menu.addSeparator();
    menu.addItem((item) => item.setTitle("Canvas Palette \u2014 collect selected text").setIcon("library-big").setIsLabel(true));
    menu.addItem((item) => item.setTitle("Collect text to Mini Palette").setIcon("inbox").onClick(() => this.collectCanvasTextToMini(text, context.file.path, range)));
    const currentWorkspace = this.activeWorkspace();
    if (currentWorkspace) menu.addItem((item) => item.setTitle(`Save text directly to Side Palette \u2014 ${currentWorkspace.name}`).setIcon("panel-right").setDisabled(!this.canSaveCanvasToWorkspace(currentWorkspace, context.file.path)).onClick(() => this.confirmWorkspaceSave(currentWorkspace.id, () => this.collectCanvasTextToWorkspace(text, context.file.path, range, currentWorkspace.id))));
    for (const workspace of Object.values(this.store.data.workspaces)) {
      if (workspace.id === (currentWorkspace == null ? void 0 : currentWorkspace.id)) continue;
      menu.addItem((item) => item.setTitle(`Save text directly to Side Palette \u2014 ${workspace.name}`).setIcon("panel-right").setDisabled(!this.canSaveCanvasToWorkspace(workspace, context.file.path)).onClick(() => this.confirmWorkspaceSave(workspace.id, () => this.collectCanvasTextToWorkspace(text, context.file.path, range, workspace.id))));
    }
  }
  textItem(text, canvasPath, textRange) {
    const now = Date.now();
    return { id: createId("card"), type: "card", displayTitle: text.split(/\r?\n/, 1)[0].slice(0, 60) || "Text scrap", tags: [], label: "", caption: "Text scrap", backContent: "", facesEnabled: false, createdAt: now, modifiedAt: now, origin: { canvasPath, textRange }, canvasPlacements: [], content: text };
  }
  collectCanvasTextToMini(text, canvasPath, textRange) {
    this.store.addPending(this.textItem(text, canvasPath, textRange));
    this.store.data.uiState.miniPalette.tab = "collect";
    this.miniPalette.open();
    new import_obsidian18.Notice("Selected Canvas text collected in Mini Palette.");
  }
  collectCanvasTextToWorkspace(text, canvasPath, textRange, workspaceId) {
    const item = this.textItem(text, canvasPath, textRange);
    const saved = this.isOtherCanvasRepresentativeWorkspace(workspaceId, canvasPath) ? this.store.addToWorkspaceAsUnlinked(workspaceId, item) : this.store.addToWorkspace(workspaceId, item);
    if (!saved) {
      new import_obsidian18.Notice("This Canvas Workspace only accepts items from its own Canvas.");
      return;
    }
    this.store.data.uiState.activeWorkspaceId = workspaceId;
    this.selectItem(item.id);
    void this.openSidePalette();
    new import_obsidian18.Notice("Selected Canvas text saved to Side Palette.");
  }
  async collectCanvasSelectionToWorkspace(workspaceId) {
    var _a;
    const items = await this.canvas.collectSelection();
    if (items.length === 0) return;
    const candidates = items.map((item) => {
      var _a2;
      return (_a2 = this.store.existingCollectedItem(item)) != null ? _a2 : item;
    });
    const save = this.isOtherCanvasRepresentativeWorkspace(workspaceId) ? (item) => this.store.addToWorkspaceAsUnlinked(workspaceId, item) : (item) => this.store.addToWorkspace(workspaceId, item);
    const unique = candidates.filter((item, index) => candidates.findIndex((candidate) => candidate.id === item.id) === index);
    const alreadySaved = unique.filter((item) => {
      var _a2;
      return ((_a2 = this.store.workspaceForItem(item.id)) == null ? void 0 : _a2.id) === workspaceId;
    });
    const accepted = unique.filter((item) => !alreadySaved.includes(item) && save(item));
    if (accepted.length === 0 && alreadySaved.length === 0) {
      new import_obsidian18.Notice("This Canvas Workspace only accepts items from its own Canvas.");
      return;
    }
    this.store.data.uiState.activeWorkspaceId = workspaceId;
    this.store.data.uiState.selectedItemId = ((_a = accepted[0]) != null ? _a : alreadySaved[0]).id;
    this.store.changed();
    await this.openSidePalette();
    if (alreadySaved.length > 0) this.showAlreadySavedToWorkspace(workspaceId, accepted.length, alreadySaved.length);
    else new import_obsidian18.Notice(`${accepted.length} Canvas item${accepted.length === 1 ? "" : "s"} saved to Side Palette.`);
  }
  markdownSourceStatus(item) {
    if (item.type !== "markdown") return null;
    if (item.sourceDeletedAt) return "deleted";
    return null;
  }
  showMarkdownSourceMenu(item, event) {
    const status = this.markdownSourceStatus(item);
    if (!status) return;
    const menu = new import_obsidian18.Menu();
    menu.addItem((entry) => entry.setTitle("MD \uBCF5\uAD6C").setIcon("file-up").onClick(() => void this.restoreMarkdownSource(item.id)));
    menu.addItem((entry) => entry.setTitle("Palette\uC5D0\uC11C \uC0AD\uC81C").setIcon("trash").onClick(() => new ConfirmDeleteModal(this.app, 1, () => this.store.removeItems([item.id])).open()));
    menu.showAtMouseEvent(event);
  }
  async restoreMarkdownSource(itemId) {
    var _a;
    const item = this.store.data.items[itemId];
    const path = item == null ? void 0 : item.origin.filePath;
    if (!item || item.type !== "markdown" || !path) return false;
    const relatedItems = this.store.allItems().filter((candidate) => candidate.type === "markdown" && candidate.origin.filePath === path);
    try {
      const existing = this.app.vault.getAbstractFileByPath(path);
      if (existing && !(existing instanceof import_obsidian18.TFile)) {
        new import_obsidian18.Notice(`Cannot restore Markdown at ${path}.`);
        return false;
      }
      if (!existing) {
        const slash = path.lastIndexOf("/");
        await this.ensureVaultFolder(slash >= 0 ? path.slice(0, slash) : "");
        const restoredContent = (_a = item.content) != null ? _a : "";
        await this.app.vault.create(path, restoredContent);
      }
      const restored = this.store.restoreSource(item.id, path);
      if (!restored) return false;
      for (const related of relatedItems) await this.canvas.convertLinkedCardsToMarkdown(this.store.linkedCanvasNodes(related), path);
      new import_obsidian18.Notice(`Restored ${path} and reconnected its Canvas cards.`);
      return true;
    } catch (error) {
      console.error("Canvas Palette failed to restore a deleted Markdown source", error);
      new import_obsidian18.Notice("Could not restore the Markdown source.");
      return false;
    }
  }
  reconcileLoadedMarkdownSources() {
    for (const item of this.store.allItems()) {
      if (item.type !== "markdown" || !item.origin.filePath) continue;
      const file = this.app.vault.getAbstractFileByPath(item.origin.filePath);
      if (!(file instanceof import_obsidian18.TFile)) this.store.reconcileDeletedFile(item.origin.filePath);
      else if (item.sourceDeletedAt) this.store.restoreSource(item.id, file.path);
    }
  }
  async refreshMarkdownSource(file) {
    try {
      this.store.updateMarkdownSource(file.path, await this.app.vault.cachedRead(file));
    } catch (error) {
      console.error("Canvas Palette failed to refresh a Markdown source", error);
    }
  }
  async handleVaultRename(file, oldPath) {
    this.store.renameCanvasPath(oldPath, file.path, file instanceof import_obsidian18.TFolder);
    const changedItems = this.store.renameSourcePath(oldPath, file.path, file instanceof import_obsidian18.TFolder);
    for (const item of changedItems) {
      const path = item.origin.filePath;
      if (path) await this.canvas.renameLinkedFileNodes(this.store.linkedCanvasNodes(item), path);
    }
    if (file instanceof import_obsidian18.TFile && file.extension.toLowerCase() === "md") await this.refreshMarkdownSource(file);
  }
  async reconnectMovedMarkdown(file) {
    const deleted = this.store.allItems().filter((item) => item.type === "markdown" && Boolean(item.sourceDeletedAt) && Boolean(item.origin.filePath));
    if (deleted.length === 0) return;
    try {
      const content = await this.app.vault.cachedRead(file);
      const matches = deleted.filter((item2) => {
        var _a, _b;
        return item2.content === content && ((_b = (_a = item2.origin.filePath) == null ? void 0 : _a.split("/").pop()) == null ? void 0 : _b.toLocaleLowerCase()) === file.name.toLocaleLowerCase();
      });
      const previousPaths = [...new Set(matches.map((item2) => item2.origin.filePath).filter((path) => Boolean(path)))];
      if (previousPaths.length !== 1) return;
      const relatedItems = deleted.filter((item2) => item2.origin.filePath === previousPaths[0]);
      const item = this.store.restoreSource(matches[0].id, file.path);
      if (!item) return;
      for (const related of relatedItems) await this.canvas.renameLinkedFileNodes(this.store.linkedCanvasNodes(related), file.path);
      new import_obsidian18.Notice(`Canvas Palette followed ${file.name} to its new folder.`);
    } catch (error) {
      console.error("Canvas Palette failed to reconnect a moved Markdown source", error);
    }
  }
  async openOriginal(item) {
    if (item.origin.canvasPath && item.origin.canvasNodeId && await this.canvas.revealNode(item.origin.canvasPath, item.origin.canvasNodeId)) return;
    if (item.origin.filePath) {
      const file = this.app.vault.getAbstractFileByPath(item.origin.filePath);
      if (file instanceof import_obsidian18.TFile) {
        await this.app.workspace.getLeaf("tab").openFile(file);
        return;
      }
    }
    new import_obsidian18.Notice("The original item is unavailable.");
  }
  async convertCardToMarkdown(itemId, requestedName, requestedFolder) {
    var _a;
    const item = this.store.data.items[itemId];
    if (!item || item.type !== "card") {
      new import_obsidian18.Notice("Only Card items can be converted to Markdown.");
      return false;
    }
    const baseName = requestedName.trim().replace(/\.md$/i, "").replace(/[.\s]+$/g, "");
    if (!baseName || /[\\/:*?"<>|]/.test(baseName)) {
      new import_obsidian18.Notice("Enter a valid Markdown file name.");
      return false;
    }
    const folder = requestedFolder.trim().replace(/^\/+|\/+$/g, "");
    const path = (0, import_obsidian18.normalizePath)(`${folder ? `${folder}/` : ""}${baseName}.md`);
    if (this.app.vault.getAbstractFileByPath(path)) {
      new import_obsidian18.Notice(`A file already exists at ${path}.`);
      return false;
    }
    try {
      await this.ensureVaultFolder(folder);
      await this.app.vault.create(path, (_a = item.content) != null ? _a : "");
      await this.canvas.convertLinkedCardsToMarkdown(this.store.linkedCanvasNodes(item), path);
      if (!this.store.convertCardToMarkdown(item.id, path)) return false;
      new import_obsidian18.Notice(`${item.displayTitle} and its linked Canvas Cards now share ${path}.`);
      return true;
    } catch (error) {
      console.error("Canvas Palette failed to convert a Card to shared Markdown", error);
      new import_obsidian18.Notice("Could not create the Markdown file.");
      return false;
    }
  }
  async renameLinkedItem(itemId, requestedTitle) {
    var _a, _b, _c, _d;
    const item = this.store.data.items[itemId];
    if (!item || item.type === "card") return false;
    const title = requestedTitle.trim();
    if (!title) return false;
    const locations = this.store.linkedCanvasNodes(item);
    try {
      if (item.type === "markdown" || item.type === "image") {
        const source = item.origin.filePath ? this.app.vault.getAbstractFileByPath(item.origin.filePath) : null;
        if (!(source instanceof import_obsidian18.TFile)) {
          new import_obsidian18.Notice("The linked source file is unavailable.");
          return false;
        }
        const baseName = title.replace(new RegExp(`\\.${source.extension}$`, "i"), "");
        if (!baseName || /[\\/:*?"<>|]/.test(baseName)) {
          new import_obsidian18.Notice("Enter a valid file name.");
          return false;
        }
        const parentPath = ((_a = source.parent) == null ? void 0 : _a.path) && source.parent.path !== "/" ? `${source.parent.path}/` : "";
        const nextPath = (0, import_obsidian18.normalizePath)(`${parentPath}${baseName}.${source.extension}`);
        if (nextPath !== source.path && this.app.vault.getAbstractFileByPath(nextPath)) {
          new import_obsidian18.Notice(`A file already exists at ${nextPath}.`);
          return false;
        }
        if (nextPath !== source.path) await this.app.fileManager.renameFile(source, nextPath);
        item.origin.filePath = nextPath;
        await this.canvas.renameLinkedFileNodes(locations, nextPath);
      } else if (item.type === "group") {
        const rootGroup = (_d = (_b = item.group) == null ? void 0 : _b.nodes.find((node) => node.type === "group" && !node.parentId)) != null ? _d : (_c = item.group) == null ? void 0 : _c.nodes.find((node) => node.type === "group");
        if (rootGroup) rootGroup.label = title;
        await this.canvas.renameLinkedGroupNodes(locations, title);
      }
      this.store.updateItem(item.id, { displayTitle: title, tags: item.tags, label: item.label, labelColor: item.labelColor, caption: item.caption });
      new import_obsidian18.Notice(`Renamed linked ${item.type} item to ${title}.`);
      return true;
    } catch (error) {
      console.error("Canvas Palette failed to rename a linked item", error);
      new import_obsidian18.Notice("Could not rename every linked item.");
      this.store.changed();
      return false;
    }
  }
  async ensureVaultFolder(folder) {
    if (!folder) return;
    let current = "";
    for (const segment of folder.split("/").filter(Boolean)) {
      current = (0, import_obsidian18.normalizePath)(current ? `${current}/${segment}` : segment);
      const existing = this.app.vault.getAbstractFileByPath(current);
      if (existing && !(existing instanceof import_obsidian18.TFolder)) throw new Error(`${current} is not a folder`);
      if (!existing) await this.app.vault.createFolder(current);
    }
  }
  async syncPaletteItemToCanvas(item) {
    const locations = this.store.linkedCanvasNodes(item);
    if (locations.length === 0) return;
    try {
      await this.canvas.syncItemToCanvases(item, locations);
    } catch (error) {
      console.error("Canvas Palette failed to synchronize an item to its linked Canvas nodes", error);
    }
  }
  async locateItemOnCanvas(item) {
    const canvasPath = item.origin.canvasPath;
    const nodeId = item.origin.canvasNodeId;
    if (!canvasPath || !nodeId || !await this.canvas.revealNode(canvasPath, nodeId)) new import_obsidian18.Notice("The original Canvas item is unavailable.");
  }
  findLinkedCanvas(item) {
    const locations = this.store.linkedCanvasLocations(item);
    if (locations.length === 0) {
      new import_obsidian18.Notice("This Palette item has no linked Canvas location.");
      return;
    }
    const reveal = async (location) => {
      if (!await this.canvas.revealNode(location.canvasPath, location.nodeId)) new import_obsidian18.Notice("The linked Canvas location is unavailable.");
    };
    if (locations.length === 1) {
      void reveal(locations[0]);
      return;
    }
    new FindLinkModal(this.app, item.displayTitle, locations, (location) => void reveal(location)).open();
  }
  scheduleCanvasSync(file) {
    const previous = this.canvasSyncTimers.get(file.path);
    if (previous !== void 0) window.clearTimeout(previous);
    this.canvasSyncTimers.set(file.path, window.setTimeout(() => {
      this.canvasSyncTimers.delete(file.path);
      void this.syncCanvasFileToPalette(file);
    }, 150));
  }
  async syncCanvasFileToPalette(file) {
    try {
      const result = await this.canvas.syncItemsFromCanvas(file, this.store.allItems());
      const existingNodeIds = mergeCanvasNodeIds(result.nodeIds, this.canvas.openNodeIds(file.path));
      const linksChanged = this.store.reconcileCanvasLinks(file.path, existingNodeIds);
      if (result.changedItems > 0 || linksChanged) {
        this.store.changed();
        for (const item of this.store.allItems()) if (item.type === "card") void this.syncPaletteItemToCanvas(item);
      }
    } catch (error) {
      console.error("Canvas Palette failed to synchronize original Canvas items", error);
    }
  }
  async exportActiveWorkspace() {
    const workspace = this.activeWorkspace();
    if (!workspace) return;
    await this.beginExport((context) => this.canvas.createTreeBundle(this.exportTree(workspace.id), context));
  }
  async exportCollectionSubtree(collectionId) {
    const collection = this.store.data.collections[collectionId];
    if (!collection) return;
    await this.beginExport((context) => this.canvas.createTreeBundle(this.exportTree(collection.workspaceId, collectionId), context));
  }
  async beginExport(createBundle) {
    var _a;
    const target = await new Promise((resolve) => {
      var _a2, _b;
      return new CanvasTargetModal(this.app, this.canvas.canvasFiles(), (_b = (_a2 = this.canvas.activeContext()) == null ? void 0 : _a2.file.path) != null ? _b : this.lastCanvasPath, resolve).open();
    });
    if (!target) return false;
    const context = await this.canvas.openContext(target);
    if (!context) {
      new import_obsidian18.Notice("Unable to open the selected Canvas.");
      return false;
    }
    const bundle = createBundle(context);
    if (bundle.nodes.length === 0) {
      new import_obsidian18.Notice((_a = bundle.warnings[0]) != null ? _a : "There is nothing available to export.");
      return false;
    }
    const duplicateItemIds = this.canvas.bundleDuplicateItemIds(bundle, context);
    const mode = duplicateItemIds.length === 0 ? "copy" : await new Promise((resolve) => new ConfirmExportDuplicateModal(this.app, duplicateItemIds.length, resolve).open());
    if (!mode) return false;
    this.exportPlacement.start(context, bundle, mode);
    return true;
  }
  exportTree(workspaceId, rootCollectionId) {
    const workspace = this.store.data.workspaces[workspaceId];
    if (!workspace) return [];
    const entries = [];
    const itemStack = /* @__PURE__ */ new Set();
    const addItem = (itemId, parentId) => {
      var _a;
      const item = this.store.data.items[itemId];
      if (!item || itemStack.has(itemId)) return;
      const id = `${parentId}/item:${item.id}`;
      entries.push({ id, name: item.displayTitle, parentId, item });
      itemStack.add(itemId);
      for (const childId of (_a = item.childItemIds) != null ? _a : []) addItem(childId, id);
      itemStack.delete(itemId);
    };
    const addCollection = (collectionId, parentId) => {
      const collection = this.store.data.collections[collectionId];
      if (!collection || collection.workspaceId !== workspaceId) return;
      const id = `${parentId}/collection:${collection.id}`;
      entries.push({ id, name: collection.name, parentId });
      for (const itemId of collection.itemIds) addItem(itemId, id);
      for (const childId of collection.childCollectionIds) addCollection(childId, id);
    };
    if (rootCollectionId) {
      const collection = this.store.data.collections[rootCollectionId];
      if (!collection || collection.workspaceId !== workspaceId) return [];
      const root2 = `collection:${collection.id}`;
      entries.push({ id: root2, name: collection.name, parentId: null });
      for (const itemId of collection.itemIds) addItem(itemId, root2);
      for (const childId of collection.childCollectionIds) addCollection(childId, root2);
      return entries;
    }
    const root = `workspace:${workspace.id}`;
    entries.push({ id: root, name: workspace.name, parentId: null });
    for (const collectionId of workspace.rootCollectionIds) addCollection(collectionId, root);
    for (const itemId of workspace.looseItemIds) addItem(itemId, root);
    return entries;
  }
  exportSelectedItemTree(itemIds) {
    var _a;
    const selected = new Set(itemIds.filter((id) => Boolean(this.store.data.items[id])));
    if (selected.size === 0) return [];
    const parentByChild = /* @__PURE__ */ new Map();
    for (const item of this.store.allItems()) for (const childId of (_a = item.childItemIds) != null ? _a : []) if (!parentByChild.has(childId)) parentByChild.set(childId, item.id);
    const hasSelectedAncestor = (itemId) => {
      var _a2, _b, _c, _d, _e, _f;
      const visited = /* @__PURE__ */ new Set();
      let parentId = (_c = (_b = (_a2 = this.store.data.items[itemId]) == null ? void 0 : _a2.parentItemId) != null ? _b : parentByChild.get(itemId)) != null ? _c : null;
      while (parentId && !visited.has(parentId)) {
        if (selected.has(parentId)) return true;
        visited.add(parentId);
        parentId = (_f = (_e = (_d = this.store.data.items[parentId]) == null ? void 0 : _d.parentItemId) != null ? _e : parentByChild.get(parentId)) != null ? _f : null;
      }
      return false;
    };
    const entries = [];
    const added = /* @__PURE__ */ new Set();
    const addItem = (itemId, parentId, path) => {
      var _a2;
      const item = this.store.data.items[itemId];
      if (!item || path.has(itemId) || added.has(itemId)) return;
      const id = `mindmap:item:${item.id}`;
      entries.push({ id, name: item.displayTitle, parentId, item });
      added.add(itemId);
      const nextPath = new Set(path);
      nextPath.add(itemId);
      for (const childId of (_a2 = item.childItemIds) != null ? _a2 : []) addItem(childId, id, nextPath);
    };
    for (const itemId of selected) if (!hasSelectedAncestor(itemId)) addItem(itemId, null, /* @__PURE__ */ new Set());
    return entries;
  }
  exportOutlineSelectionTree(targets) {
    var _a, _b, _c;
    const workspace = this.activeWorkspace();
    if (!workspace) return [];
    const selectedCollections = new Set(targets.filter((target) => target.kind === "collection").map((target) => target.id).filter((id) => {
      var _a2;
      return ((_a2 = this.store.data.collections[id]) == null ? void 0 : _a2.workspaceId) === workspace.id;
    }));
    const selectedItems = new Set(targets.filter((target) => target.kind === "item").map((target) => target.id).filter((id) => Boolean(this.store.data.items[id])));
    const entries = [];
    for (const collectionId of selectedCollections) {
      const collection = this.store.data.collections[collectionId];
      entries.push({ id: `mindmap:collection:${collection.id}`, name: collection.name, parentId: collection.parentId && selectedCollections.has(collection.parentId) ? `mindmap:collection:${collection.parentId}` : null });
    }
    const parentByChild = /* @__PURE__ */ new Map();
    for (const candidate of this.store.allItems()) for (const childId of (_a = candidate.childItemIds) != null ? _a : []) if (!parentByChild.has(childId)) parentByChild.set(childId, candidate.id);
    for (const itemId of selectedItems) {
      const item = this.store.data.items[itemId];
      const parentItemId = (_c = (_b = item.parentItemId) != null ? _b : parentByChild.get(item.id)) != null ? _c : null;
      const containingCollection = Object.values(this.store.data.collections).find((collection) => collection.workspaceId === workspace.id && collection.itemIds.includes(item.id));
      const parentId = parentItemId && selectedItems.has(parentItemId) ? `mindmap:item:${parentItemId}` : containingCollection && selectedCollections.has(containingCollection.id) ? `mindmap:collection:${containingCollection.id}` : null;
      entries.push({ id: `mindmap:item:${item.id}`, name: item.displayTitle, parentId, item });
    }
    return entries;
  }
  async openSidePalette() {
    await this.activateSidePalette();
  }
  selectRepresentativeWorkspace(canvasPath = this.currentCanvasPath()) {
    if (!canvasPath) return;
    const workspace = this.store.ensureCanvasWorkspace(canvasPath, this.canvasBaseName(canvasPath));
    if (workspace && workspace.id !== this.store.data.uiState.activeWorkspaceId) {
      this.store.data.uiState.activeWorkspaceId = workspace.id;
      this.store.changed();
    }
  }
  ensureCurrentCanvasWorkspace() {
    const canvasPath = this.currentCanvasPath();
    if (!canvasPath) return void 0;
    return this.store.ensureCanvasWorkspace(canvasPath, this.canvasBaseName(canvasPath));
  }
  canvasBaseName(path) {
    var _a;
    return ((_a = path.split("/").pop()) == null ? void 0 : _a.replace(/\.canvas$/i, "")) || "Canvas";
  }
  async activateSidePalette() {
    const existing = this.app.workspace.getLeavesOfType(SIDE_PALETTE_VIEW)[0];
    const leaf = existing != null ? existing : this.app.workspace.getRightLeaf(false);
    if (!leaf) return null;
    if (!existing) await leaf.setViewState({ type: SIDE_PALETTE_VIEW, active: true });
    this.app.workspace.revealLeaf(leaf);
    return leaf.view instanceof SidePaletteView ? leaf.view : null;
  }
};
